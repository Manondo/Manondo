﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBillTrade
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnBill = New System.Windows.Forms.Button()
        Me.btnDescriptionSearch = New System.Windows.Forms.Button()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.txtBillDesc = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.txtBillTradeID = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnIDsearch = New System.Windows.Forms.Button()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.btnHome = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnBill
        '
        Me.btnBill.Location = New System.Drawing.Point(636, 271)
        Me.btnBill.Name = "btnBill"
        Me.btnBill.Size = New System.Drawing.Size(75, 23)
        Me.btnBill.TabIndex = 26
        Me.btnBill.Text = "Bill"
        Me.btnBill.UseVisualStyleBackColor = True
        '
        'btnDescriptionSearch
        '
        Me.btnDescriptionSearch.Location = New System.Drawing.Point(707, 20)
        Me.btnDescriptionSearch.Name = "btnDescriptionSearch"
        Me.btnDescriptionSearch.Size = New System.Drawing.Size(75, 23)
        Me.btnDescriptionSearch.TabIndex = 25
        Me.btnDescriptionSearch.Text = "Search"
        Me.btnDescriptionSearch.UseVisualStyleBackColor = True
        '
        'txtSearch
        '
        Me.txtSearch.Location = New System.Drawing.Point(807, 23)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(100, 20)
        Me.txtSearch.TabIndex = 24
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(534, 271)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 22
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'txtBillDesc
        '
        Me.txtBillDesc.Location = New System.Drawing.Point(151, 104)
        Me.txtBillDesc.Name = "txtBillDesc"
        Me.txtBillDesc.Size = New System.Drawing.Size(100, 20)
        Me.txtBillDesc.TabIndex = 21
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(19, 111)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 13)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Bill Trade Description"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(431, 271)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 19
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(266, 58)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(641, 182)
        Me.DataGridView1.TabIndex = 18
        '
        'txtBillTradeID
        '
        Me.txtBillTradeID.Location = New System.Drawing.Point(151, 58)
        Me.txtBillTradeID.Name = "txtBillTradeID"
        Me.txtBillTradeID.Size = New System.Drawing.Size(100, 20)
        Me.txtBillTradeID.TabIndex = 17
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(35, 65)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 13)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Bill Trade ID"
        '
        'btnIDsearch
        '
        Me.btnIDsearch.Location = New System.Drawing.Point(271, 17)
        Me.btnIDsearch.Name = "btnIDsearch"
        Me.btnIDsearch.Size = New System.Drawing.Size(75, 23)
        Me.btnIDsearch.TabIndex = 28
        Me.btnIDsearch.Text = "Search"
        Me.btnIDsearch.UseVisualStyleBackColor = True
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(371, 20)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(100, 20)
        Me.txtID.TabIndex = 27
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(854, 316)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 190
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'frmBillTrade
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(931, 340)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnIDsearch)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.btnBill)
        Me.Controls.Add(Me.btnDescriptionSearch)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.txtBillDesc)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.txtBillTradeID)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmBillTrade"
        Me.Text = "BILL TRADE"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnBill As Button
    Friend WithEvents btnDescriptionSearch As Button
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents btnClear As Button
    Friend WithEvents txtBillDesc As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnAdd As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents txtBillTradeID As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnIDsearch As Button
    Friend WithEvents txtID As TextBox
    Friend WithEvents btnHome As Button
End Class
