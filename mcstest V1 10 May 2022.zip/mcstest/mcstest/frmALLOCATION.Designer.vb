﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmALLOCATION
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtAddDesc = New System.Windows.Forms.TextBox()
        Me.txtdesc = New System.Windows.Forms.TextBox()
        Me.txtIDalloc = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnHome = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Enter new Allocation Description"
        '
        'txtAddDesc
        '
        Me.txtAddDesc.Location = New System.Drawing.Point(9, 81)
        Me.txtAddDesc.Name = "txtAddDesc"
        Me.txtAddDesc.Size = New System.Drawing.Size(157, 20)
        Me.txtAddDesc.TabIndex = 10
        '
        'txtdesc
        '
        Me.txtdesc.Location = New System.Drawing.Point(519, 25)
        Me.txtdesc.Name = "txtdesc"
        Me.txtdesc.Size = New System.Drawing.Size(240, 20)
        Me.txtdesc.TabIndex = 9
        Me.txtdesc.Text = "Type Description to search"
        '
        'txtIDalloc
        '
        Me.txtIDalloc.Location = New System.Drawing.Point(12, 25)
        Me.txtIDalloc.Name = "txtIDalloc"
        Me.txtIDalloc.Size = New System.Drawing.Size(228, 20)
        Me.txtIDalloc.TabIndex = 8
        Me.txtIDalloc.Text = "Type ID to search"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(9, 135)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(165, 43)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Add New Allocation ID"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(12, 66)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(747, 305)
        Me.DataGridView1.TabIndex = 6
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtAddDesc)
        Me.GroupBox1.Location = New System.Drawing.Point(779, 87)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(188, 194)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "ADD ALLOCATION ITEM"
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(904, 358)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 190
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'frmALLOCATION
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(979, 382)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtdesc)
        Me.Controls.Add(Me.txtIDalloc)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "frmALLOCATION"
        Me.Text = "ALLOCATION"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtAddDesc As TextBox
    Friend WithEvents txtdesc As TextBox
    Friend WithEvents txtIDalloc As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnHome As Button
End Class
