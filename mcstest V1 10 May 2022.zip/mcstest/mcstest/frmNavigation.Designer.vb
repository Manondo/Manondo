﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmNavigation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnBillNav = New System.Windows.Forms.Button()
        Me.btnEvaluation = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(239, 9)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(196, 47)
        Me.Button15.TabIndex = 31
        Me.Button15.Text = "Go To Debtor Bank Acc"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(495, 12)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(196, 47)
        Me.Button14.TabIndex = 30
        Me.Button14.Text = "Go To Debtor Type"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(239, 62)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(196, 47)
        Me.Button13.TabIndex = 29
        Me.Button13.Text = "Go To Price Code Resourcing"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(495, 177)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(196, 47)
        Me.Button12.TabIndex = 28
        Me.Button12.Text = "Go To Department"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(239, 177)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(196, 47)
        Me.Button11.TabIndex = 27
        Me.Button11.Text = "Go To User"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(495, 124)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(196, 47)
        Me.Button10.TabIndex = 26
        Me.Button10.Text = "Go To Resource Type"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(239, 115)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(196, 47)
        Me.Button9.TabIndex = 25
        Me.Button9.Text = "Go To Resources"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(495, 65)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(196, 47)
        Me.Button8.TabIndex = 24
        Me.Button8.Text = "Go To Project Code"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(12, 312)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(196, 47)
        Me.Button7.TabIndex = 23
        Me.Button7.Text = "Go To Debtor"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(495, 245)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(196, 47)
        Me.Button6.TabIndex = 22
        Me.Button6.Text = "Go To Classification"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(239, 245)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(196, 47)
        Me.Button5.TabIndex = 21
        Me.Button5.Text = "Go To Allocation"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(12, 245)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(196, 47)
        Me.Button4.TabIndex = 20
        Me.Button4.Text = "Go To Company"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(12, 177)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(196, 47)
        Me.Button3.TabIndex = 19
        Me.Button3.Text = "Go To Cost Code"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(12, 124)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(196, 47)
        Me.Button2.TabIndex = 18
        Me.Button2.Text = "Go To Bill Trade"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 62)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(196, 47)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "Go To Price Code"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnBillNav
        '
        Me.btnBillNav.Location = New System.Drawing.Point(12, 9)
        Me.btnBillNav.Name = "btnBillNav"
        Me.btnBillNav.Size = New System.Drawing.Size(196, 47)
        Me.btnBillNav.TabIndex = 16
        Me.btnBillNav.Text = "Go To Bill"
        Me.btnBillNav.UseVisualStyleBackColor = True
        '
        'btnEvaluation
        '
        Me.btnEvaluation.Location = New System.Drawing.Point(239, 312)
        Me.btnEvaluation.Name = "btnEvaluation"
        Me.btnEvaluation.Size = New System.Drawing.Size(196, 47)
        Me.btnEvaluation.TabIndex = 32
        Me.btnEvaluation.Text = "Go To Evaluation"
        Me.btnEvaluation.UseVisualStyleBackColor = True
        '
        'frmNavigation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(782, 535)
        Me.Controls.Add(Me.btnEvaluation)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnBillNav)
        Me.Name = "frmNavigation"
        Me.Text = "HOME"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Button15 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents btnBillNav As Button
    Friend WithEvents btnEvaluation As Button
End Class
