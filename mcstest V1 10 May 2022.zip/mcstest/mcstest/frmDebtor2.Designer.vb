﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDebtor2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnsearchid = New System.Windows.Forms.Button()
        Me.txtDebtorID = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.btnBrowse = New System.Windows.Forms.Button()
        Me.cmbBEELevel = New System.Windows.Forms.ComboBox()
        Me.cmbBlackOwnership = New System.Windows.Forms.ComboBox()
        Me.dtpBEEEpiryDate = New System.Windows.Forms.DateTimePicker()
        Me.txtCreditLimit = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtBEEClassification = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtBEECertification = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtContactName = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtWebsite = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtFax2 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtFax1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtTel3 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtTel2 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtTel1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtDPhysicalAddress = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtDPostalAddress = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtVATNumber = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtDRegNumber = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtDebtorName = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtDebtorTypeID = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnHome = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnsearchid
        '
        Me.btnsearchid.Location = New System.Drawing.Point(59, 72)
        Me.btnsearchid.Name = "btnsearchid"
        Me.btnsearchid.Size = New System.Drawing.Size(66, 23)
        Me.btnsearchid.TabIndex = 228
        Me.btnsearchid.Text = "Search"
        Me.btnsearchid.UseVisualStyleBackColor = True
        '
        'txtDebtorID
        '
        Me.txtDebtorID.Location = New System.Drawing.Point(9, 45)
        Me.txtDebtorID.Name = "txtDebtorID"
        Me.txtDebtorID.Size = New System.Drawing.Size(116, 20)
        Me.txtDebtorID.TabIndex = 227
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(-74, 75)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(80, 13)
        Me.Label21.TabIndex = 226
        Me.Label21.Text = "Debtor Type ID"
        '
        'btnBrowse
        '
        Me.btnBrowse.Location = New System.Drawing.Point(689, 460)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(136, 30)
        Me.btnBrowse.TabIndex = 225
        Me.btnBrowse.Text = "Browse"
        Me.btnBrowse.UseVisualStyleBackColor = True
        '
        'cmbBEELevel
        '
        Me.cmbBEELevel.FormattingEnabled = True
        Me.cmbBEELevel.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "Non compliant contributor"})
        Me.cmbBEELevel.Location = New System.Drawing.Point(720, 109)
        Me.cmbBEELevel.Name = "cmbBEELevel"
        Me.cmbBEELevel.Size = New System.Drawing.Size(94, 21)
        Me.cmbBEELevel.TabIndex = 224
        '
        'cmbBlackOwnership
        '
        Me.cmbBlackOwnership.FormattingEnabled = True
        Me.cmbBlackOwnership.Items.AddRange(New Object() {"10", "20", "30", "40", "50", "60", "70", "80", "90", "100"})
        Me.cmbBlackOwnership.Location = New System.Drawing.Point(724, 177)
        Me.cmbBlackOwnership.Name = "cmbBlackOwnership"
        Me.cmbBlackOwnership.Size = New System.Drawing.Size(90, 21)
        Me.cmbBlackOwnership.TabIndex = 223
        '
        'dtpBEEEpiryDate
        '
        Me.dtpBEEEpiryDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpBEEEpiryDate.Location = New System.Drawing.Point(724, 76)
        Me.dtpBEEEpiryDate.Name = "dtpBEEEpiryDate"
        Me.dtpBEEEpiryDate.Size = New System.Drawing.Size(90, 20)
        Me.dtpBEEEpiryDate.TabIndex = 222
        '
        'txtCreditLimit
        '
        Me.txtCreditLimit.Location = New System.Drawing.Point(916, 45)
        Me.txtCreditLimit.Name = "txtCreditLimit"
        Me.txtCreditLimit.Size = New System.Drawing.Size(90, 20)
        Me.txtCreditLimit.TabIndex = 221
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(843, 48)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(55, 13)
        Me.Label16.TabIndex = 220
        Me.Label16.Text = "CreditLimit"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(634, 181)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(84, 13)
        Me.Label17.TabIndex = 219
        Me.Label17.Text = "BlackOwnership"
        '
        'txtBEEClassification
        '
        Me.txtBEEClassification.Location = New System.Drawing.Point(724, 143)
        Me.txtBEEClassification.Name = "txtBEEClassification"
        Me.txtBEEClassification.Size = New System.Drawing.Size(90, 20)
        Me.txtBEEClassification.TabIndex = 218
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(629, 146)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(89, 13)
        Me.Label18.TabIndex = 217
        Me.Label18.Text = "BEEClassification"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(660, 109)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(54, 13)
        Me.Label19.TabIndex = 216
        Me.Label19.Text = "BEELevel"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(640, 79)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(74, 13)
        Me.Label20.TabIndex = 215
        Me.Label20.Text = "BEEEpiryDate"
        '
        'txtBEECertification
        '
        Me.txtBEECertification.Location = New System.Drawing.Point(724, 45)
        Me.txtBEECertification.Name = "txtBEECertification"
        Me.txtBEECertification.Size = New System.Drawing.Size(90, 20)
        Me.txtBEECertification.TabIndex = 214
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(635, 48)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(83, 13)
        Me.Label7.TabIndex = 213
        Me.Label7.Text = "BEECertification"
        '
        'txtContactName
        '
        Me.txtContactName.Location = New System.Drawing.Point(486, 174)
        Me.txtContactName.Name = "txtContactName"
        Me.txtContactName.Size = New System.Drawing.Size(90, 20)
        Me.txtContactName.TabIndex = 212
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(405, 177)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(75, 13)
        Me.Label8.TabIndex = 211
        Me.Label8.Text = "Contact Name"
        '
        'txtWebsite
        '
        Me.txtWebsite.Location = New System.Drawing.Point(486, 143)
        Me.txtWebsite.Name = "txtWebsite"
        Me.txtWebsite.Size = New System.Drawing.Size(90, 20)
        Me.txtWebsite.TabIndex = 210
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(434, 146)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(46, 13)
        Me.Label9.TabIndex = 209
        Me.Label9.Text = "Website"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(486, 106)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(90, 20)
        Me.txtEmail.TabIndex = 208
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(444, 109)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(32, 13)
        Me.Label10.TabIndex = 207
        Me.Label10.Text = "Email"
        '
        'txtFax2
        '
        Me.txtFax2.Location = New System.Drawing.Point(486, 76)
        Me.txtFax2.Name = "txtFax2"
        Me.txtFax2.Size = New System.Drawing.Size(90, 20)
        Me.txtFax2.TabIndex = 206
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(446, 79)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(30, 13)
        Me.Label11.TabIndex = 205
        Me.Label11.Text = "Fax2"
        '
        'txtFax1
        '
        Me.txtFax1.Location = New System.Drawing.Point(486, 42)
        Me.txtFax1.Name = "txtFax1"
        Me.txtFax1.Size = New System.Drawing.Size(90, 20)
        Me.txtFax1.TabIndex = 204
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(446, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 13)
        Me.Label1.TabIndex = 203
        Me.Label1.Text = "Fax1"
        '
        'txtTel3
        '
        Me.txtTel3.Location = New System.Drawing.Point(268, 170)
        Me.txtTel3.Name = "txtTel3"
        Me.txtTel3.Size = New System.Drawing.Size(90, 20)
        Me.txtTel3.TabIndex = 202
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(230, 173)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(28, 13)
        Me.Label2.TabIndex = 201
        Me.Label2.Text = "Tel3"
        '
        'txtTel2
        '
        Me.txtTel2.Location = New System.Drawing.Point(268, 139)
        Me.txtTel2.Name = "txtTel2"
        Me.txtTel2.Size = New System.Drawing.Size(90, 20)
        Me.txtTel2.TabIndex = 200
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(230, 142)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 13)
        Me.Label4.TabIndex = 199
        Me.Label4.Text = "Tel2"
        '
        'txtTel1
        '
        Me.txtTel1.Location = New System.Drawing.Point(268, 102)
        Me.txtTel1.Name = "txtTel1"
        Me.txtTel1.Size = New System.Drawing.Size(90, 20)
        Me.txtTel1.TabIndex = 198
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(230, 105)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 13)
        Me.Label5.TabIndex = 197
        Me.Label5.Text = "Tel1"
        '
        'txtDPhysicalAddress
        '
        Me.txtDPhysicalAddress.Location = New System.Drawing.Point(268, 72)
        Me.txtDPhysicalAddress.Name = "txtDPhysicalAddress"
        Me.txtDPhysicalAddress.Size = New System.Drawing.Size(90, 20)
        Me.txtDPhysicalAddress.TabIndex = 196
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(166, 75)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(92, 13)
        Me.Label6.TabIndex = 195
        Me.Label6.Text = "DPhysicalAddress"
        '
        'txtDPostalAddress
        '
        Me.txtDPostalAddress.Location = New System.Drawing.Point(267, 45)
        Me.txtDPostalAddress.Name = "txtDPostalAddress"
        Me.txtDPostalAddress.Size = New System.Drawing.Size(90, 20)
        Me.txtDPostalAddress.TabIndex = 194
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(176, 48)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(82, 13)
        Me.Label12.TabIndex = 193
        Me.Label12.Text = "DPostalAddress"
        '
        'txtVATNumber
        '
        Me.txtVATNumber.Location = New System.Drawing.Point(6, 174)
        Me.txtVATNumber.Name = "txtVATNumber"
        Me.txtVATNumber.Size = New System.Drawing.Size(119, 20)
        Me.txtVATNumber.TabIndex = 192
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(-75, 177)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(65, 13)
        Me.Label13.TabIndex = 191
        Me.Label13.Text = "VATNumber"
        '
        'txtDRegNumber
        '
        Me.txtDRegNumber.Location = New System.Drawing.Point(6, 143)
        Me.txtDRegNumber.Name = "txtDRegNumber"
        Me.txtDRegNumber.Size = New System.Drawing.Size(119, 20)
        Me.txtDRegNumber.TabIndex = 190
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(-75, 146)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 13)
        Me.Label14.TabIndex = 189
        Me.Label14.Text = "DRegNumber"
        '
        'txtDebtorName
        '
        Me.txtDebtorName.Location = New System.Drawing.Point(6, 106)
        Me.txtDebtorName.Name = "txtDebtorName"
        Me.txtDebtorName.Size = New System.Drawing.Size(119, 20)
        Me.txtDebtorName.TabIndex = 188
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(-67, 109)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(67, 13)
        Me.Label15.TabIndex = 187
        Me.Label15.Text = "DebtorName"
        '
        'txtDebtorTypeID
        '
        Me.txtDebtorTypeID.Location = New System.Drawing.Point(6, 76)
        Me.txtDebtorTypeID.Name = "txtDebtorTypeID"
        Me.txtDebtorTypeID.Size = New System.Drawing.Size(47, 20)
        Me.txtDebtorTypeID.TabIndex = 186
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(-53, 45)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 13)
        Me.Label3.TabIndex = 185
        Me.Label3.Text = "Debtor ID"
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(10, 460)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(151, 30)
        Me.btnUpdate.TabIndex = 184
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(183, 460)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(151, 30)
        Me.btnDelete.TabIndex = 183
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(532, 460)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(151, 30)
        Me.btnClear.TabIndex = 182
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(340, 460)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(151, 30)
        Me.btnAdd.TabIndex = 181
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(6, 253)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(1052, 189)
        Me.DataGridView1.TabIndex = 180
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(983, 508)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 229
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'frmDebtor2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1062, 533)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnsearchid)
        Me.Controls.Add(Me.txtDebtorID)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.btnBrowse)
        Me.Controls.Add(Me.cmbBEELevel)
        Me.Controls.Add(Me.cmbBlackOwnership)
        Me.Controls.Add(Me.dtpBEEEpiryDate)
        Me.Controls.Add(Me.txtCreditLimit)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.txtBEEClassification)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.txtBEECertification)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtContactName)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtWebsite)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtFax2)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtFax1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtTel3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtTel2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtTel1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtDPhysicalAddress)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtDPostalAddress)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtVATNumber)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtDRegNumber)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.txtDebtorName)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.txtDebtorTypeID)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "frmDebtor2"
        Me.Text = "DEBTOR"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnsearchid As Button
    Friend WithEvents txtDebtorID As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents btnBrowse As Button
    Friend WithEvents cmbBEELevel As ComboBox
    Friend WithEvents cmbBlackOwnership As ComboBox
    Friend WithEvents dtpBEEEpiryDate As DateTimePicker
    Friend WithEvents txtCreditLimit As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents txtBEEClassification As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents txtBEECertification As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtContactName As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtWebsite As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtFax2 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txtFax1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtTel3 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtTel2 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtTel1 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtDPhysicalAddress As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtDPostalAddress As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txtVATNumber As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtDRegNumber As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents txtDebtorName As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents txtDebtorTypeID As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnAdd As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnHome As Button
End Class
