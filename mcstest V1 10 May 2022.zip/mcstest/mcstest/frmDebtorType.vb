﻿Public Class frmDebtorType


    'sub procedure to be reused to fetch/load data from database tables
    Public Sub connectToDB()
        Try
            'establish connection to DB
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            'select sql statement to view only
            sqlcomm.CommandText = "SELECT* FROM T_DebtorType"
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()

            'populate the datagridview

            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    'subprocedure/ module to search and DISPLAY THE SPECIFIC ROW DATA TO THE DATA GRIDVIEW
    Public Sub cSearchID()

        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            'sql to view/open then fetch specific row of data in the table

            sqlcomm.CommandText = "SELECT* FROM T_DebtorType WHERE DType_Id=@AIDE"


            Dim Debtype As New OleDb.OleDbParameter("@AID", Val(txtsearchbyid.Text))
            sqlcomm.Parameters.Add(Debtype)
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    'subprocedure/ module to search and DISPLAY THE SPECIFIC ROW DATA TO THE DATA GRIDVIEW
    Public Sub cSearchDesc()
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "SELECT* FROM T_DebtorType WHERE Description=@AD"
            Dim allocdis As New OleDb.OleDbParameter("@AD", txtdesc.Text)
            sqlcomm.Parameters.Add(allocdis)
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            Dim intcount As String

            'ASIGNING VALUE OF THE SELECTED CELL TO THE VARABLE intcount
            intcount = DataGridView1.CurrentCell.Value
            frmDebtor.txtDebtorTypeID.Text = intcount
            frmDebtor.Show()
            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "INSERT INTO T_DebtorType (Description) VALUES (@descr)"
            Dim allochange As New OleDb.OleDbParameter("@descr", txtdescription.Text)
            sqlcomm.Parameters.Add(allochange)
            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            connectToDB()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub txtIDalloc_MouseEnter(sender As Object, e As EventArgs) Handles txtsearchbyid.MouseEnter
        txtsearchbyid.Clear()
    End Sub

    Private Sub txtdesc_MouseEnter(sender As Object, e As EventArgs) Handles txtdesc.MouseEnter
        txtdesc.Clear()
    End Sub

    Private Sub btnsearch1_Click(sender As Object, e As EventArgs) Handles btnsearch1.Click
        cSearchID()
    End Sub

    Private Sub btnsearch2_Click(sender As Object, e As EventArgs) Handles btnsearch2.Click
        cSearchDesc()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtDebtorTypeID.Clear()
        txtdescription.Clear()

    End Sub

    Private Sub frmDebtorType_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connectToDB()
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmNavigation.Show()
        Me.Close()
    End Sub
End Class