﻿Imports System.Data.OleDb
Public Class frmCompany

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb")

    Private Sub bind_data()
        Try
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_Company", conn)
            Dim dataAda As New OleDbDataAdapter
            dataAda.SelectCommand = cmd1

            Dim table2 As New DataTable
            table2.Clear()
            dataAda.Fill(table2)

            DataGridView1.DataSource = table2
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Private Sub frmCompany_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        bind_data()
    End Sub

    Private Sub btnAddCompany_Click(sender As Object, e As EventArgs) Handles btnAddCompany.Click

        Try
            'add company
            Dim strsql As String
            strsql = "INSERT INTO T_Company(CompanyID,CompanyName) Values(@Cid,@Cname)"
            Dim cmd2 As New OleDbCommand(strsql, conn)

            cmd2.Parameters.AddWithValue("@Cid", Val(txtcompanyID.Text))
            cmd2.Parameters.AddWithValue("@Cname", txtCompanyName.Text)

            conn.Open()
            cmd2.ExecuteNonQuery()
            conn.Close()
            bind_data()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub txtcoIDsearch_TextChanged(sender As Object, e As EventArgs) Handles txtcoIDsearch.TextChanged


        Try
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_Company where CompanyID like '%'+ @parm1 + '%'", conn)
            cmd1.Parameters.AddWithValue("@parm1", txtcoIDsearch.Text)
            Dim da As New OleDbDataAdapter
            da.SelectCommand = cmd1

            Dim table1 As New DataTable
            table1.Clear()
            da.Fill(table1)

            DataGridView1.DataSource = table1
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try 'search by company id

    End Sub

    Private Sub txtcoNamesearch_TextChanged(sender As Object, e As EventArgs) Handles txtcoNamesearch.TextChanged

        Try
            'search by company name
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_Company where CompanyName like '%'+ @parm1 + '%'", conn)
            cmd1.Parameters.AddWithValue("@parm1", txtcoNamesearch.Text)
            Dim da As New OleDbDataAdapter
            da.SelectCommand = cmd1

            Dim table1 As New DataTable
            table1.Clear()
            da.Fill(table1)

            DataGridView1.DataSource = table1
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            Dim intcount As String

            'ASIGNING VALUE OF THE SELECTED/CLICKED CELL TO THE VARABLE intcount
            intcount = DataGridView1.CurrentCell.Value
            frmDepartment.txtsearchcompanyid.Text = intcount
            frmDepartment.Show()
            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmNavigation.Show()
        Me.Close()
    End Sub
End Class