﻿Imports System.Data.OleDb
Public Class frmDebtorBankAccount
    Public IDKey As Long
    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb")

    Public Sub searchupdate()
        Try
            Dim connection As New OleDb.OleDbConnection
            Dim table As New DataTable
            Dim sqlcommand As New OleDb.OleDbCommand
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            connection.Open()
            sqlcommand.Connection = connection
            sqlcommand.CommandText = "SELECT* FROM T_DebtorBankAcc WHERE Debtor_Id = @CustID AND D_BankAccount=@bank"
            Dim pdebtorD As New OleDb.OleDbParameter("@CustID", Val(txtDebtorID.Text))
            Dim pbankID As New OleDb.OleDbParameter("@bank", Val(txtBankAcc.Text))
            sqlcommand.Parameters.Add(pdebtorD)
            sqlcommand.Parameters.Add(pbankID)
            table.Load(sqlcommand.ExecuteReader)
            DataGridView1.DataSource = table
            connection.Close()

        Catch ex As Exception

        End Try

    End Sub

    Public Sub searchbankacc()
        Try
            Dim connection As New OleDb.OleDbConnection
            Dim table As New DataTable
            Dim sqlcommand As New OleDb.OleDbCommand
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            connection.Open()
            sqlcommand.Connection = connection
            sqlcommand.CommandText = "SELECT* FROM T_DebtorBankAcc WHERE  D_BankAccount=@CustID"
            Dim pCustomerID As New OleDb.OleDbParameter("@CustID", Val(txtBankAcc.Text))
            sqlcommand.Parameters.Add(pCustomerID)
            table.Load(sqlcommand.ExecuteReader)
            DataGridView1.DataSource = table
            connection.Close()
        Catch ex As Exception

        End Try

    End Sub
    Private Sub bind_data()

        Dim cmd1 As New OleDbCommand("SELECT * FROM T_Debtors", conn)
        Dim dataAda As New OleDbDataAdapter
        dataAda.SelectCommand = cmd1

        Dim table2 As New DataTable
        table2.Clear()
        dataAda.Fill(table2)
    End Sub

    Private Sub frmDebtorBankAccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        bind_data()
    End Sub


    Private Sub btnSearchDebtorID_Click(sender As Object, e As EventArgs)
        frmDebtor.Show()
        Me.Hide()

    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try
            Dim connection As New OleDb.OleDbConnection
            Dim table As New DataTable
            Dim sqlcommand As New OleDb.OleDbCommand
            connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            connection.Open()
            sqlcommand.Connection = connection
            sqlcommand.CommandText = "SELECT* FROM T_DebtorBankAcc WHERE Debtor_Id = @CustID"
            Dim pCustomerID As New OleDb.OleDbParameter("@CustID", Val(txtDebtorID.Text))
            sqlcommand.Parameters.Add(pCustomerID)
            table.Load(sqlcommand.ExecuteReader)
            connection.Close()

            txtBankAcc.Text = table.Rows(0)("D_BankAccount")
            txtDebtorID.Text = table.Rows(0)("Debtor_Id")
            txtBankName.Text = table.Rows(0)("D_BankName")
            txtBranchName.Text = table.Rows(0)("D_BranchName")
            txtBranchCode.Text = table.Rows(0)("D_BranchCode")
            cmbAccType.Text = table.Rows(0)("D_AccType")
            txtBankStatus.Text = table.Rows(0)("D_BankStatus")



        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            Dim strsql As String
            strsql = "INSERT INTO T_DebtorBankAcc(D_BankAccount,Debtor_Id,D_BankName,D_BranchName,D_BranchCode,D_AccType,D_BankStatus) Values(@bank,@debt,@bname,@brname,brcode,@atype,@status)"
            Dim cmd2 As New OleDbCommand(strsql, conn)

            cmd2.Parameters.AddWithValue("@bank", txtBankAcc.Text)
            cmd2.Parameters.AddWithValue("@debt", txtDebtorID.Text)
            cmd2.Parameters.AddWithValue("@bname", txtBankName.Text)
            cmd2.Parameters.AddWithValue("@brname", txtBranchName.Text)
            cmd2.Parameters.AddWithValue("@brcode", txtBranchCode.Text)
            cmd2.Parameters.AddWithValue("@atype", cmbAccType.Text)
            cmd2.Parameters.AddWithValue("@status", txtBankStatus.Text)

            conn.Open()
            cmd2.ExecuteNonQuery()
            conn.Close()
            bind_data()
            MsgBox("Record saved successfully")

            'refresh the preview of live database table data
            searchbankacc()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            'update sql statement
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()

            sqlcomm.Connection = cn
            sqlcomm.CommandText = "UPDATE T_DebtorBankAcc SET Debtor_Id=@debt1,D_BankName=@bank,D_BranchName=@brname,D_BranchCode=@bcode,D_AccType=@atype,D_BankStatus=@actve WHERE D_BankAccount=@IDKey"


            'must be first in this group of items

            Dim acc As New OleDb.OleDbParameter("@IDKey", Val(txtBankAcc.Text))
            'IDN for id number
            Dim debt As New OleDb.OleDbParameter("@debt1", Val(txtDebtorID.Text))

            Dim bank1 As New OleDb.OleDbParameter("bank", txtBankName.Text)
            Dim branch As New OleDb.OleDbParameter("brname", txtBranchName.Text)
            Dim bcode As New OleDb.OleDbParameter("bcode", Val(txtBranchCode.Text))
            Dim atype As New OleDb.OleDbParameter("atype", cmbAccType.Text)
            Dim status1 As New OleDb.OleDbParameter("actve", txtBankStatus.Text)



            'userid/code must be last in this list
            sqlcomm.Parameters.Add(debt)
            sqlcomm.Parameters.Add(bank1)
            sqlcomm.Parameters.Add(branch)
            sqlcomm.Parameters.Add(bcode)
            sqlcomm.Parameters.Add(atype)
            sqlcomm.Parameters.Add(status1)


            'f

            'this must be last or it won't work
            sqlcomm.Parameters.Add(acc)



            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            searchbankacc()

            'freeze the first column of the datagrid to avoid confusion as the table has a scroll functionality And a lot of fields/columns

            DataGridView1.Columns("D_BankAccount").Frozen = True
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub txtDebtorID_MouseDown(sender As Object, e As MouseEventArgs) Handles txtDebtorID.MouseDown
        txtDebtorID.Clear()
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmNavigation.Show()
        Me.Close()
    End Sub

    Private Sub grbBankAcc_Enter(sender As Object, e As EventArgs) Handles grbBankAcc.Enter

    End Sub
End Class