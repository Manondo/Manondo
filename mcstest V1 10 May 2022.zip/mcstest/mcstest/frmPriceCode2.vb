﻿Imports System.Data.OleDb
Imports System.Math
Public Class frmPriceCode2
    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb")
    Public IDKey As Long


    'the index of the row selected will be stored in this variable and passed to the pricecoderesourcing form
    Public Property IndxCurrent As Integer
    Public Property IndxCurrent2 As String
    Public Property IndxCurrent3 As String

    Public Property IndxCurrent4 As String

    Public Property selectedrow1 As Integer = -1



    'Sub to calculate the netrate and write it back to the Datagridview on Bill
    Public Sub getBillNetRate()

        'get current selected row of datagrid on pricecode form

        Dim selectedvalue As Integer = DataGridView1.CurrentCell.Value

        txtpricecode.Text = Val(selectedvalue)


        Try
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_PriceCodeResourcing where BillPriceCode like '%'+ @parm1 + '%'", conn)
            cmd1.Parameters.AddWithValue("@parm1", txtpricecode.Text)
            Dim da As New OleDbDataAdapter
            da.SelectCommand = cmd1

            Dim table2 As New DataTable
            table2.Clear()
            da.Fill(table2)

            Dim sum As Decimal = 0

            'this array goes through the values in the data table
            'executing the processing below to calculate the sum

            For i As Integer = 0 To table2.Rows.Count - 1

                sum = (Val(table2.Rows(i)("PriceCodeResourceRate"))) + sum

            Next

            '========the code will be used to keep rate up to date on the new price code resourcing form
            frmBill.txtPriceCodeResourcingRate.Text = sum

            'get current selected row
            Dim selectedrow1 As Integer = frmBill.DataGridView2.CurrentRow.Index

            'assigning default value of 1 to avoid divide by zero errors / dbnull errors

            'frmBill.DataGridView2.Rows(selectedrow1).Cells(3).Value = 2

            Dim billQty1 As Decimal = frmBill.DataGridView2.Rows(selectedrow1).Cells(3).Value


            'writing the value to the selling rate/selling amount cell on the DG
            frmBill.DataGridView2.Rows(selectedrow1).Cells(4).Value = Round((sum / billQty1), 2)


            'call description sub procedure to fill bill description text box on price code form with the appropriate description
            getDescription()

            DataGridView1.DataSource = table2
            bind_data()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    'this sub procedure gets the bill code description from price code table and displays in bill description textbox on price code form
    Public Sub getDescription()
        Dim cmd1 As New OleDbCommand("SELECT * FROM T_PriceCode where BillPriceCode like '%'+ @parm1 + '%'", conn)
        cmd1.Parameters.AddWithValue("@parm1", txtpricecode.Text)
        Dim da As New OleDbDataAdapter
        da.SelectCommand = cmd1

        Dim table2 As New DataTable
        table2.Clear()
        da.Fill(table2)

        txtdesc.Text = table2.Rows(0)("BillPriceCodeDescription")
    End Sub


    'calculate the sum of resource rates in the pricecoderesourcing table by bill code
    Public Sub getBillPriceRate()
        Try
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_PriceCodeResourcing where BillPriceCode like '%'+ @parm1 + '%'", conn)
            cmd1.Parameters.AddWithValue("@parm1", txtpricecode.Text)
            Dim da As New OleDbDataAdapter
            da.SelectCommand = cmd1

            Dim table2 As New DataTable
            table2.Clear()
            da.Fill(table2)

            Dim sum As Decimal = 0

            'this array goes through the values in the data table
            'executing the processing below to calculate the sum

            For i As Integer = 0 To table2.Rows.Count - 1
                sum = (Val(table2.Rows(i)("PriceCodeResourceRate")) + sum)

            Next

            'get current selected row
            Dim selectedrow1 As Integer = frmBill.DataGridView2.CurrentRow.Index


            'writing the value to the selling rate/selling amount cell on the DG
            ' frmBill.DataGridView2.Rows(selectedrow1).Cells(5).Value = sum


            'call description sub procedure to fill bill description text box on price code form with the appropriate description
            getDescription()

            txtpricerate.Text = sum



            DataGridView1.DataSource = table2
            bind_data()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub bind_data()
        Try


            Dim cmd1 As New OleDbCommand("SELECT * FROM T_PriceCode", conn)
            Dim dataAda As New OleDbDataAdapter
            dataAda.SelectCommand = cmd1

            Dim table2 As New DataTable
            table2.Clear()
            dataAda.Fill(table2)

            DataGridView1.DataSource = table2
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub






    Private Sub frmPriceCode_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        bind_data()
        DataGridView1.ClearSelection()

    End Sub

    Private Sub btnIDsearch_Click(sender As Object, e As EventArgs)
        'Try
        '    Dim cmd1 As New OleDbCommand("SELECT * FROM T_PriceCode where BillPriceCode like '%'+ @parm1 + '%'", conn)
        '    cmd1.Parameters.AddWithValue("@parm1", txtID.Text)
        '    Dim da As New OleDbDataAdapter
        '    da.SelectCommand = cmd1

        '    Dim table1 As New DataTable
        '    table1.Clear()
        '    da.Fill(table1)

        '    DataGridView1.DataSource = table1
        'Catch ex As Exception
        '    MsgBox(ex.Message)
        'End Try 'search by price code
    End Sub



    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            'add 
            Dim strsql As String
            strsql = "INSERT INTO T_PriceCode(BillPriceCode,BillPriceCodeDescription,BillPriceCodeUnit,BillPriceCodeRate) Values(@BPC,@BPD,@BPU,@BPR)"
            Dim cmd2 As New OleDbCommand(strsql, conn)

            cmd2.Parameters.AddWithValue("@BPC", Val(txtpricecode.Text))
            cmd2.Parameters.AddWithValue("@BPD", txtdesc.Text)
            cmd2.Parameters.AddWithValue("@BPU", txtUnit.Text)
            cmd2.Parameters.AddWithValue("@BPR", Val(txtpricerate.Text))


            conn.Open()
            cmd2.ExecuteNonQuery()
            conn.Close()

            bind_data()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles BtnClear.Click
        'clear all textboxes
        Try

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Dim txt As Control
        For Each txt In Controls
            If TypeOf txt Is TextBox Then
                txt.Text = ""
            End If
        Next
    End Sub


    Private Sub txtpricecode_TextChanged(sender As Object, e As EventArgs) Handles txtpricecode.TextChanged
        'after user types in billpricecode it fetches the billpricerate and displays in the bill price rate textbox
        txtpricerate.Enabled = True

        getBillPriceRate()

    End Sub

    Private Sub frmPriceCode_MouseEnter(sender As Object, e As EventArgs) Handles MyBase.MouseEnter
        'the table doesn't update immediately, so I'm forcing an update
        bind_data()
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmNavigation.Show()
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        Dim header1 As Integer = DataGridView1.CurrentCell.ColumnIndex




        If header1 = 0 Then
            Try
                Dim Valueselected As String

                'get current selected row
                Dim selectedrow2 As Integer = frmBill.DataGridView2.CurrentRow.Index


                'WRITING BACK THE SELECTED PRICE CODE VALUE FROM THE DATAGRID ON THE PRICE CODE FORM TO THE BILL
                Valueselected = DataGridView1.CurrentCell.Value

                frmBill.DataGridView2.Rows(selectedrow2).Cells(9).Value = Valueselected

                getBillNetRate()
                Me.Close()
                frmBill.Show()


                Me.Hide()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        ElseIf header1 = 3 Then


            'get current selected row
            selectedrow1 = Me.DataGridView1.CurrentRow.Index
            IndxCurrent = Me.DataGridView1.Rows(selectedrow1).Cells(0).Value
            IndxCurrent2 = Me.DataGridView1.Rows(selectedrow1).Cells(1).Value
            IndxCurrent3 = Me.DataGridView1.Rows(selectedrow1).Cells(2).Value
            IndxCurrent4 = Me.DataGridView1.Rows(selectedrow1).Cells(3).Value


            Me.Hide()

            MsgBox(IndxCurrent)
            frmPriceCodeResourcing.txtbillcode.Text = IndxCurrent
            frmPriceCodeResourcing.cSearchBillID()
            frmPriceCodeResourcing.Show()
        End If

    End Sub

    Private Sub frmPriceCode_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown


    End Sub

    Private Sub DataGridView1_MouseHover(sender As Object, e As EventArgs) Handles DataGridView1.MouseHover

        'when price code loads again it will automatically select the 'bill code that was priced' row
        If selectedrow1 < 0 Then
            DataGridView1.ClearSelection()
        Else
            'this highlights the bill price code row that's currently being priced.
            DataGridView1.ClearSelection()
            DataGridView1.Rows(selectedrow1).DefaultCellStyle.BackColor = Color.CornflowerBlue

            'in addition, the focus is sent to that row also.
            DataGridView1.Rows(selectedrow1).Cells(0).Selected = True
            DataGridView1.Select()


        End If

    End Sub

    Private Sub DataGridView1_CellMouseEnter(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellMouseEnter
        If selectedrow1 < 0 Then
            DataGridView1.ClearSelection()
        Else

            DataGridView1.Rows(selectedrow1).DefaultCellStyle.BackColor = Color.CornflowerBlue

        End If
    End Sub

    Private Sub DataGridView1_CellMouseLeave(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellMouseLeave
        If selectedrow1 < 0 Then
            DataGridView1.ClearSelection()
        Else

            DataGridView1.Rows(selectedrow1).DefaultCellStyle.BackColor = Color.CornflowerBlue

        End If
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        Try
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_PriceCode where BillPriceCodeDescription like '%'+ @parm1 + '%'", conn)
            cmd1.Parameters.AddWithValue("@parm1", txtSearch.Text)
            Dim da As New OleDbDataAdapter
            da.SelectCommand = cmd1

            Dim table1 As New DataTable
            table1.Clear()
            da.Fill(table1)

            DataGridView1.DataSource = table1
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try 'search by  description
    End Sub
End Class