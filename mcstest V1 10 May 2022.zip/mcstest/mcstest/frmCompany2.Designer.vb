﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCompany2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtcoNamesearch = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtcoIDsearch = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnAddCompany = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.txtCompanyName = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtcompanyID = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnHome = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtcoNamesearch
        '
        Me.txtcoNamesearch.Location = New System.Drawing.Point(472, 11)
        Me.txtcoNamesearch.Name = "txtcoNamesearch"
        Me.txtcoNamesearch.Size = New System.Drawing.Size(109, 20)
        Me.txtcoNamesearch.TabIndex = 134
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(333, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(133, 13)
        Me.Label2.TabIndex = 133
        Me.Label2.Text = "Search by Company Name"
        '
        'txtcoIDsearch
        '
        Me.txtcoIDsearch.Location = New System.Drawing.Point(127, 8)
        Me.txtcoIDsearch.Name = "txtcoIDsearch"
        Me.txtcoIDsearch.Size = New System.Drawing.Size(100, 20)
        Me.txtcoIDsearch.TabIndex = 132
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(116, 13)
        Me.Label1.TabIndex = 131
        Me.Label1.Text = "Search by Company ID"
        '
        'btnAddCompany
        '
        Me.btnAddCompany.Location = New System.Drawing.Point(701, 135)
        Me.btnAddCompany.Name = "btnAddCompany"
        Me.btnAddCompany.Size = New System.Drawing.Size(100, 23)
        Me.btnAddCompany.TabIndex = 130
        Me.btnAddCompany.Text = "Add Company"
        Me.btnAddCompany.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(-1, 40)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(582, 265)
        Me.DataGridView1.TabIndex = 129
        '
        'txtCompanyName
        '
        Me.txtCompanyName.Location = New System.Drawing.Point(701, 84)
        Me.txtCompanyName.Name = "txtCompanyName"
        Me.txtCompanyName.Size = New System.Drawing.Size(100, 20)
        Me.txtCompanyName.TabIndex = 128
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(602, 91)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(82, 13)
        Me.Label7.TabIndex = 127
        Me.Label7.Text = "Company Name"
        '
        'txtcompanyID
        '
        Me.txtcompanyID.Location = New System.Drawing.Point(701, 47)
        Me.txtcompanyID.Name = "txtcompanyID"
        Me.txtcompanyID.Size = New System.Drawing.Size(100, 20)
        Me.txtcompanyID.TabIndex = 126
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(619, 54)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 13)
        Me.Label6.TabIndex = 125
        Me.Label6.Text = "Company ID"
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(726, 295)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 190
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'frmCompany2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(810, 330)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.txtcoNamesearch)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtcoIDsearch)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnAddCompany)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.txtCompanyName)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtcompanyID)
        Me.Controls.Add(Me.Label6)
        Me.Name = "frmCompany2"
        Me.Text = "COMPANY"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtcoNamesearch As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtcoIDsearch As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnAddCompany As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents txtCompanyName As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtcompanyID As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents btnHome As Button
End Class
