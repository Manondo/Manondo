﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmResourceType
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtRtypenew = New System.Windows.Forms.TextBox()
        Me.txtdesc = New System.Windows.Forms.TextBox()
        Me.txtRtype = New System.Windows.Forms.TextBox()
        Me.btnNewResourceType = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtRdescnew = New System.Windows.Forms.TextBox()
        Me.btnHome = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(12, 58)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(747, 305)
        Me.DataGridView1.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(131, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Enter new Resource Type"
        '
        'txtRtypenew
        '
        Me.txtRtypenew.Location = New System.Drawing.Point(9, 61)
        Me.txtRtypenew.Name = "txtRtypenew"
        Me.txtRtypenew.Size = New System.Drawing.Size(157, 20)
        Me.txtRtypenew.TabIndex = 10
        '
        'txtdesc
        '
        Me.txtdesc.Location = New System.Drawing.Point(519, 17)
        Me.txtdesc.Name = "txtdesc"
        Me.txtdesc.Size = New System.Drawing.Size(240, 20)
        Me.txtdesc.TabIndex = 15
        Me.txtdesc.Text = "Type Description to search"
        '
        'txtRtype
        '
        Me.txtRtype.Location = New System.Drawing.Point(12, 17)
        Me.txtRtype.Name = "txtRtype"
        Me.txtRtype.Size = New System.Drawing.Size(228, 20)
        Me.txtRtype.TabIndex = 14
        Me.txtRtype.Text = "Type ID to search"
        '
        'btnNewResourceType
        '
        Me.btnNewResourceType.Location = New System.Drawing.Point(17, 178)
        Me.btnNewResourceType.Name = "btnNewResourceType"
        Me.btnNewResourceType.Size = New System.Drawing.Size(165, 43)
        Me.btnNewResourceType.TabIndex = 7
        Me.btnNewResourceType.Text = "Add New Resource Type"
        Me.btnNewResourceType.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtRdescnew)
        Me.GroupBox1.Controls.Add(Me.btnNewResourceType)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtRtypenew)
        Me.GroupBox1.Location = New System.Drawing.Point(779, 79)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(188, 236)
        Me.GroupBox1.TabIndex = 16
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "ADD RESOURCE TYPE"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 107)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(160, 13)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Enter new Resource Description"
        '
        'txtRdescnew
        '
        Me.txtRdescnew.Location = New System.Drawing.Point(9, 132)
        Me.txtRdescnew.Name = "txtRdescnew"
        Me.txtRdescnew.Size = New System.Drawing.Size(157, 20)
        Me.txtRdescnew.TabIndex = 12
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(902, 349)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 190
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'frmResourceType
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(980, 384)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.txtdesc)
        Me.Controls.Add(Me.txtRtype)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmResourceType"
        Me.Text = "RESOURCE TYPE"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents txtRtypenew As TextBox
    Friend WithEvents txtdesc As TextBox
    Friend WithEvents txtRtype As TextBox
    Friend WithEvents btnNewResourceType As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtRdescnew As TextBox
    Friend WithEvents btnHome As Button
End Class
