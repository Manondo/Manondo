﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCLASSIFICATION
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnsearchallocations = New System.Windows.Forms.Button()
        Me.txtallocID = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtAddID = New System.Windows.Forms.TextBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.txtClassDesc = New System.Windows.Forms.TextBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtAddClass = New System.Windows.Forms.TextBox()
        Me.lblAdd = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnHome = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnsearchallocations
        '
        Me.btnsearchallocations.Location = New System.Drawing.Point(6, 207)
        Me.btnsearchallocations.Name = "btnsearchallocations"
        Me.btnsearchallocations.Size = New System.Drawing.Size(210, 23)
        Me.btnsearchallocations.TabIndex = 21
        Me.btnsearchallocations.Text = "Search Allocation ID"
        Me.btnsearchallocations.UseVisualStyleBackColor = True
        '
        'txtallocID
        '
        Me.txtallocID.Location = New System.Drawing.Point(6, 181)
        Me.txtallocID.Name = "txtallocID"
        Me.txtallocID.Size = New System.Drawing.Size(210, 20)
        Me.txtallocID.TabIndex = 20
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 156)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "ENTER ALLOCATION ID"
        '
        'txtAddID
        '
        Me.txtAddID.Location = New System.Drawing.Point(6, 105)
        Me.txtAddID.Name = "txtAddID"
        Me.txtAddID.Size = New System.Drawing.Size(210, 20)
        Me.txtAddID.TabIndex = 18
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Location = New System.Drawing.Point(3, 89)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(147, 13)
        Me.lblID.TabIndex = 17
        Me.lblID.Text = "ENTER CLASSIFICATION ID"
        '
        'txtClassDesc
        '
        Me.txtClassDesc.Location = New System.Drawing.Point(382, 16)
        Me.txtClassDesc.Name = "txtClassDesc"
        Me.txtClassDesc.Size = New System.Drawing.Size(224, 20)
        Me.txtClassDesc.TabIndex = 16
        Me.txtClassDesc.Text = "Insert Description to search"
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(12, 16)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(227, 20)
        Me.txtID.TabIndex = 15
        Me.txtID.Text = "Insert ID to search"
        '
        'txtAddClass
        '
        Me.txtAddClass.Location = New System.Drawing.Point(6, 49)
        Me.txtAddClass.Name = "txtAddClass"
        Me.txtAddClass.Size = New System.Drawing.Size(210, 20)
        Me.txtAddClass.TabIndex = 14
        '
        'lblAdd
        '
        Me.lblAdd.AutoSize = True
        Me.lblAdd.Location = New System.Drawing.Point(6, 33)
        Me.lblAdd.Name = "lblAdd"
        Me.lblAdd.Size = New System.Drawing.Size(238, 13)
        Me.lblAdd.TabIndex = 13
        Me.lblAdd.Text = "ENTER NEW CLASSIFICATION DESCRIPTION"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(9, 241)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(207, 42)
        Me.btnAdd.TabIndex = 12
        Me.btnAdd.Text = "ADD CLASSIFICATION ITEM"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(12, 58)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(594, 283)
        Me.DataGridView1.TabIndex = 11
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnsearchallocations)
        Me.GroupBox1.Controls.Add(Me.lblAdd)
        Me.GroupBox1.Controls.Add(Me.txtallocID)
        Me.GroupBox1.Controls.Add(Me.btnAdd)
        Me.GroupBox1.Controls.Add(Me.txtAddClass)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.lblID)
        Me.GroupBox1.Controls.Add(Me.txtAddID)
        Me.GroupBox1.Location = New System.Drawing.Point(692, 58)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(257, 289)
        Me.GroupBox1.TabIndex = 22
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "ADD CLASSIFICATION"
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(918, 344)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 190
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'frmCLASSIFICATION
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(995, 368)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtClassDesc)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "frmCLASSIFICATION"
        Me.Text = "CLASSIFICATION"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnsearchallocations As Button
    Friend WithEvents txtallocID As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtAddID As TextBox
    Friend WithEvents lblID As Label
    Friend WithEvents txtClassDesc As TextBox
    Friend WithEvents txtID As TextBox
    Friend WithEvents txtAddClass As TextBox
    Friend WithEvents lblAdd As Label
    Friend WithEvents btnAdd As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnHome As Button
End Class
