﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCost_Codes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.btnsearchclassifications = New System.Windows.Forms.Button()
        Me.lblclassi = New System.Windows.Forms.Label()
        Me.txtClassiID = New System.Windows.Forms.TextBox()
        Me.txtcodeID = New System.Windows.Forms.TextBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.txtCostDesc = New System.Windows.Forms.TextBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtcodedescrip = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lblAdd = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnHome = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(245, 181)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(168, 32)
        Me.Button1.TabIndex = 36
        Me.Button1.Text = "Update Cost Code Status"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Active", "Locked"})
        Me.ComboBox1.Location = New System.Drawing.Point(229, 91)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(184, 21)
        Me.ComboBox1.TabIndex = 35
        '
        'btnsearchclassifications
        '
        Me.btnsearchclassifications.Location = New System.Drawing.Point(299, 121)
        Me.btnsearchclassifications.Name = "btnsearchclassifications"
        Me.btnsearchclassifications.Size = New System.Drawing.Size(114, 23)
        Me.btnsearchclassifications.TabIndex = 34
        Me.btnsearchclassifications.Text = "Search Classification ID"
        Me.btnsearchclassifications.UseVisualStyleBackColor = True
        '
        'lblclassi
        '
        Me.lblclassi.AutoSize = True
        Me.lblclassi.Location = New System.Drawing.Point(61, 127)
        Me.lblclassi.Name = "lblclassi"
        Me.lblclassi.Size = New System.Drawing.Size(147, 13)
        Me.lblclassi.TabIndex = 32
        Me.lblclassi.Text = "ENTER CLASSIFICATION ID"
        '
        'txtClassiID
        '
        Me.txtClassiID.Location = New System.Drawing.Point(229, 124)
        Me.txtClassiID.Name = "txtClassiID"
        Me.txtClassiID.Size = New System.Drawing.Size(64, 20)
        Me.txtClassiID.TabIndex = 33
        '
        'txtcodeID
        '
        Me.txtcodeID.Location = New System.Drawing.Point(229, 22)
        Me.txtcodeID.Name = "txtcodeID"
        Me.txtcodeID.Size = New System.Drawing.Size(184, 20)
        Me.txtcodeID.TabIndex = 31
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Location = New System.Drawing.Point(99, 29)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(109, 13)
        Me.lblID.TabIndex = 30
        Me.lblID.Text = "ENTER COST CODE"
        '
        'txtCostDesc
        '
        Me.txtCostDesc.Location = New System.Drawing.Point(318, 19)
        Me.txtCostDesc.Name = "txtCostDesc"
        Me.txtCostDesc.Size = New System.Drawing.Size(224, 20)
        Me.txtCostDesc.TabIndex = 29
        Me.txtCostDesc.Text = "Insert Description to search"
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(12, 19)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(227, 20)
        Me.txtID.TabIndex = 28
        Me.txtID.Text = "Insert ID to search"
        '
        'txtcodedescrip
        '
        Me.txtcodedescrip.Location = New System.Drawing.Point(229, 52)
        Me.txtcodedescrip.Name = "txtcodedescrip"
        Me.txtcodedescrip.Size = New System.Drawing.Size(184, 20)
        Me.txtcodedescrip.TabIndex = 27
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(6, 181)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(214, 32)
        Me.btnAdd.TabIndex = 25
        Me.btnAdd.Text = "ADD COST CODE ITEM"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'lblAdd
        '
        Me.lblAdd.AutoSize = True
        Me.lblAdd.Location = New System.Drawing.Point(23, 55)
        Me.lblAdd.Name = "lblAdd"
        Me.lblAdd.Size = New System.Drawing.Size(185, 13)
        Me.lblAdd.TabIndex = 26
        Me.lblAdd.Text = "ENTER COST CODE DESCRIPTION"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(12, 61)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(530, 205)
        Me.DataGridView1.TabIndex = 24
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.lblID)
        Me.GroupBox1.Controls.Add(Me.btnsearchclassifications)
        Me.GroupBox1.Controls.Add(Me.txtcodeID)
        Me.GroupBox1.Controls.Add(Me.btnAdd)
        Me.GroupBox1.Controls.Add(Me.txtClassiID)
        Me.GroupBox1.Controls.Add(Me.lblclassi)
        Me.GroupBox1.Controls.Add(Me.ComboBox1)
        Me.GroupBox1.Controls.Add(Me.lblAdd)
        Me.GroupBox1.Controls.Add(Me.txtcodedescrip)
        Me.GroupBox1.Location = New System.Drawing.Point(577, 47)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(419, 219)
        Me.GroupBox1.TabIndex = 37
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "ADD COST CODE ITEM"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(49, 94)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(159, 13)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "SELECT COST CODE STATUS"
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(930, 282)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 190
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'frmCost_Codes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1008, 305)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtCostDesc)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "frmCost_Codes"
        Me.Text = "COST-CODES"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents btnsearchclassifications As Button
    Friend WithEvents lblclassi As Label
    Friend WithEvents txtClassiID As TextBox
    Friend WithEvents txtcodeID As TextBox
    Friend WithEvents lblID As Label
    Friend WithEvents txtCostDesc As TextBox
    Friend WithEvents txtID As TextBox
    Friend WithEvents txtcodedescrip As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents lblAdd As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnHome As Button
End Class
