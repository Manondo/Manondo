﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDatePickerStart
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSubmitStartDate = New System.Windows.Forms.Button()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.SuspendLayout()
        '
        'btnSubmitStartDate
        '
        Me.btnSubmitStartDate.Location = New System.Drawing.Point(145, 51)
        Me.btnSubmitStartDate.Name = "btnSubmitStartDate"
        Me.btnSubmitStartDate.Size = New System.Drawing.Size(164, 23)
        Me.btnSubmitStartDate.TabIndex = 4
        Me.btnSubmitStartDate.Text = "Submit"
        Me.btnSubmitStartDate.UseVisualStyleBackColor = True
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(12, 25)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(301, 20)
        Me.DateTimePicker1.TabIndex = 3
        '
        'frmDatePickerStart
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(324, 83)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnSubmitStartDate)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Name = "frmDatePickerStart"
        Me.Text = "START DATE"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnSubmitStartDate As Button
    Friend WithEvents DateTimePicker1 As DateTimePicker
End Class
