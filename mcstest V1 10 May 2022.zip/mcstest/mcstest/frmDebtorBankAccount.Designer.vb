﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDebtorBankAccount
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtBranchCode = New System.Windows.Forms.TextBox()
        Me.txtBankAcc = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtBranchName = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtBankName = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grbBankAcc = New System.Windows.Forms.GroupBox()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.txtDebtorID = New System.Windows.Forms.TextBox()
        Me.cmbAccType = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtBankStatus = New System.Windows.Forms.TextBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.grbBankAcc.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtBranchCode
        '
        Me.txtBranchCode.Location = New System.Drawing.Point(212, 260)
        Me.txtBranchCode.Name = "txtBranchCode"
        Me.txtBranchCode.Size = New System.Drawing.Size(130, 20)
        Me.txtBranchCode.TabIndex = 260
        '
        'txtBankAcc
        '
        Me.txtBankAcc.Location = New System.Drawing.Point(212, 79)
        Me.txtBankAcc.Name = "txtBankAcc"
        Me.txtBankAcc.Size = New System.Drawing.Size(130, 20)
        Me.txtBankAcc.TabIndex = 259
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(68, 83)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(75, 13)
        Me.Label19.TabIndex = 258
        Me.Label19.Text = "Bank Account"
        '
        'txtBranchName
        '
        Me.txtBranchName.Location = New System.Drawing.Point(212, 195)
        Me.txtBranchName.Name = "txtBranchName"
        Me.txtBranchName.Size = New System.Drawing.Size(130, 20)
        Me.txtBranchName.TabIndex = 257
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(68, 264)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(69, 13)
        Me.Label12.TabIndex = 256
        Me.Label12.Text = "Branch Code"
        '
        'txtBankName
        '
        Me.txtBankName.Location = New System.Drawing.Point(212, 139)
        Me.txtBankName.Name = "txtBankName"
        Me.txtBankName.Size = New System.Drawing.Size(130, 20)
        Me.txtBankName.TabIndex = 255
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(68, 199)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 13)
        Me.Label14.TabIndex = 254
        Me.Label14.Text = "Branch Name"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(69, 320)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(74, 13)
        Me.Label7.TabIndex = 253
        Me.Label7.Text = "Account Type"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(68, 143)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 13)
        Me.Label1.TabIndex = 251
        Me.Label1.Text = "Bank Name"
        '
        'grbBankAcc
        '
        Me.grbBankAcc.Controls.Add(Me.btnsearch)
        Me.grbBankAcc.Controls.Add(Me.txtDebtorID)
        Me.grbBankAcc.Controls.Add(Me.cmbAccType)
        Me.grbBankAcc.Controls.Add(Me.txtBranchCode)
        Me.grbBankAcc.Controls.Add(Me.txtBankAcc)
        Me.grbBankAcc.Controls.Add(Me.Label19)
        Me.grbBankAcc.Controls.Add(Me.txtBranchName)
        Me.grbBankAcc.Controls.Add(Me.Label12)
        Me.grbBankAcc.Controls.Add(Me.txtBankName)
        Me.grbBankAcc.Controls.Add(Me.Label14)
        Me.grbBankAcc.Controls.Add(Me.Label2)
        Me.grbBankAcc.Controls.Add(Me.Label7)
        Me.grbBankAcc.Controls.Add(Me.txtBankStatus)
        Me.grbBankAcc.Controls.Add(Me.Label1)
        Me.grbBankAcc.Location = New System.Drawing.Point(38, 65)
        Me.grbBankAcc.Name = "grbBankAcc"
        Me.grbBankAcc.Size = New System.Drawing.Size(358, 429)
        Me.grbBankAcc.TabIndex = 265
        Me.grbBankAcc.TabStop = False
        Me.grbBankAcc.Text = "Bank Account"
        '
        'btnsearch
        '
        Me.btnsearch.Location = New System.Drawing.Point(71, 22)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(120, 23)
        Me.btnsearch.TabIndex = 333
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'txtDebtorID
        '
        Me.txtDebtorID.Location = New System.Drawing.Point(212, 22)
        Me.txtDebtorID.Name = "txtDebtorID"
        Me.txtDebtorID.Size = New System.Drawing.Size(130, 20)
        Me.txtDebtorID.TabIndex = 332
        Me.txtDebtorID.Text = "Enter Debtor Id to Search"
        '
        'cmbAccType
        '
        Me.cmbAccType.FormattingEnabled = True
        Me.cmbAccType.Items.AddRange(New Object() {"Check", "Saving", "Overdraft"})
        Me.cmbAccType.Location = New System.Drawing.Point(212, 316)
        Me.cmbAccType.Name = "cmbAccType"
        Me.cmbAccType.Size = New System.Drawing.Size(130, 21)
        Me.cmbAccType.TabIndex = 261
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(69, 376)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 13)
        Me.Label2.TabIndex = 253
        Me.Label2.Text = "Bank Status"
        '
        'txtBankStatus
        '
        Me.txtBankStatus.Location = New System.Drawing.Point(212, 372)
        Me.txtBankStatus.Name = "txtBankStatus"
        Me.txtBankStatus.Size = New System.Drawing.Size(133, 20)
        Me.txtBankStatus.TabIndex = 252
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(308, 539)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 268
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(181, 544)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(75, 23)
        Me.btnUpdate.TabIndex = 266
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(52, 544)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(75, 23)
        Me.btnSave.TabIndex = 267
        Me.btnSave.Text = "Add"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(402, 127)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(565, 367)
        Me.DataGridView1.TabIndex = 269
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(402, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(433, 31)
        Me.Label3.TabIndex = 334
        Me.Label3.Text = "PREVIEW ENTRIES, UPDATES"
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(890, 529)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 335
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'frmDebtorBankAccount
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(977, 574)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.grbBankAcc)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnSave)
        Me.Name = "frmDebtorBankAccount"
        Me.Text = "DEBTOR BANK ACCOUNT"
        Me.grbBankAcc.ResumeLayout(False)
        Me.grbBankAcc.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtBranchCode As TextBox
    Friend WithEvents txtBankAcc As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents txtBranchName As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txtBankName As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents grbBankAcc As GroupBox
    Friend WithEvents cmbAccType As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtBankStatus As TextBox
    Friend WithEvents btnClear As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents txtDebtorID As TextBox
    Friend WithEvents btnsearch As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label3 As Label
    Friend WithEvents btnHome As Button
End Class
