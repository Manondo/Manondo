﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDebtor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnBrowse = New System.Windows.Forms.Button()
        Me.txtDebtorID = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtDPostalAddress = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtDPhysicalAddress = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtTel1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtTel2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtTel3 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtFax1 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtFax2 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtWebsite = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtContactName = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtBEECertification = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtBEEClassification = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtCreditLimit = New System.Windows.Forms.TextBox()
        Me.dtpBEEEpiryDate = New System.Windows.Forms.DateTimePicker()
        Me.cmbBlackOwnership = New System.Windows.Forms.ComboBox()
        Me.cmbBEELevel = New System.Windows.Forms.ComboBox()
        Me.txtDebtorTypeID = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtDebtorName = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtDRegNumber = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtVATNumber = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.btnsearchid = New System.Windows.Forms.Button()
        Me.btnHome = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(12, 217)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(1136, 189)
        Me.DataGridView1.TabIndex = 0
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(437, 427)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(151, 30)
        Me.btnAdd.TabIndex = 1
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(629, 427)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(151, 30)
        Me.btnClear.TabIndex = 2
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(280, 427)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(151, 30)
        Me.btnDelete.TabIndex = 3
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(107, 427)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(151, 30)
        Me.btnUpdate.TabIndex = 4
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(44, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 13)
        Me.Label3.TabIndex = 133
        Me.Label3.Text = "Debtor ID"
        '
        'btnBrowse
        '
        Me.btnBrowse.Location = New System.Drawing.Point(786, 427)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(136, 30)
        Me.btnBrowse.TabIndex = 176
        Me.btnBrowse.Text = "Browse"
        Me.btnBrowse.UseVisualStyleBackColor = True
        '
        'txtDebtorID
        '
        Me.txtDebtorID.Location = New System.Drawing.Point(106, 12)
        Me.txtDebtorID.Name = "txtDebtorID"
        Me.txtDebtorID.Size = New System.Drawing.Size(116, 20)
        Me.txtDebtorID.TabIndex = 178
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(273, 15)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(82, 13)
        Me.Label12.TabIndex = 141
        Me.Label12.Text = "DPostalAddress"
        '
        'txtDPostalAddress
        '
        Me.txtDPostalAddress.Location = New System.Drawing.Point(364, 12)
        Me.txtDPostalAddress.Name = "txtDPostalAddress"
        Me.txtDPostalAddress.Size = New System.Drawing.Size(90, 20)
        Me.txtDPostalAddress.TabIndex = 142
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(263, 42)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(92, 13)
        Me.Label6.TabIndex = 143
        Me.Label6.Text = "DPhysicalAddress"
        '
        'txtDPhysicalAddress
        '
        Me.txtDPhysicalAddress.Location = New System.Drawing.Point(365, 39)
        Me.txtDPhysicalAddress.Name = "txtDPhysicalAddress"
        Me.txtDPhysicalAddress.Size = New System.Drawing.Size(90, 20)
        Me.txtDPhysicalAddress.TabIndex = 144
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(327, 72)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 13)
        Me.Label5.TabIndex = 145
        Me.Label5.Text = "Tel1"
        '
        'txtTel1
        '
        Me.txtTel1.Location = New System.Drawing.Point(365, 69)
        Me.txtTel1.Name = "txtTel1"
        Me.txtTel1.Size = New System.Drawing.Size(90, 20)
        Me.txtTel1.TabIndex = 146
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(327, 109)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 13)
        Me.Label4.TabIndex = 147
        Me.Label4.Text = "Tel2"
        '
        'txtTel2
        '
        Me.txtTel2.Location = New System.Drawing.Point(365, 106)
        Me.txtTel2.Name = "txtTel2"
        Me.txtTel2.Size = New System.Drawing.Size(90, 20)
        Me.txtTel2.TabIndex = 148
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(327, 140)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(28, 13)
        Me.Label2.TabIndex = 149
        Me.Label2.Text = "Tel3"
        '
        'txtTel3
        '
        Me.txtTel3.Location = New System.Drawing.Point(365, 137)
        Me.txtTel3.Name = "txtTel3"
        Me.txtTel3.Size = New System.Drawing.Size(90, 20)
        Me.txtTel3.TabIndex = 150
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(543, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 13)
        Me.Label1.TabIndex = 151
        Me.Label1.Text = "Fax1"
        '
        'txtFax1
        '
        Me.txtFax1.Location = New System.Drawing.Point(583, 9)
        Me.txtFax1.Name = "txtFax1"
        Me.txtFax1.Size = New System.Drawing.Size(90, 20)
        Me.txtFax1.TabIndex = 152
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(543, 46)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(30, 13)
        Me.Label11.TabIndex = 153
        Me.Label11.Text = "Fax2"
        '
        'txtFax2
        '
        Me.txtFax2.Location = New System.Drawing.Point(583, 43)
        Me.txtFax2.Name = "txtFax2"
        Me.txtFax2.Size = New System.Drawing.Size(90, 20)
        Me.txtFax2.TabIndex = 154
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(541, 76)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(32, 13)
        Me.Label10.TabIndex = 155
        Me.Label10.Text = "Email"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(583, 73)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(90, 20)
        Me.txtEmail.TabIndex = 156
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(531, 113)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(46, 13)
        Me.Label9.TabIndex = 157
        Me.Label9.Text = "Website"
        '
        'txtWebsite
        '
        Me.txtWebsite.Location = New System.Drawing.Point(583, 110)
        Me.txtWebsite.Name = "txtWebsite"
        Me.txtWebsite.Size = New System.Drawing.Size(90, 20)
        Me.txtWebsite.TabIndex = 158
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(502, 144)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(75, 13)
        Me.Label8.TabIndex = 159
        Me.Label8.Text = "Contact Name"
        '
        'txtContactName
        '
        Me.txtContactName.Location = New System.Drawing.Point(583, 141)
        Me.txtContactName.Name = "txtContactName"
        Me.txtContactName.Size = New System.Drawing.Size(90, 20)
        Me.txtContactName.TabIndex = 160
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(732, 15)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(83, 13)
        Me.Label7.TabIndex = 161
        Me.Label7.Text = "BEECertification"
        '
        'txtBEECertification
        '
        Me.txtBEECertification.Location = New System.Drawing.Point(821, 12)
        Me.txtBEECertification.Name = "txtBEECertification"
        Me.txtBEECertification.Size = New System.Drawing.Size(90, 20)
        Me.txtBEECertification.TabIndex = 162
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(737, 46)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(74, 13)
        Me.Label20.TabIndex = 163
        Me.Label20.Text = "BEEEpiryDate"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(757, 76)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(54, 13)
        Me.Label19.TabIndex = 165
        Me.Label19.Text = "BEELevel"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(726, 113)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(89, 13)
        Me.Label18.TabIndex = 167
        Me.Label18.Text = "BEEClassification"
        '
        'txtBEEClassification
        '
        Me.txtBEEClassification.Location = New System.Drawing.Point(821, 110)
        Me.txtBEEClassification.Name = "txtBEEClassification"
        Me.txtBEEClassification.Size = New System.Drawing.Size(90, 20)
        Me.txtBEEClassification.TabIndex = 168
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(731, 148)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(84, 13)
        Me.Label17.TabIndex = 169
        Me.Label17.Text = "BlackOwnership"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(940, 15)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(55, 13)
        Me.Label16.TabIndex = 171
        Me.Label16.Text = "CreditLimit"
        '
        'txtCreditLimit
        '
        Me.txtCreditLimit.Location = New System.Drawing.Point(1013, 12)
        Me.txtCreditLimit.Name = "txtCreditLimit"
        Me.txtCreditLimit.Size = New System.Drawing.Size(90, 20)
        Me.txtCreditLimit.TabIndex = 172
        '
        'dtpBEEEpiryDate
        '
        Me.dtpBEEEpiryDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpBEEEpiryDate.Location = New System.Drawing.Point(821, 43)
        Me.dtpBEEEpiryDate.Name = "dtpBEEEpiryDate"
        Me.dtpBEEEpiryDate.Size = New System.Drawing.Size(90, 20)
        Me.dtpBEEEpiryDate.TabIndex = 173
        '
        'cmbBlackOwnership
        '
        Me.cmbBlackOwnership.FormattingEnabled = True
        Me.cmbBlackOwnership.Items.AddRange(New Object() {"10", "20", "30", "40", "50", "60", "70", "80", "90", "100"})
        Me.cmbBlackOwnership.Location = New System.Drawing.Point(821, 144)
        Me.cmbBlackOwnership.Name = "cmbBlackOwnership"
        Me.cmbBlackOwnership.Size = New System.Drawing.Size(90, 21)
        Me.cmbBlackOwnership.TabIndex = 174
        '
        'cmbBEELevel
        '
        Me.cmbBEELevel.FormattingEnabled = True
        Me.cmbBEELevel.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "Non compliant contributor"})
        Me.cmbBEELevel.Location = New System.Drawing.Point(817, 76)
        Me.cmbBEELevel.Name = "cmbBEELevel"
        Me.cmbBEELevel.Size = New System.Drawing.Size(94, 21)
        Me.cmbBEELevel.TabIndex = 175
        '
        'txtDebtorTypeID
        '
        Me.txtDebtorTypeID.Location = New System.Drawing.Point(103, 43)
        Me.txtDebtorTypeID.Name = "txtDebtorTypeID"
        Me.txtDebtorTypeID.Size = New System.Drawing.Size(47, 20)
        Me.txtDebtorTypeID.TabIndex = 134
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(30, 76)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(67, 13)
        Me.Label15.TabIndex = 135
        Me.Label15.Text = "DebtorName"
        '
        'txtDebtorName
        '
        Me.txtDebtorName.Location = New System.Drawing.Point(103, 73)
        Me.txtDebtorName.Name = "txtDebtorName"
        Me.txtDebtorName.Size = New System.Drawing.Size(119, 20)
        Me.txtDebtorName.TabIndex = 136
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(22, 113)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 13)
        Me.Label14.TabIndex = 137
        Me.Label14.Text = "DRegNumber"
        '
        'txtDRegNumber
        '
        Me.txtDRegNumber.Location = New System.Drawing.Point(103, 110)
        Me.txtDRegNumber.Name = "txtDRegNumber"
        Me.txtDRegNumber.Size = New System.Drawing.Size(119, 20)
        Me.txtDRegNumber.TabIndex = 138
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(22, 144)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(65, 13)
        Me.Label13.TabIndex = 139
        Me.Label13.Text = "VATNumber"
        '
        'txtVATNumber
        '
        Me.txtVATNumber.Location = New System.Drawing.Point(103, 141)
        Me.txtVATNumber.Name = "txtVATNumber"
        Me.txtVATNumber.Size = New System.Drawing.Size(119, 20)
        Me.txtVATNumber.TabIndex = 140
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(23, 42)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(80, 13)
        Me.Label21.TabIndex = 177
        Me.Label21.Text = "Debtor Type ID"
        '
        'btnsearchid
        '
        Me.btnsearchid.Location = New System.Drawing.Point(156, 39)
        Me.btnsearchid.Name = "btnsearchid"
        Me.btnsearchid.Size = New System.Drawing.Size(66, 23)
        Me.btnsearchid.TabIndex = 179
        Me.btnsearchid.Text = "Search"
        Me.btnsearchid.UseVisualStyleBackColor = True
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(1064, 434)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 190
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'frmDebtor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1160, 469)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnsearchid)
        Me.Controls.Add(Me.txtDebtorID)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.btnBrowse)
        Me.Controls.Add(Me.cmbBEELevel)
        Me.Controls.Add(Me.cmbBlackOwnership)
        Me.Controls.Add(Me.dtpBEEEpiryDate)
        Me.Controls.Add(Me.txtCreditLimit)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.txtBEEClassification)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.txtBEECertification)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtContactName)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtWebsite)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtFax2)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtFax1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtTel3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtTel2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtTel1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtDPhysicalAddress)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtDPostalAddress)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtVATNumber)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtDRegNumber)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.txtDebtorName)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.txtDebtorTypeID)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "frmDebtor"
        Me.Text = "DEBTOR"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents btnBrowse As Button
    Friend WithEvents txtDebtorID As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txtDPostalAddress As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtDPhysicalAddress As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtTel1 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtTel2 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtTel3 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtFax1 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txtFax2 As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtWebsite As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtContactName As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtBEECertification As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents txtBEEClassification As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents txtCreditLimit As TextBox
    Friend WithEvents dtpBEEEpiryDate As DateTimePicker
    Friend WithEvents cmbBlackOwnership As ComboBox
    Friend WithEvents cmbBEELevel As ComboBox
    Friend WithEvents txtDebtorTypeID As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents txtDebtorName As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents txtDRegNumber As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtVATNumber As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents btnsearchid As Button
    Friend WithEvents btnHome As Button
End Class
