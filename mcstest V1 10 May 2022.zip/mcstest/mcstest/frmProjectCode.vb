﻿Imports System.Data.OleDb
Public Class frmProjectCode

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb")

    Public IDKey As Long

    Private Sub bind_data()
        Try
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_Projects", conn)
            Dim dataAda As New OleDbDataAdapter
            dataAda.SelectCommand = cmd1

            Dim table2 As New DataTable
            table2.Clear()
            dataAda.Fill(table2)

            DataGridView1.DataSource = table2
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub frmProjectCode_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            bind_data()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            'Update PROJECT DATA
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "UPDATE T_Projects SET Department_Code=@dept,Debtor_Id=@DebtorId,ProjectName=@ProjectName, ProjectDescription=@ProjDescr, ProjectAdress=@ProjAddress,ProjectContractType=@ProjContrType, ProjectEstimatedStartDate=@ProjEstStartDate,ProjectEstimatedEndDate=@ProjEstEndDate,ProjectEstimatedDuration=@ProjEstDuration,ProjectValue=@ProjValue,ProjectMargin=@ProjMargin,ProjectRetention=@ProjReten,ProjectPenalties=@ProjPens, ProjectPaymentTerms=@ProjPayTerms,ProjectDefaultInterest=@ProjDefInts WHERE ProjectCode=@IDKey"



            Dim ProjCode As New OleDb.OleDbParameter("@IDKey", Val(txtProjectCode.Text))

            'error says department can't be updated---not updateable field

            Dim DepartmentCode As New OleDb.OleDbParameter("@dept", Val(txtDeptCode.Text))
            Dim DebtId As New OleDb.OleDbParameter("@DebtorId", Val(txtDebtorID.Text))
            Dim ProjName As New OleDb.OleDbParameter("@ProjectName", txtProjectName.Text)
            Dim ProjDescr As New OleDb.OleDbParameter("@ProjDescr", txtProjectDesc.Text)
            Dim PAddress As New OleDb.OleDbParameter("@ProjAddress", txtProjectAddress.Text)
            Dim PContrType As New OleDb.OleDbParameter("@ProjContrType", cmbContractType.Text)
            Dim PEstStartDate As New OleDb.OleDbParameter("@ProjEstStartDate", dtpStart.Text)
            Dim PEstEndDate As New OleDb.OleDbParameter("@ProjEstEndDate", dtpEnd.Text)
            Dim PEstDuration As New OleDb.OleDbParameter("@ProjEstDuration", Val(txtDuration.Text))
            Dim PValue As New OleDb.OleDbParameter("@ProjValue", Val(txtProjectVal.Text))
            Dim PMargin As New OleDb.OleDbParameter("@ProjMargin", Val(txtProjectMargin.Text))
            Dim PRetention As New OleDb.OleDbParameter("@ProjReten", Val(txtProjectRetention.Text))
            'Dim PInsurance As New OleDb.OleDbParameter("@ProjInsur", txtProjectInsurance.Text)
            'Dim PSecurity As New OleDb.OleDbParameter("@ProjSecurity", txtProjectSecurity.Text)
            Dim PPenalties As New OleDb.OleDbParameter("@ProjPens", Val(txtProjectPenalties.Text))
            Dim PPaymentTerms As New OleDb.OleDbParameter("@ProjPayTerms", Val(txtProjectPaymentTerms.Text))
            Dim PDefaultInterests As New OleDb.OleDbParameter("@ProjDefInts", Val(txtProjectDefaultInt.Text))




            sqlcomm.Parameters.Add(DepartmentCode)
            sqlcomm.Parameters.Add(DebtId)
            sqlcomm.Parameters.Add(ProjName)
            sqlcomm.Parameters.Add(ProjDescr)
            sqlcomm.Parameters.Add(PAddress)
            sqlcomm.Parameters.Add(PContrType)
            sqlcomm.Parameters.Add(PEstStartDate)
            sqlcomm.Parameters.Add(PEstEndDate)
            sqlcomm.Parameters.Add(PEstDuration)
            sqlcomm.Parameters.Add(PValue)
            sqlcomm.Parameters.Add(PMargin)
            sqlcomm.Parameters.Add(PRetention)

            'error arises due to these fields being multi-field value fields, so they were ommitted

            'sqlcomm.Parameters.Add(PInsurance)
            'sqlcomm.Parameters.Add(PSecurity)
            sqlcomm.Parameters.Add(PPenalties)
            sqlcomm.Parameters.Add(PPaymentTerms)
            sqlcomm.Parameters.Add(PDefaultInterests)
            sqlcomm.Parameters.Add(ProjCode)

            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            bind_data()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub



    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        'Delete Data From The T_Projects Table

        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "DELETE FROM T_Projects WHERE ProjectCode=@ProjectCode"

            Dim ProjCode As New OleDb.OleDbParameter("@ProjectCode", Val(txtProjectCode.Text))


            sqlcomm.Parameters.Add(ProjCode)

            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            bind_data()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try


            'get current selected row
            Dim selectedrow1 As Integer = DataGridView1.CurrentRow.Index

            'WRITING BACK THE SELECTED PRICE CODE VALUE FROM THE DATAGRID ON THE PRICE CODE FORM TO THE BILL
            frmBill.txtProjName.Text = DataGridView1.Rows(selectedrow1).Cells(3).Value

            frmBill.txtProjCode.Text = DataGridView1.Rows(selectedrow1).Cells(0).Value



            Me.Close()

            frmBill.Show()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try



    End Sub

    Private Sub btnsearchprojectcode_Click(sender As Object, e As EventArgs)
        Try
            frmDepartment.Show()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub btnsearchbilltrade_Click(sender As Object, e As EventArgs)
        Try
            frmDebtor.Show()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            'ADD  PROJECT ---- currently we can't attach files --- will implement in actual project
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "INSERT INTO T_Projects (ProjectCode,Department_Code,Debtor_Id,ProjectName,ProjectDescription,ProjectAdress,ProjectContractType,ProjectEstimatedStartDate,ProjectEstimatedEndDate,ProjectEstimatedDuration, ProjectValue, ProjectMargin,ProjectRetention,ProjectPenalties, ProjectPaymentTerms,ProjectDefaultInterest) VALUES (@ProjectCode,@DeptCode,@DebtorId,@ProjectName,@ProjDescr,@ProjAddress,@ProjContrType,@ProjEstStartDate,@ProjEstEndDate,@ProjEstDuration,@ProjValue,@ProjMargin,@ProjReten,@ProjPens,@ProjPayTerms,@ProjDefInts)"

            'ProjectInsurance,ProjectSecurity,
            ' @ProjInsur,@ProjSecurity,



            Dim ProjCode As New OleDb.OleDbParameter("@ProjectCode", Val(txtProjectCode.Text))
            Dim DepartmentCode As New OleDb.OleDbParameter("@DeptCode", Val(txtDeptCode.Text))
            Dim DebtId As New OleDb.OleDbParameter("@DebtorId", Val(txtDebtorID.Text))
            Dim ProjName As New OleDb.OleDbParameter("@ProjectName", txtProjectName.Text)
            Dim ProjDescr As New OleDb.OleDbParameter("@ProjDescr", txtProjectDesc.Text)
            Dim PAddress As New OleDb.OleDbParameter("@ProjAddress", txtProjectAddress.Text)
            Dim PContrType As New OleDb.OleDbParameter("@ProjContrType", cmbContractType.Text)
            Dim PEstStartDate As New OleDb.OleDbParameter("@ProjEstStartDate", dtpStart.Text)
            Dim PEstEndDate As New OleDb.OleDbParameter("@ProjEstEndDate", dtpEnd.Text)
            Dim PEstDuration As New OleDb.OleDbParameter("@ProjEstDuration", Val(txtDuration.Text))
            Dim PValue As New OleDb.OleDbParameter("@ProjValue", Val(txtProjectVal.Text))
            Dim PMargin As New OleDb.OleDbParameter("@ProjMargin", Val(txtProjectMargin.Text))
            Dim PRetention As New OleDb.OleDbParameter("@ProjReten", Val(txtProjectRetention.Text))
            'Dim PInsurance As New OleDb.OleDbParameter("@ProjInsur", txtProjectInsurance.Text)
            'Dim PSecurity As New OleDb.OleDbParameter("@ProjSecurity", txtProjectSecurity.Text)
            Dim PPenalties As New OleDb.OleDbParameter("@ProjPens", Val(txtProjectPenalties.Text))
            Dim PPaymentTerms As New OleDb.OleDbParameter("@ProjPayTerms", Val(txtProjectPaymentTerms.Text))
            Dim PDefaultInterests As New OleDb.OleDbParameter("@ProjDefInts", Val(txtProjectDefaultInt.Text))


            sqlcomm.Parameters.Add(ProjCode)
            sqlcomm.Parameters.Add(DepartmentCode)
            sqlcomm.Parameters.Add(DebtId)
            sqlcomm.Parameters.Add(ProjName)
            sqlcomm.Parameters.Add(ProjDescr)
            sqlcomm.Parameters.Add(PAddress)
            sqlcomm.Parameters.Add(PContrType)
            sqlcomm.Parameters.Add(PEstStartDate)
            sqlcomm.Parameters.Add(PEstEndDate)
            sqlcomm.Parameters.Add(PEstDuration)
            sqlcomm.Parameters.Add(PValue)
            sqlcomm.Parameters.Add(PMargin)
            sqlcomm.Parameters.Add(PRetention)
            'error says we must delete this multi field value/attachment
            'sqlcomm.Parameters.Add(PInsurance)
            'sqlcomm.Parameters.Add(PSecurity)
            sqlcomm.Parameters.Add(PPenalties)
            sqlcomm.Parameters.Add(PPaymentTerms)
            sqlcomm.Parameters.Add(PDefaultInterests)

            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            bind_data()

            btnAdd.Enabled = True

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnSearchDeptCode_Click(sender As Object, e As EventArgs) Handles btnSearchDeptCode.Click
        Try
            frmDepartment.Show()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub btnSearchDebtorID_Click(sender As Object, e As EventArgs) Handles btnSearchDebtorID.Click
        Try
            frmDebtor2.Show()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub dtpStart_ValueChanged(sender As Object, e As EventArgs) Handles dtpStart.ValueChanged
        'calculates the duration everytime one of the datetimepickers is selected

        Try
            If True Then

                Dim dt1 As DateTime = Convert.ToDateTime(dtpStart.Text)
                Dim dt2 As DateTime = Convert.ToDateTime(dtpEnd.Text)

                Dim ts As TimeSpan = dt2.Subtract(dt1)

                If Convert.ToInt32(ts.Days) >= 0 Then

                    txtDuration.Text = Convert.ToInt32(ts.Days)
                Else

                    MessageBox.Show("Invalid Input")

                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub dtpEnd_ValueChanged(sender As Object, e As EventArgs) Handles dtpEnd.ValueChanged
        Try
            If True Then

                Dim dt1 As DateTime = Convert.ToDateTime(dtpStart.Text)
                Dim dt2 As DateTime = Convert.ToDateTime(dtpEnd.Text)

                Dim ts As TimeSpan = dt2.Subtract(dt1)

                If Convert.ToInt32(ts.Days) >= 0 Then

                    txtDuration.Text = Convert.ToInt32(ts.Days)
                Else

                    MessageBox.Show("Invalid Input")

                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click

        Try
            frmNavigation.Show()
            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub
End Class