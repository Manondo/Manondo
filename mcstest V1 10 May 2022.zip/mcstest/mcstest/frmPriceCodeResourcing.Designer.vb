﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPriceCodeResourcing
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnbillcode = New System.Windows.Forms.Button()
        Me.txtbillcode = New System.Windows.Forms.TextBox()
        Me.txtqty = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtPercentage = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.lblpricecoderesourcerate = New System.Windows.Forms.Label()
        Me.txtresourceID = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblresourcerate = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtusagePerdayunit = New System.Windows.Forms.TextBox()
        Me.txtdurationunit = New System.Windows.Forms.TextBox()
        Me.txtunitqty = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtduration = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtusagePday = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblresourceunit = New System.Windows.Forms.Label()
        Me.btnsearchclassifications = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.txtresourcecode = New System.Windows.Forms.TextBox()
        Me.lblclassi = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtBillPriceid = New System.Windows.Forms.TextBox()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblUnit = New System.Windows.Forms.Label()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lblRate = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(15, 66)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(647, 254)
        Me.DataGridView1.TabIndex = 42
        '
        'btnbillcode
        '
        Me.btnbillcode.Location = New System.Drawing.Point(170, 342)
        Me.btnbillcode.Name = "btnbillcode"
        Me.btnbillcode.Size = New System.Drawing.Size(289, 20)
        Me.btnbillcode.TabIndex = 42
        Me.btnbillcode.Text = "UPDATE AND FINISH"
        Me.btnbillcode.UseVisualStyleBackColor = True
        '
        'txtbillcode
        '
        Me.txtbillcode.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtbillcode.Enabled = False
        Me.txtbillcode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbillcode.Location = New System.Drawing.Point(39, 36)
        Me.txtbillcode.Name = "txtbillcode"
        Me.txtbillcode.Size = New System.Drawing.Size(81, 13)
        Me.txtbillcode.TabIndex = 41
        '
        'txtqty
        '
        Me.txtqty.Location = New System.Drawing.Point(200, 200)
        Me.txtqty.Name = "txtqty"
        Me.txtqty.Size = New System.Drawing.Size(221, 20)
        Me.txtqty.TabIndex = 40
        Me.txtqty.Text = "1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(71, 203)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(118, 13)
        Me.Label3.TabIndex = 39
        Me.Label3.Text = "PriceCodeResourceQty"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(43, 160)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(152, 13)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "RESOURCE UNIT MEASURE"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtPercentage)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.lblpricecoderesourcerate)
        Me.GroupBox1.Controls.Add(Me.txtresourceID)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.lblresourcerate)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtusagePerdayunit)
        Me.GroupBox1.Controls.Add(Me.txtdurationunit)
        Me.GroupBox1.Controls.Add(Me.txtunitqty)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtduration)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtusagePday)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.lblresourceunit)
        Me.GroupBox1.Controls.Add(Me.txtqty)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.btnsearchclassifications)
        Me.GroupBox1.Controls.Add(Me.btnAdd)
        Me.GroupBox1.Controls.Add(Me.txtresourcecode)
        Me.GroupBox1.Controls.Add(Me.lblclassi)
        Me.GroupBox1.Location = New System.Drawing.Point(687, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(472, 526)
        Me.GroupBox1.TabIndex = 45
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "ADD PRICE CODE RESOURCE ITEM"
        '
        'txtPercentage
        '
        Me.txtPercentage.Location = New System.Drawing.Point(197, 397)
        Me.txtPercentage.Name = "txtPercentage"
        Me.txtPercentage.Size = New System.Drawing.Size(221, 20)
        Me.txtPercentage.TabIndex = 66
        Me.txtPercentage.Text = "0"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(77, 400)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(113, 13)
        Me.Label15.TabIndex = 65
        Me.Label15.Text = "Wastage Allowance %"
        '
        'lblpricecoderesourcerate
        '
        Me.lblpricecoderesourcerate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblpricecoderesourcerate.Location = New System.Drawing.Point(196, 426)
        Me.lblpricecoderesourcerate.Name = "lblpricecoderesourcerate"
        Me.lblpricecoderesourcerate.Size = New System.Drawing.Size(223, 23)
        Me.lblpricecoderesourcerate.TabIndex = 64
        '
        'txtresourceID
        '
        Me.txtresourceID.Location = New System.Drawing.Point(198, 47)
        Me.txtresourceID.Name = "txtresourceID"
        Me.txtresourceID.Size = New System.Drawing.Size(221, 20)
        Me.txtresourceID.TabIndex = 63
        Me.txtresourceID.Text = "326"
        Me.txtresourceID.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(50, 50)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(121, 13)
        Me.Label10.TabIndex = 62
        Me.Label10.Text = "PriceCodeResourcingID"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(64, 427)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(125, 13)
        Me.Label11.TabIndex = 59
        Me.Label11.Text = "PriceCodeResourceRate"
        '
        'lblresourcerate
        '
        Me.lblresourcerate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblresourcerate.Location = New System.Drawing.Point(197, 116)
        Me.lblresourcerate.Name = "lblresourcerate"
        Me.lblresourcerate.Size = New System.Drawing.Size(221, 22)
        Me.lblresourcerate.TabIndex = 58
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(92, 117)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(99, 13)
        Me.Label4.TabIndex = 56
        Me.Label4.Text = "RESOURCE RATE"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(84, 367)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(106, 13)
        Me.Label9.TabIndex = 55
        Me.Label9.Text = "UNIT OF MEASURE"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(89, 313)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(106, 13)
        Me.Label8.TabIndex = 54
        Me.Label8.Text = "UNIT OF MEASURE"
        '
        'txtusagePerdayunit
        '
        Me.txtusagePerdayunit.Location = New System.Drawing.Point(199, 360)
        Me.txtusagePerdayunit.Name = "txtusagePerdayunit"
        Me.txtusagePerdayunit.Size = New System.Drawing.Size(221, 20)
        Me.txtusagePerdayunit.TabIndex = 53
        '
        'txtdurationunit
        '
        Me.txtdurationunit.Location = New System.Drawing.Point(200, 306)
        Me.txtdurationunit.Name = "txtdurationunit"
        Me.txtdurationunit.Size = New System.Drawing.Size(221, 20)
        Me.txtdurationunit.TabIndex = 51
        '
        'txtunitqty
        '
        Me.txtunitqty.Location = New System.Drawing.Point(200, 226)
        Me.txtunitqty.Name = "txtunitqty"
        Me.txtunitqty.Size = New System.Drawing.Size(221, 20)
        Me.txtunitqty.TabIndex = 49
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(85, 229)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(106, 13)
        Me.Label7.TabIndex = 48
        Me.Label7.Text = "UNIT OF MEASURE"
        '
        'txtduration
        '
        Me.txtduration.Location = New System.Drawing.Point(200, 280)
        Me.txtduration.Name = "txtduration"
        Me.txtduration.Size = New System.Drawing.Size(221, 20)
        Me.txtduration.TabIndex = 47
        Me.txtduration.Text = "1"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(55, 283)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(142, 13)
        Me.Label6.TabIndex = 46
        Me.Label6.Text = "PriceCodeResourceDuration"
        '
        'txtusagePday
        '
        Me.txtusagePday.Location = New System.Drawing.Point(198, 337)
        Me.txtusagePday.Name = "txtusagePday"
        Me.txtusagePday.Size = New System.Drawing.Size(221, 20)
        Me.txtusagePday.TabIndex = 45
        Me.txtusagePday.Text = "1"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(25, 340)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(168, 13)
        Me.Label5.TabIndex = 44
        Me.Label5.Text = "PriceCodeResourceUsagePerDay"
        '
        'lblresourceunit
        '
        Me.lblresourceunit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblresourceunit.Location = New System.Drawing.Point(200, 159)
        Me.lblresourceunit.Name = "lblresourceunit"
        Me.lblresourceunit.Size = New System.Drawing.Size(221, 22)
        Me.lblresourceunit.TabIndex = 43
        '
        'btnsearchclassifications
        '
        Me.btnsearchclassifications.Location = New System.Drawing.Point(286, 80)
        Me.btnsearchclassifications.Name = "btnsearchclassifications"
        Me.btnsearchclassifications.Size = New System.Drawing.Size(134, 23)
        Me.btnsearchclassifications.TabIndex = 34
        Me.btnsearchclassifications.Text = "Search  Resource Code"
        Me.btnsearchclassifications.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(198, 468)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(221, 32)
        Me.btnAdd.TabIndex = 25
        Me.btnAdd.Text = "ADD PRICE CODERESOURCING ITEM"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'txtresourcecode
        '
        Me.txtresourcecode.Location = New System.Drawing.Point(199, 80)
        Me.txtresourcecode.Name = "txtresourcecode"
        Me.txtresourcecode.Size = New System.Drawing.Size(81, 20)
        Me.txtresourcecode.TabIndex = 33
        '
        'lblclassi
        '
        Me.lblclassi.AutoSize = True
        Me.lblclassi.Location = New System.Drawing.Point(54, 85)
        Me.lblclassi.Name = "lblclassi"
        Me.lblclassi.Size = New System.Drawing.Size(140, 13)
        Me.lblclassi.TabIndex = 32
        Me.lblclassi.Text = "ENTER RESOURCE CODE"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(36, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 13)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "Bill Price Code"
        '
        'txtBillPriceid
        '
        Me.txtBillPriceid.Location = New System.Drawing.Point(438, 501)
        Me.txtBillPriceid.Name = "txtBillPriceid"
        Me.txtBillPriceid.Size = New System.Drawing.Size(224, 20)
        Me.txtBillPriceid.TabIndex = 44
        Me.txtBillPriceid.Text = "Insert Description to search"
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(1097, 550)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 190
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(15, 501)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(227, 20)
        Me.txtID.TabIndex = 43
        Me.txtID.Text = "Insert ID to search"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(553, 22)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(30, 13)
        Me.Label12.TabIndex = 36
        Me.Label12.Text = "Rate"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(410, 22)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(26, 13)
        Me.Label13.TabIndex = 36
        Me.Label13.Text = "Unit"
        '
        'lblUnit
        '
        Me.lblUnit.AutoSize = True
        Me.lblUnit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUnit.Location = New System.Drawing.Point(410, 43)
        Me.lblUnit.Name = "lblUnit"
        Me.lblUnit.Size = New System.Drawing.Size(30, 13)
        Me.lblUnit.TabIndex = 36
        Me.lblUnit.Text = "Unit"
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = True
        Me.lblDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDescription.Location = New System.Drawing.Point(267, 43)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(71, 13)
        Me.lblDescription.TabIndex = 36
        Me.lblDescription.Text = "Description"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(267, 22)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(60, 13)
        Me.Label16.TabIndex = 36
        Me.Label16.Text = "Description"
        '
        'lblRate
        '
        Me.lblRate.AutoSize = True
        Me.lblRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRate.Location = New System.Drawing.Point(553, 43)
        Me.lblRate.Name = "lblRate"
        Me.lblRate.Size = New System.Drawing.Size(34, 13)
        Me.lblRate.TabIndex = 36
        Me.lblRate.Text = "Rate"
        '
        'frmPriceCodeResourcing
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1174, 585)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtBillPriceid)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.lblDescription)
        Me.Controls.Add(Me.lblRate)
        Me.Controls.Add(Me.lblUnit)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtbillcode)
        Me.Controls.Add(Me.btnbillcode)
        Me.Name = "frmPriceCodeResourcing"
        Me.Text = "PRICE CODE RESOURCING"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnbillcode As Button
    Friend WithEvents txtbillcode As TextBox
    Friend WithEvents txtqty As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnsearchclassifications As Button
    Friend WithEvents btnAdd As Button
    Friend WithEvents txtresourcecode As TextBox
    Friend WithEvents lblclassi As Label
    Friend WithEvents txtBillPriceid As TextBox
    Friend WithEvents lblresourceunit As Label
    Friend WithEvents txtusagePerdayunit As TextBox
    Friend WithEvents txtdurationunit As TextBox
    Friend WithEvents txtunitqty As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtduration As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtusagePday As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblresourcerate As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents txtresourceID As TextBox
    Friend WithEvents lblpricecoderesourcerate As Label
    Friend WithEvents btnHome As Button
    Friend WithEvents txtID As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents lblUnit As Label
    Friend WithEvents lblDescription As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents lblRate As Label
    Friend WithEvents txtPercentage As TextBox
    Friend WithEvents Label15 As Label
End Class
