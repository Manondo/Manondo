﻿Imports System.Data.OleDb
Public Class frmUser

    Public IDKey As Long

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb")



    Public Sub clear()
        txtuser.Clear()
        txtemp.Clear()
        txtpasswd.Clear()
        txtcompany.Clear()
        txtuname.Clear()
    End Sub


    Public Sub bind_data()
        Try
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_User", conn)
            Dim da As New OleDbDataAdapter
            da.SelectCommand = cmd1

            Dim table1 As New DataTable
            table1.Clear()
            da.Fill(table1)

            DataGridView1.DataSource = table1
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub txtsearch_Click(sender As Object, e As EventArgs) Handles txtsearch.Click
        frmCompany2.Show()
        Me.Hide()
    End Sub

    Private Sub txtadd_Click(sender As Object, e As EventArgs) Handles txtadd.Click

        '===note to self. username and password are reserved on vbnet even if not on the dbms. make necessary changes
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "INSERT INTO T_User (UserID,EmployeeID,UserName1,Password1,Companyid) Values (@UserID,@EmployeeID,@UserName,@Password,@Companyid)"

            Dim user1 As New OleDb.OleDbParameter("@UserID", Val(txtuser.Text))
            Dim emp1 As New OleDb.OleDbParameter("@EmployeeID", Val(txtemp.Text))
            Dim uname1 As New OleDb.OleDbParameter("@UserName", txtuname.Text)
            Dim passw1 As New OleDb.OleDbParameter("@Password", txtpasswd.Text)
            Dim company1 As New OleDb.OleDbParameter("@Companyid", Val(txtcompany.Text))


            sqlcomm.Parameters.Add(user1)
            sqlcomm.Parameters.Add(emp1)
            sqlcomm.Parameters.Add(uname1)
            sqlcomm.Parameters.Add(passw1)
            sqlcomm.Parameters.Add(company1)


            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            bind_data()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub frmUser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        bind_data()
    End Sub

    Private Sub txtupdate_Click(sender As Object, e As EventArgs) Handles txtupdate.Click

        'username and password are reserved on vb.net when connecting, rename them

        Try
            'update sql statement
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()

            sqlcomm.Connection = cn
            sqlcomm.CommandText = "UPDATE T_User SET UserName1=@Us1,EmployeeID=@emp,Password1=@passt,Companyid=@company WHERE UserID=@IDKey"


            'must be first in this group of items

            Dim usercode As New OleDb.OleDbParameter("@IDKey", Val(txtuser.Text))
            'IDN for id number
            Dim usname As New OleDb.OleDbParameter("@Us1", txtuname.Text)

            Dim empi As New OleDb.OleDbParameter("emp", Val(txtemp.Text))
            Dim uspass As New OleDb.OleDbParameter("passt", txtpasswd.Text)
            Dim co As New OleDb.OleDbParameter("company", Val(txtcompany.Text))



            'userid/code must be last in this list
            sqlcomm.Parameters.Add(usname)
            sqlcomm.Parameters.Add(empi)
            sqlcomm.Parameters.Add(uspass)
            sqlcomm.Parameters.Add(co)


            'this must be last or it won't work
            sqlcomm.Parameters.Add(usercode)



            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            bind_data()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub txtclear_Click(sender As Object, e As EventArgs) Handles txtclear.Click
        clear()
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmNavigation.Show()
        Me.Close()
    End Sub
End Class