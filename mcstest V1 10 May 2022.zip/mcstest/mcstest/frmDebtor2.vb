﻿Imports System.Data.OleDb
Imports System.IO
Public Class frmDebtor2
    Public IDKey As Long
    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb")
    Private ofdDocument As Object

    'sub to clear all textboxes
    Public Sub clear()
        Try

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Dim txt As Control
        For Each txt In Controls
            If TypeOf txt Is TextBox Then
                txt.Text = ""
            End If
        Next
    End Sub


    Private Sub bind_data()

        Try
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_Debtors", conn)
            Dim dataAda As New OleDbDataAdapter
            dataAda.SelectCommand = cmd1

            Dim table2 As New DataTable
            table2.Clear()
            dataAda.Fill(table2)

            DataGridView1.DataSource = table2
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub frmDebtor_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        bind_data()
    End Sub

    'button to insert costcode items
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "INSERT INTO T_Debtors (Debtor_Id,DType_Id,D_Name,D_RegistrationNr,D_VatNr,D_PostalAddress,D_PhysicalAddress,D_Tel1,D_Tel2,D_Tel3,D_Fax1,D_Fax2,D_Email,D_Website,D_ContactName,D_BEEECertificate,D_BEEEExpiryDate,D_BEELevel,D_BEEClassification,D_Blackownership,D_CreditLimit) VALUES (@Debtor_Id1,@DType,@DName,@DRegNr,@DVatNr,@DPostalAdd,@DPhysicalAdd,@DTel1,@DTel2,@DTel3,@DFax1,@DFax2,@DEmail,@DWeb,@DContactName,@BEECert,@BEEExp,@BEELevel,@BEEClass,@BlackOwnership,@DCreditlim)"


            Dim DebtorID1 As New OleDb.OleDbParameter("@Debtor_Id1", Val(txtDebtorID.Text))
            Dim DebtorType As New OleDb.OleDbParameter("@DType", Val(txtDebtorTypeID.Text))
            Dim DebtorName As New OleDb.OleDbParameter("@DName", txtDebtorName.Text)
            Dim DebtorRegNumber As New OleDb.OleDbParameter("@DRegNr", txtDRegNumber.Text)
            Dim DebtorVatNumber As New OleDb.OleDbParameter("@DVatNr", txtVATNumber.Text)
            Dim PostalAddress As New OleDb.OleDbParameter("@DPostalAdd", txtDPostalAddress.Text)
            Dim PhysicalAddress As New OleDb.OleDbParameter("@DPhysicalAdd", txtDPhysicalAddress.Text)
            Dim DebtorTel1 As New OleDb.OleDbParameter("@DTel1", txtTel1.Text)
            Dim DebtorTel2 As New OleDb.OleDbParameter("@DTel2", txtTel2.Text)
            Dim DebtorTel3 As New OleDb.OleDbParameter("@DTel3", txtTel3.Text)
            Dim DebtorFax1 As New OleDb.OleDbParameter("@DFax1", txtFax1.Text)
            Dim DebtorFax2 As New OleDb.OleDbParameter("@DFax2", txtFax2.Text)
            Dim DebtorEmail As New OleDb.OleDbParameter("@DEmail", txtEmail.Text)
            Dim DebtorWebsite As New OleDb.OleDbParameter("@DWeb", txtWebsite.Text)
            Dim DebtorContactName As New OleDb.OleDbParameter("@DContactName", txtContactName.Text)
            Dim DebtorBEECertificate As New OleDb.OleDbParameter("@BEECert", txtBEECertification.Text)
            Dim DebtorBEEEXpiry As New OleDb.OleDbParameter("@BEEExp", dtpBEEEpiryDate.Text)
            Dim DebtorBEELevel As New OleDb.OleDbParameter("@BEELevel", cmbBEELevel.Text)
            Dim DebtorBEEClass As New OleDb.OleDbParameter("@BEEClass", txtBEEClassification.Text)
            Dim DebtorBlackOwnership As New OleDb.OleDbParameter("@BlackOwnership", Val(cmbBlackOwnership.Text))
            Dim DebtorCredit As New OleDb.OleDbParameter("@DCreditlim", Val(txtCreditLimit.Text))


            sqlcomm.Parameters.Add(DebtorID1)
            sqlcomm.Parameters.Add(DebtorType)
            sqlcomm.Parameters.Add(DebtorName)
            sqlcomm.Parameters.Add(DebtorRegNumber)
            sqlcomm.Parameters.Add(DebtorVatNumber)
            sqlcomm.Parameters.Add(PostalAddress)
            sqlcomm.Parameters.Add(PhysicalAddress)
            sqlcomm.Parameters.Add(DebtorTel1)
            sqlcomm.Parameters.Add(DebtorTel2)
            sqlcomm.Parameters.Add(DebtorTel3)
            sqlcomm.Parameters.Add(DebtorFax1)
            sqlcomm.Parameters.Add(DebtorFax2)
            sqlcomm.Parameters.Add(DebtorEmail)
            sqlcomm.Parameters.Add(DebtorWebsite)
            sqlcomm.Parameters.Add(DebtorContactName)
            sqlcomm.Parameters.Add(DebtorBEECertificate)
            sqlcomm.Parameters.Add(DebtorBEEEXpiry)
            sqlcomm.Parameters.Add(DebtorBEELevel)
            sqlcomm.Parameters.Add(DebtorBEEClass)
            sqlcomm.Parameters.Add(DebtorBlackOwnership)
            sqlcomm.Parameters.Add(DebtorCredit)


            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            bind_data()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            'Update The T_Debtors Table
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand


            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "UPDATE T_Debtors SET DType_Id=@DType,D_Name=@DName, D_RegistrationNr=@DRegNr,D_VatNr=@DVatNr, D_PostalAddress=@DPostalAdd, D_PhysicalAddress=@DPhysicalAdd,D_Tel1=@DTel1, D_Tel2=@DTel2, D_Tel3=@DTel3, D_Fax1=@DFax1, D_Fax2=@DFax2, D_Email=@DEmail,D_Website=@DWeb, D_ContactName=@DContactName, D_BEEECertificate=@BEECert,D_BEEEExpiryDate=@BEEExp, D_BEELevel=@BEELevel, D_BEEClassification=@BEEClass,D_Blackownership=@BlackOwnership, D_CreditLimit=@DCreditlim WHERE Debtor_Id=@IDKey "



            Dim DebtorID1 As New OleDb.OleDbParameter("@IDKey", Val(txtDebtorID.Text))
            Dim DebtorType As New OleDb.OleDbParameter("@DType", Val(txtDebtorTypeID.Text))
            Dim DebtorName As New OleDb.OleDbParameter("@DName", txtDebtorName.Text)
            Dim DebtorRegNumber As New OleDb.OleDbParameter("@DRegNr", txtDRegNumber.Text)
            Dim DebtorVatNumber As New OleDb.OleDbParameter("@DVatNr", txtVATNumber.Text)
            Dim PostalAddress As New OleDb.OleDbParameter("@DPostalAdd", txtDPostalAddress.Text)
            Dim PhysicalAddress As New OleDb.OleDbParameter("@DPhysicalAdd", txtDPhysicalAddress.Text)
            Dim DebtorTel1 As New OleDb.OleDbParameter("@DTel1", txtTel1.Text)
            Dim DebtorTel2 As New OleDb.OleDbParameter("@DTel2", txtTel2.Text)
            Dim DebtorTel3 As New OleDb.OleDbParameter("@DTel3", txtTel3.Text)
            Dim DebtorFax1 As New OleDb.OleDbParameter("@DFax1", txtFax1.Text)
            Dim DebtorFax2 As New OleDb.OleDbParameter("@DFax2", txtFax2.Text)
            Dim DebtorEmail As New OleDb.OleDbParameter("@DEmail", txtEmail.Text)
            Dim DebtorWebsite As New OleDb.OleDbParameter("@DWeb", txtWebsite.Text)
            Dim DebtorContactName As New OleDb.OleDbParameter("@DContactName", txtContactName.Text)
            Dim DebtorBEECertificate As New OleDb.OleDbParameter("@BEECert", txtBEECertification.Text)
            Dim DebtorBEEEXpiry As New OleDb.OleDbParameter("@BEEExp", dtpBEEEpiryDate.Text)
            Dim DebtorBEELevel As New OleDb.OleDbParameter("@BEELevel", cmbBEELevel.Text)
            Dim DebtorBEEClass As New OleDb.OleDbParameter("@BEEClass", txtBEEClassification.Text)
            Dim DebtorBlackOwnership As New OleDb.OleDbParameter("@BlackOwnership", Val(cmbBlackOwnership.Text))
            Dim DebtorCredit As New OleDb.OleDbParameter("@DCreditlim", Val(txtCreditLimit.Text))


            sqlcomm.Parameters.Add(DebtorType)
            sqlcomm.Parameters.Add(DebtorName)
            sqlcomm.Parameters.Add(DebtorRegNumber)
            sqlcomm.Parameters.Add(DebtorVatNumber)
            sqlcomm.Parameters.Add(PostalAddress)
            sqlcomm.Parameters.Add(PhysicalAddress)
            sqlcomm.Parameters.Add(DebtorTel1)
            sqlcomm.Parameters.Add(DebtorTel2)
            sqlcomm.Parameters.Add(DebtorTel3)
            sqlcomm.Parameters.Add(DebtorFax1)
            sqlcomm.Parameters.Add(DebtorFax2)
            sqlcomm.Parameters.Add(DebtorEmail)
            sqlcomm.Parameters.Add(DebtorWebsite)
            sqlcomm.Parameters.Add(DebtorContactName)
            sqlcomm.Parameters.Add(DebtorBEECertificate)
            sqlcomm.Parameters.Add(DebtorBEEEXpiry)
            sqlcomm.Parameters.Add(DebtorBEELevel)
            sqlcomm.Parameters.Add(DebtorBEEClass)
            sqlcomm.Parameters.Add(DebtorBlackOwnership)
            sqlcomm.Parameters.Add(DebtorCredit)


            sqlcomm.Parameters.Add(DebtorID1)

            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            bind_data()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            'Delete Data From The T_Debtors Table
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "DELETE FROM T_Debtors WHERE Debtor_Id=@debt"

            Dim DebtorType As New OleDb.OleDbParameter("@debt", Val(txtDebtorID.Text))


            sqlcomm.Parameters.Add(DebtorType)


            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            bind_data()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clearing All Textboxes And Other Inputs
        Try
            'This code clears all the text boxes on the form --- here we call the sub procedure

            Dim r As New Control
            clear()

            cmbBEELevel.SelectedIndex = 0
            cmbBlackOwnership.SelectedIndex = 0
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub btnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        'Opening a pop up local folder to show you local files and load it into the BEE Certificate textbox
        ofdDocument.ShowDialog()

        'Check if file is a document
        If ofdDocument.FileName > "" Then
            txtBEECertification.Text = ofdDocument.FileName
        End If

    End Sub


    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            Dim intcount As String

            'ASIGNING VALUE OF THE SELECTED CELL TO THE VARABLE intcount
            intcount = DataGridView1.CurrentCell.Value
            frmProjectCode.txtDebtorID.Text = intcount

            frmProjectCode.Show()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnsearchid_Click(sender As Object, e As EventArgs) Handles btnsearchid.Click
        frmDebtorType.Show()
        Me.Hide()
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmNavigation.Show()
        Me.Close()
    End Sub
End Class