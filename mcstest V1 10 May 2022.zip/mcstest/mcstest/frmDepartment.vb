﻿Imports System.Data.OleDb
Public Class frmDepartment

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb")

    Private Sub bind_data()
        Try
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_Department", conn)
            Dim dataAda As New OleDbDataAdapter
            dataAda.SelectCommand = cmd1

            Dim table2 As New DataTable
            table2.Clear()
            dataAda.Fill(table2)

            DataGridView1.DataSource = table2
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Private Sub frmCompany_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        bind_data()
    End Sub



    Private Sub txtcoIDsearch_TextChanged(sender As Object, e As EventArgs) Handles txtcoIDsearch.TextChanged

        Try
            'search by department id
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_Department where Department_Code like '%'+ @parm1 + '%'", conn)
            cmd1.Parameters.AddWithValue("@parm1", txtcoIDsearch.Text)
            Dim da As New OleDbDataAdapter
            da.SelectCommand = cmd1

            Dim table1 As New DataTable
            table1.Clear()
            da.Fill(table1)

            DataGridView1.DataSource = table1
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub txtcoNamesearch_TextChanged(sender As Object, e As EventArgs) Handles txtcoNamesearch.TextChanged
        Try
            'search by department name
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_Department where D_Description like '%'+ @parm1 + '%'", conn)
            cmd1.Parameters.AddWithValue("@parm1", txtcoNamesearch.Text)
            Dim da As New OleDbDataAdapter
            da.SelectCommand = cmd1

            Dim table1 As New DataTable
            table1.Clear()
            da.Fill(table1)

            DataGridView1.DataSource = table1
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub btnsearchcompany_Click(sender As Object, e As EventArgs) Handles btnsearchcompany.Click

        Try
            frmCompany.Show()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub btnAddDept_Click(sender As Object, e As EventArgs) Handles btnAddDept.Click
        Try
            'add department
            Dim strsql As String
            strsql = "INSERT INTO T_Department(Department_Code,D_Description,CompanyID) Values(@Did,@Ddescription,@Cid)"
            Dim cmd2 As New OleDbCommand(strsql, conn)

            cmd2.Parameters.AddWithValue("@Did", Val(txtDepartmentID.Text))
            cmd2.Parameters.AddWithValue("@Ddescription", txtDepartmentDescription.Text)
            cmd2.Parameters.AddWithValue("@Cid", Val(txtsearchcompanyid.Text))

            conn.Open()
            cmd2.ExecuteNonQuery()
            conn.Close()
            bind_data()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            Dim intcount As String

            'ASIGNING VALUE OF THE SELECTED CELL TO THE VARABLE intcount
            intcount = DataGridView1.CurrentCell.Value
            frmProjectCode.txtDeptCode.Text = intcount
            frmProjectCode.Show()
            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmNavigation.Show()
        Me.Close()
    End Sub
End Class