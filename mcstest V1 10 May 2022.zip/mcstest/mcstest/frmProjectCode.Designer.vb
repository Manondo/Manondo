﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProjectCode
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtProjectCode = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtDuration = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtProjectVal = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtProjectName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtProjectAddress = New System.Windows.Forms.TextBox()
        Me.ype = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtProjectMargin = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtProjectInsurance = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtProjectRetention = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtProjectDesc = New System.Windows.Forms.TextBox()
        Me.dtpStart = New System.Windows.Forms.DateTimePicker()
        Me.dtpEnd = New System.Windows.Forms.DateTimePicker()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtProjectSecurity = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtProjectPenalties = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtProjectPaymentTerms = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtProjectDefaultInt = New System.Windows.Forms.TextBox()
        Me.cmbContractType = New System.Windows.Forms.ComboBox()
        Me.btnSearchDebtorID = New System.Windows.Forms.Button()
        Me.btnSearchDeptCode = New System.Windows.Forms.Button()
        Me.txtDebtorID = New System.Windows.Forms.TextBox()
        Me.txtDeptCode = New System.Windows.Forms.TextBox()
        Me.btnHome = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(193, 598)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 260
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(142, 294)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(148, 23)
        Me.btnSearch.TabIndex = 195
        Me.btnSearch.Text = "Search Project By Code"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'txtSearch
        '
        Me.txtSearch.Location = New System.Drawing.Point(10, 296)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(126, 20)
        Me.txtSearch.TabIndex = 194
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(728, 598)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(75, 23)
        Me.btnDelete.TabIndex = 193
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(462, 598)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(92, 23)
        Me.btnUpdate.TabIndex = 190
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(12, 323)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(962, 251)
        Me.DataGridView1.TabIndex = 257
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(25, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 13)
        Me.Label1.TabIndex = 188
        Me.Label1.Text = "Project Code"
        '
        'txtProjectCode
        '
        Me.txtProjectCode.Location = New System.Drawing.Point(131, 7)
        Me.txtProjectCode.Name = "txtProjectCode"
        Me.txtProjectCode.Size = New System.Drawing.Size(159, 20)
        Me.txtProjectCode.TabIndex = 192
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(365, 53)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 13)
        Me.Label6.TabIndex = 196
        Me.Label6.Text = "Start Date"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(365, 107)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 13)
        Me.Label7.TabIndex = 197
        Me.Label7.Text = "End Date"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(365, 144)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(47, 13)
        Me.Label8.TabIndex = 198
        Me.Label8.Text = "Duration"
        '
        'txtDuration
        '
        Me.txtDuration.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtDuration.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDuration.Location = New System.Drawing.Point(449, 144)
        Me.txtDuration.Name = "txtDuration"
        Me.txtDuration.Size = New System.Drawing.Size(187, 23)
        Me.txtDuration.TabIndex = 199
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(365, 193)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(70, 13)
        Me.Label9.TabIndex = 200
        Me.Label9.Text = "Project Value"
        '
        'txtProjectVal
        '
        Me.txtProjectVal.Location = New System.Drawing.Point(449, 190)
        Me.txtProjectVal.Name = "txtProjectVal"
        Me.txtProjectVal.Size = New System.Drawing.Size(187, 20)
        Me.txtProjectVal.TabIndex = 201
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 147)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 13)
        Me.Label5.TabIndex = 204
        Me.Label5.Text = "Project Name"
        '
        'txtProjectName
        '
        Me.txtProjectName.Location = New System.Drawing.Point(131, 144)
        Me.txtProjectName.Name = "txtProjectName"
        Me.txtProjectName.Size = New System.Drawing.Size(159, 20)
        Me.txtProjectName.TabIndex = 205
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 241)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 13)
        Me.Label3.TabIndex = 208
        Me.Label3.Text = "Project Address"
        '
        'txtProjectAddress
        '
        Me.txtProjectAddress.Location = New System.Drawing.Point(129, 238)
        Me.txtProjectAddress.Name = "txtProjectAddress"
        Me.txtProjectAddress.Size = New System.Drawing.Size(161, 20)
        Me.txtProjectAddress.TabIndex = 209
        '
        'ype
        '
        Me.ype.AutoSize = True
        Me.ype.Location = New System.Drawing.Point(361, 11)
        Me.ype.Name = "ype"
        Me.ype.Size = New System.Drawing.Size(74, 13)
        Me.ype.TabIndex = 210
        Me.ype.Text = "Contract Type"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(360, 241)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(75, 13)
        Me.Label14.TabIndex = 212
        Me.Label14.Text = "Project Margin"
        '
        'txtProjectMargin
        '
        Me.txtProjectMargin.Location = New System.Drawing.Point(450, 238)
        Me.txtProjectMargin.Name = "txtProjectMargin"
        Me.txtProjectMargin.Size = New System.Drawing.Size(186, 20)
        Me.txtProjectMargin.TabIndex = 213
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Enabled = False
        Me.Label13.Location = New System.Drawing.Point(725, 63)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(90, 13)
        Me.Label13.TabIndex = 214
        Me.Label13.Text = "Project Insurance"
        '
        'txtProjectInsurance
        '
        Me.txtProjectInsurance.Enabled = False
        Me.txtProjectInsurance.Location = New System.Drawing.Point(837, 60)
        Me.txtProjectInsurance.Name = "txtProjectInsurance"
        Me.txtProjectInsurance.Size = New System.Drawing.Size(148, 20)
        Me.txtProjectInsurance.TabIndex = 215
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(726, 19)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(89, 13)
        Me.Label12.TabIndex = 216
        Me.Label12.Text = "Project Retention"
        '
        'txtProjectRetention
        '
        Me.txtProjectRetention.Location = New System.Drawing.Point(837, 15)
        Me.txtProjectRetention.Name = "txtProjectRetention"
        Me.txtProjectRetention.Size = New System.Drawing.Size(148, 20)
        Me.txtProjectRetention.TabIndex = 217
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(5, 193)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(96, 13)
        Me.Label20.TabIndex = 220
        Me.Label20.Text = "Project Description"
        '
        'txtProjectDesc
        '
        Me.txtProjectDesc.Location = New System.Drawing.Point(129, 193)
        Me.txtProjectDesc.Name = "txtProjectDesc"
        Me.txtProjectDesc.Size = New System.Drawing.Size(161, 20)
        Me.txtProjectDesc.TabIndex = 221
        '
        'dtpStart
        '
        Me.dtpStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpStart.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpStart.Location = New System.Drawing.Point(451, 56)
        Me.dtpStart.Name = "dtpStart"
        Me.dtpStart.Size = New System.Drawing.Size(186, 21)
        Me.dtpStart.TabIndex = 255
        '
        'dtpEnd
        '
        Me.dtpEnd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpEnd.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpEnd.Location = New System.Drawing.Point(449, 105)
        Me.dtpEnd.Name = "dtpEnd"
        Me.dtpEnd.Size = New System.Drawing.Size(187, 21)
        Me.dtpEnd.TabIndex = 256
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Enabled = False
        Me.Label19.Location = New System.Drawing.Point(726, 114)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(81, 13)
        Me.Label19.TabIndex = 261
        Me.Label19.Text = "Project Security"
        '
        'txtProjectSecurity
        '
        Me.txtProjectSecurity.Enabled = False
        Me.txtProjectSecurity.Location = New System.Drawing.Point(837, 111)
        Me.txtProjectSecurity.Name = "txtProjectSecurity"
        Me.txtProjectSecurity.Size = New System.Drawing.Size(148, 20)
        Me.txtProjectSecurity.TabIndex = 262
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(726, 147)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(86, 13)
        Me.Label18.TabIndex = 263
        Me.Label18.Text = "Project Penalties"
        '
        'txtProjectPenalties
        '
        Me.txtProjectPenalties.Location = New System.Drawing.Point(837, 147)
        Me.txtProjectPenalties.Name = "txtProjectPenalties"
        Me.txtProjectPenalties.Size = New System.Drawing.Size(148, 20)
        Me.txtProjectPenalties.TabIndex = 264
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(699, 193)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(116, 13)
        Me.Label17.TabIndex = 265
        Me.Label17.Text = "Project Payment Terms"
        '
        'txtProjectPaymentTerms
        '
        Me.txtProjectPaymentTerms.Location = New System.Drawing.Point(837, 190)
        Me.txtProjectPaymentTerms.Name = "txtProjectPaymentTerms"
        Me.txtProjectPaymentTerms.Size = New System.Drawing.Size(148, 20)
        Me.txtProjectPaymentTerms.TabIndex = 266
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(700, 244)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(115, 13)
        Me.Label16.TabIndex = 267
        Me.Label16.Text = "Project Default Interest"
        '
        'txtProjectDefaultInt
        '
        Me.txtProjectDefaultInt.Location = New System.Drawing.Point(837, 241)
        Me.txtProjectDefaultInt.Name = "txtProjectDefaultInt"
        Me.txtProjectDefaultInt.Size = New System.Drawing.Size(148, 20)
        Me.txtProjectDefaultInt.TabIndex = 268
        '
        'cmbContractType
        '
        Me.cmbContractType.FormattingEnabled = True
        Me.cmbContractType.Items.AddRange(New Object() {"long term", "short term", "consignment"})
        Me.cmbContractType.Location = New System.Drawing.Point(450, 11)
        Me.cmbContractType.Name = "cmbContractType"
        Me.cmbContractType.Size = New System.Drawing.Size(187, 21)
        Me.cmbContractType.TabIndex = 271
        '
        'btnSearchDebtorID
        '
        Me.btnSearchDebtorID.Location = New System.Drawing.Point(8, 102)
        Me.btnSearchDebtorID.Name = "btnSearchDebtorID"
        Me.btnSearchDebtorID.Size = New System.Drawing.Size(104, 23)
        Me.btnSearchDebtorID.TabIndex = 331
        Me.btnSearchDebtorID.Text = "Search Debtor ID"
        Me.btnSearchDebtorID.UseVisualStyleBackColor = True
        '
        'btnSearchDeptCode
        '
        Me.btnSearchDeptCode.Location = New System.Drawing.Point(8, 53)
        Me.btnSearchDeptCode.Name = "btnSearchDeptCode"
        Me.btnSearchDeptCode.Size = New System.Drawing.Size(104, 23)
        Me.btnSearchDeptCode.TabIndex = 332
        Me.btnSearchDeptCode.Text = "Search Dept Code"
        Me.btnSearchDeptCode.UseVisualStyleBackColor = True
        '
        'txtDebtorID
        '
        Me.txtDebtorID.Location = New System.Drawing.Point(129, 102)
        Me.txtDebtorID.Name = "txtDebtorID"
        Me.txtDebtorID.Size = New System.Drawing.Size(161, 20)
        Me.txtDebtorID.TabIndex = 330
        Me.txtDebtorID.Text = "Debtor Id"
        '
        'txtDeptCode
        '
        Me.txtDeptCode.Location = New System.Drawing.Point(129, 54)
        Me.txtDeptCode.Name = "txtDeptCode"
        Me.txtDeptCode.Size = New System.Drawing.Size(161, 20)
        Me.txtDeptCode.TabIndex = 329
        Me.txtDeptCode.Text = "Department Code"
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(910, 608)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 333
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'frmProjectCode
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(991, 633)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnSearchDebtorID)
        Me.Controls.Add(Me.btnSearchDeptCode)
        Me.Controls.Add(Me.txtDebtorID)
        Me.Controls.Add(Me.txtDeptCode)
        Me.Controls.Add(Me.cmbContractType)
        Me.Controls.Add(Me.txtProjectDefaultInt)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.txtProjectPaymentTerms)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.txtProjectPenalties)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.txtProjectSecurity)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.dtpEnd)
        Me.Controls.Add(Me.dtpStart)
        Me.Controls.Add(Me.txtProjectDesc)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.txtProjectRetention)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txtProjectInsurance)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtProjectMargin)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.ype)
        Me.Controls.Add(Me.txtProjectAddress)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtProjectName)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtProjectVal)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtDuration)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.txtProjectCode)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmProjectCode"
        Me.Text = "PROJECTS"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnAdd As Button
    Friend WithEvents btnSearch As Button
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents txtProjectCode As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtDuration As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtProjectVal As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtProjectName As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtProjectAddress As TextBox
    Friend WithEvents ype As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents txtProjectMargin As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtProjectInsurance As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txtProjectRetention As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents txtProjectDesc As TextBox
    Friend WithEvents dtpStart As DateTimePicker
    Friend WithEvents dtpEnd As DateTimePicker
    Friend WithEvents Label19 As Label
    Friend WithEvents txtProjectSecurity As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents txtProjectPenalties As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents txtProjectPaymentTerms As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents txtProjectDefaultInt As TextBox
    Friend WithEvents cmbContractType As ComboBox
    Friend WithEvents btnSearchDebtorID As Button
    Friend WithEvents btnSearchDeptCode As Button
    Friend WithEvents txtDebtorID As TextBox
    Friend WithEvents txtDeptCode As TextBox
    Friend WithEvents btnHome As Button
End Class
