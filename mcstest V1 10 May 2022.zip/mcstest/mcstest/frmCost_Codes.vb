﻿Public Class frmCost_Codes

    'This declaration is required for UPDATE statement

    Public IDkey As Long

    'sub procedure to be reused to fetch/load data from database tables
    Public Sub connectToDB()

        Try
            'establish connection to DB
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            'select sql statement to view only
            sqlcomm.CommandText = "SELECT* FROM T_CostCodes"
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()

            'populate the datagridview
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Public Sub cSearchID()

        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            'sql to view/open then fetch specific row of data in the table
            sqlcomm.CommandText = "SELECT* FROM T_CostCodes WHERE CostCode=@AID"
            Dim allocID As New OleDb.OleDbParameter("@AID", Val(txtID.Text))
            sqlcomm.Parameters.Add(allocID)
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Public Sub cSearchDesc()

        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()

            sqlcomm.Connection = cn
            sqlcomm.CommandText = "SELECT* FROM T_CostCodes WHERE CostCodeDescription=@AD"

            Dim allocdis As New OleDb.OleDbParameter("@AD", txtCostDesc.Text)

            sqlcomm.Parameters.Add(allocdis)
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub



    Private Sub Cost_Codes_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        connectToDB()

    End Sub


    Private Sub btnsearchclassifications_Click(sender As Object, e As EventArgs) Handles btnsearchclassifications.Click

        Try
            frmCLASSIFICATION.Show()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub


    'button to insert costcode items
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "INSERT INTO T_CostCodes (CostCode,CostCodeDescription,ClassificationID,CostCodeStatus) VALUES (@CID,@Cdescr,@Allocat,@Actve)"

            Dim Cdescri As New OleDb.OleDbParameter("@CID", Val(txtcodeID.Text))
            'IDN for id number
            Dim CIDN As New OleDb.OleDbParameter("@Cdescr", txtcodedescrip.Text)
            Dim AID As New OleDb.OleDbParameter("@Allocat", Val(txtClassiID.Text))
            Dim checkstatus As New OleDb.OleDbParameter("@Actve", ComboBox1.SelectedItem)

            sqlcomm.Parameters.Add(Cdescri)
            sqlcomm.Parameters.Add(CIDN)
            sqlcomm.Parameters.Add(AID)
            sqlcomm.Parameters.Add(checkstatus)

            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            connectToDB()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub txtID_TextChanged(sender As Object, e As EventArgs) Handles txtID.TextChanged
        cSearchID()
    End Sub


    Private Sub txtCostDesc_TextChanged(sender As Object, e As EventArgs) Handles txtCostDesc.TextChanged
        cSearchDesc()
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        Try
            'update sql statement
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()

            sqlcomm.Connection = cn
            sqlcomm.CommandText = "UPDATE T_CostCodes SET CostCodeStatus=@Actve WHERE CostCode=@IDKey"


            Dim Cdescri As New OleDb.OleDbParameter("@IDKey", Val(txtcodeID.Text))
            'IDN for id number
            Dim checkstatus As New OleDb.OleDbParameter("@Actve", ComboBox1.SelectedItem)

            sqlcomm.Parameters.Add(checkstatus)
            sqlcomm.Parameters.Add(Cdescri)


            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            connectToDB()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

        Try
            'Declaring Variables
            Dim CostCode As String = DataGridView1.CurrentCell.Value
            Dim CostCodeDescription As String = DataGridView1.CurrentCell.Value
            Dim CostCodeStatus As String = DataGridView1.CurrentCell.Value

            'Assigning Variables
            FRMResources.txtCostcode.Text = CostCode
            txtcodedescrip.Text = CostCodeDescription

            Me.Close()
            FRMResources.Show()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    'when user puts mouse in text box it clears it
    Private Sub txtID_MouseDown(sender As Object, e As MouseEventArgs) Handles txtID.MouseDown
        txtID.Clear()
    End Sub

    'when user puts mouse in text box it clears it
    Private Sub txtCostDesc_MouseDown(sender As Object, e As MouseEventArgs) Handles txtCostDesc.MouseDown
        txtCostDesc.Clear()
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmNavigation.Show()
        Me.Close()
    End Sub
End Class