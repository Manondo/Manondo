﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FRMResources
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblID = New System.Windows.Forms.Label()
        Me.btnsearchclassifications = New System.Windows.Forms.Button()
        Me.txtRID = New System.Windows.Forms.TextBox()
        Me.txtRtype = New System.Windows.Forms.TextBox()
        Me.lblclassi = New System.Windows.Forms.Label()
        Me.txtRDesc = New System.Windows.Forms.TextBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lblAdd = New System.Windows.Forms.Label()
        Me.txtRdescrip = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtCostcode = New System.Windows.Forms.TextBox()
        Me.txtRrate = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtRunit = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Location = New System.Drawing.Point(47, 25)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(140, 13)
        Me.lblID.TabIndex = 30
        Me.lblID.Text = "ENTER RESOURCE CODE"
        '
        'btnsearchclassifications
        '
        Me.btnsearchclassifications.Location = New System.Drawing.Point(297, 132)
        Me.btnsearchclassifications.Name = "btnsearchclassifications"
        Me.btnsearchclassifications.Size = New System.Drawing.Size(134, 23)
        Me.btnsearchclassifications.TabIndex = 34
        Me.btnsearchclassifications.Text = "Search  Resource Type"
        Me.btnsearchclassifications.UseVisualStyleBackColor = True
        '
        'txtRID
        '
        Me.txtRID.Location = New System.Drawing.Point(210, 18)
        Me.txtRID.Name = "txtRID"
        Me.txtRID.Size = New System.Drawing.Size(221, 20)
        Me.txtRID.TabIndex = 31
        '
        'txtRtype
        '
        Me.txtRtype.Location = New System.Drawing.Point(210, 135)
        Me.txtRtype.Name = "txtRtype"
        Me.txtRtype.Size = New System.Drawing.Size(81, 20)
        Me.txtRtype.TabIndex = 33
        '
        'lblclassi
        '
        Me.lblclassi.AutoSize = True
        Me.lblclassi.Location = New System.Drawing.Point(54, 142)
        Me.lblclassi.Name = "lblclassi"
        Me.lblclassi.Size = New System.Drawing.Size(138, 13)
        Me.lblclassi.TabIndex = 32
        Me.lblclassi.Text = "ENTER RESOURCE TYPE"
        '
        'txtRDesc
        '
        Me.txtRDesc.Location = New System.Drawing.Point(318, 18)
        Me.txtRDesc.Name = "txtRDesc"
        Me.txtRDesc.Size = New System.Drawing.Size(224, 20)
        Me.txtRDesc.TabIndex = 40
        Me.txtRDesc.Text = "Insert Description to search"
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(12, 18)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(227, 20)
        Me.txtID.TabIndex = 39
        Me.txtID.Text = "Insert ID to search"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(210, 280)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(221, 32)
        Me.btnAdd.TabIndex = 25
        Me.btnAdd.Text = "ADD RESOURCE ITEM"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'lblAdd
        '
        Me.lblAdd.AutoSize = True
        Me.lblAdd.Location = New System.Drawing.Point(4, 55)
        Me.lblAdd.Name = "lblAdd"
        Me.lblAdd.Size = New System.Drawing.Size(183, 13)
        Me.lblAdd.TabIndex = 26
        Me.lblAdd.Text = "ENTER RESOURCE DESCRIPTION"
        '
        'txtRdescrip
        '
        Me.txtRdescrip.Location = New System.Drawing.Point(210, 48)
        Me.txtRdescrip.Name = "txtRdescrip"
        Me.txtRdescrip.Size = New System.Drawing.Size(221, 20)
        Me.txtRdescrip.TabIndex = 27
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.txtCostcode)
        Me.GroupBox1.Controls.Add(Me.txtRrate)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtRunit)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.lblID)
        Me.GroupBox1.Controls.Add(Me.btnsearchclassifications)
        Me.GroupBox1.Controls.Add(Me.txtRID)
        Me.GroupBox1.Controls.Add(Me.btnAdd)
        Me.GroupBox1.Controls.Add(Me.txtRtype)
        Me.GroupBox1.Controls.Add(Me.lblclassi)
        Me.GroupBox1.Controls.Add(Me.lblAdd)
        Me.GroupBox1.Controls.Add(Me.txtRdescrip)
        Me.GroupBox1.Location = New System.Drawing.Point(583, 46)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(446, 318)
        Me.GroupBox1.TabIndex = 41
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "ADD RESOURCE ITEM"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(297, 96)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(134, 23)
        Me.Button1.TabIndex = 42
        Me.Button1.Text = "Search  Cost Code"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtCostcode
        '
        Me.txtCostcode.Location = New System.Drawing.Point(210, 98)
        Me.txtCostcode.Name = "txtCostcode"
        Me.txtCostcode.Size = New System.Drawing.Size(81, 20)
        Me.txtCostcode.TabIndex = 41
        '
        'txtRrate
        '
        Me.txtRrate.Location = New System.Drawing.Point(210, 223)
        Me.txtRrate.Name = "txtRrate"
        Me.txtRrate.Size = New System.Drawing.Size(221, 20)
        Me.txtRrate.TabIndex = 40
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(57, 226)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(139, 13)
        Me.Label3.TabIndex = 39
        Me.Label3.Text = "ENTER RESOURCE RATE"
        '
        'txtRunit
        '
        Me.txtRunit.Location = New System.Drawing.Point(210, 182)
        Me.txtRunit.Name = "txtRunit"
        Me.txtRunit.Size = New System.Drawing.Size(221, 20)
        Me.txtRunit.TabIndex = 38
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 185)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(192, 13)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "ENTER RESOURCE UNIT MEASURE"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(80, 101)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 13)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "ENTER COST CODE "
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(12, 60)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(530, 298)
        Me.DataGridView1.TabIndex = 38
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(976, 387)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 190
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'FRMResources
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1054, 411)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.txtRDesc)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "FRMResources"
        Me.Text = "RESOURCES"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblID As Label
    Friend WithEvents btnsearchclassifications As Button
    Friend WithEvents txtRID As TextBox
    Friend WithEvents txtRtype As TextBox
    Friend WithEvents lblclassi As Label
    Friend WithEvents txtRDesc As TextBox
    Friend WithEvents txtID As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents lblAdd As Label
    Friend WithEvents txtRdescrip As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Button1 As Button
    Friend WithEvents txtCostcode As TextBox
    Friend WithEvents txtRrate As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtRunit As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnHome As Button
End Class
