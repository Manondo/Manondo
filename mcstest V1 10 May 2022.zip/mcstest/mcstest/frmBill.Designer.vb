﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBill
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.txtPriceCodeResourcingRate = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.txtSearchBillToEdit = New System.Windows.Forms.TextBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.btnImport = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.txtProjCode = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtProjName = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtcurrentBill = New System.Windows.Forms.TextBox()
        Me.btnprojcode = New System.Windows.Forms.Button()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column17 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnhide = New System.Windows.Forms.Button()
        Me.btnshowprev = New System.Windows.Forms.Button()
        Me.btnshownext = New System.Windows.Forms.Button()
        Me.btnshowall = New System.Windows.Forms.Button()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtPriceCodeResourcingRate
        '
        Me.txtPriceCodeResourcingRate.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtPriceCodeResourcingRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceCodeResourcingRate.ForeColor = System.Drawing.SystemColors.Window
        Me.txtPriceCodeResourcingRate.Location = New System.Drawing.Point(563, 64)
        Me.txtPriceCodeResourcingRate.Name = "txtPriceCodeResourcingRate"
        Me.txtPriceCodeResourcingRate.Size = New System.Drawing.Size(126, 20)
        Me.txtPriceCodeResourcingRate.TabIndex = 134
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(415, 67)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(142, 13)
        Me.Label11.TabIndex = 133
        Me.Label11.Text = "Price Code Resourcing Rate"
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(648, 12)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(41, 23)
        Me.btnSearch.TabIndex = 108
        Me.btnSearch.Text = "Go"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'txtSearchBillToEdit
        '
        Me.txtSearchBillToEdit.Location = New System.Drawing.Point(563, 12)
        Me.txtSearchBillToEdit.Name = "txtSearchBillToEdit"
        Me.txtSearchBillToEdit.Size = New System.Drawing.Size(79, 20)
        Me.txtSearchBillToEdit.TabIndex = 107
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(623, 663)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(114, 23)
        Me.btnClear.TabIndex = 105
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(373, 660)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(137, 23)
        Me.btnSave.TabIndex = 102
        Me.btnSave.Text = "Export / Update Bill"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(121, 660)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(125, 23)
        Me.btnCalculate.TabIndex = 187
        Me.btnCalculate.Text = "Calculate Active Row"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(1283, 663)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 188
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'btnImport
        '
        Me.btnImport.Location = New System.Drawing.Point(851, 663)
        Me.btnImport.Name = "btnImport"
        Me.btnImport.Size = New System.Drawing.Size(137, 23)
        Me.btnImport.TabIndex = 189
        Me.btnImport.Text = "Import From Excel"
        Me.btnImport.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(1143, 660)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 26)
        Me.Button3.TabIndex = 191
        Me.Button3.Text = "Finalized"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'txtProjCode
        '
        Me.txtProjCode.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtProjCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProjCode.ForeColor = System.Drawing.SystemColors.Window
        Me.txtProjCode.Location = New System.Drawing.Point(121, 5)
        Me.txtProjCode.Name = "txtProjCode"
        Me.txtProjCode.Size = New System.Drawing.Size(125, 20)
        Me.txtProjCode.TabIndex = 194
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 13)
        Me.Label1.TabIndex = 193
        Me.Label1.Text = "Project Code"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(415, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(113, 13)
        Me.Label2.TabIndex = 195
        Me.Label2.Text = "Select Bill No. To Edit:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(37, 35)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 196
        Me.Label3.Text = "Project Name"
        '
        'txtProjName
        '
        Me.txtProjName.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtProjName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProjName.ForeColor = System.Drawing.SystemColors.Window
        Me.txtProjName.Location = New System.Drawing.Point(121, 32)
        Me.txtProjName.Name = "txtProjName"
        Me.txtProjName.Size = New System.Drawing.Size(206, 20)
        Me.txtProjName.TabIndex = 197
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 67)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(102, 13)
        Me.Label4.TabIndex = 200
        Me.Label4.Text = "Enter Current Bill No"
        '
        'txtcurrentBill
        '
        Me.txtcurrentBill.Location = New System.Drawing.Point(121, 62)
        Me.txtcurrentBill.Name = "txtcurrentBill"
        Me.txtcurrentBill.Size = New System.Drawing.Size(206, 20)
        Me.txtcurrentBill.TabIndex = 198
        '
        'btnprojcode
        '
        Me.btnprojcode.Location = New System.Drawing.Point(252, 5)
        Me.btnprojcode.Name = "btnprojcode"
        Me.btnprojcode.Size = New System.Drawing.Size(75, 23)
        Me.btnprojcode.TabIndex = 201
        Me.btnprojcode.Text = "Search"
        Me.btnprojcode.UseVisualStyleBackColor = True
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6, Me.Column7, Me.Column8, Me.Column9, Me.Column10, Me.Column11, Me.Column12, Me.Column13, Me.Column14, Me.Column15, Me.Column16, Me.Column17})
        Me.DataGridView2.Location = New System.Drawing.Point(9, 130)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(1348, 514)
        Me.DataGridView2.TabIndex = 205
        '
        'Column1
        '
        Me.Column1.HeaderText = "ITEM NO"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "DESCRIPTION"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.HeaderText = "UNIT"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.HeaderText = "QUANTITY"
        Me.Column4.Name = "Column4"
        '
        'Column5
        '
        Me.Column5.HeaderText = "NET RATE"
        Me.Column5.Name = "Column5"
        '
        'Column6
        '
        Me.Column6.HeaderText = "MARK-UP"
        Me.Column6.Name = "Column6"
        '
        'Column7
        '
        Me.Column7.HeaderText = "SELLING RATE"
        Me.Column7.Name = "Column7"
        '
        'Column8
        '
        Me.Column8.HeaderText = "BILL ITEM NO"
        Me.Column8.Name = "Column8"
        '
        'Column9
        '
        Me.Column9.HeaderText = "BILL TRADE ID"
        Me.Column9.Name = "Column9"
        '
        'Column10
        '
        Me.Column10.HeaderText = "PRICE CODE"
        Me.Column10.Name = "Column10"
        '
        'Column11
        '
        Me.Column11.HeaderText = "START DATE"
        Me.Column11.Name = "Column11"
        '
        'Column12
        '
        Me.Column12.HeaderText = "END DATE"
        Me.Column12.Name = "Column12"
        '
        'Column13
        '
        Me.Column13.HeaderText = "DURATION"
        Me.Column13.Name = "Column13"
        '
        'Column14
        '
        Me.Column14.HeaderText = "NET AMOUNT"
        Me.Column14.Name = "Column14"
        '
        'Column15
        '
        Me.Column15.HeaderText = "MARK-UP AMOUNT"
        Me.Column15.Name = "Column15"
        '
        'Column16
        '
        Me.Column16.HeaderText = "SELLING AMOUNT"
        Me.Column16.Name = "Column16"
        '
        'Column17
        '
        Me.Column17.HeaderText = "Submitted"
        Me.Column17.Name = "Column17"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.GridColor = System.Drawing.SystemColors.HotTrack
        Me.DataGridView1.Location = New System.Drawing.Point(10, 130)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(1347, 514)
        Me.DataGridView1.TabIndex = 204
        Me.DataGridView1.Visible = False
        '
        'btnhide
        '
        Me.btnhide.BackColor = System.Drawing.Color.LightCoral
        Me.btnhide.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhide.Location = New System.Drawing.Point(758, 2)
        Me.btnhide.Name = "btnhide"
        Me.btnhide.Size = New System.Drawing.Size(246, 23)
        Me.btnhide.TabIndex = 211
        Me.btnhide.Text = " HIDE SELECTED COLUMN"
        Me.btnhide.UseVisualStyleBackColor = False
        '
        'btnshowprev
        '
        Me.btnshowprev.BackColor = System.Drawing.Color.Turquoise
        Me.btnshowprev.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnshowprev.Location = New System.Drawing.Point(757, 31)
        Me.btnshowprev.Name = "btnshowprev"
        Me.btnshowprev.Size = New System.Drawing.Size(246, 23)
        Me.btnshowprev.TabIndex = 210
        Me.btnshowprev.Text = "<<< SHOW PREVIOUS HIDDEN COLUMN"
        Me.btnshowprev.UseVisualStyleBackColor = False
        '
        'btnshownext
        '
        Me.btnshownext.BackColor = System.Drawing.Color.Turquoise
        Me.btnshownext.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnshownext.Location = New System.Drawing.Point(756, 57)
        Me.btnshownext.Name = "btnshownext"
        Me.btnshownext.Size = New System.Drawing.Size(247, 23)
        Me.btnshownext.TabIndex = 209
        Me.btnshownext.Text = "SHOW NEXT HIDDEN COLUMN >>>"
        Me.btnshownext.UseVisualStyleBackColor = False
        '
        'btnshowall
        '
        Me.btnshowall.BackColor = System.Drawing.Color.Chartreuse
        Me.btnshowall.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnshowall.Location = New System.Drawing.Point(758, 86)
        Me.btnshowall.Name = "btnshowall"
        Me.btnshowall.Size = New System.Drawing.Size(247, 23)
        Me.btnshowall.TabIndex = 212
        Me.btnshowall.Text = "SHOW ALL COLUMNS"
        Me.btnshowall.UseVisualStyleBackColor = False
        '
        'frmBill
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 693)
        Me.Controls.Add(Me.btnshowall)
        Me.Controls.Add(Me.btnhide)
        Me.Controls.Add(Me.btnshowprev)
        Me.Controls.Add(Me.btnshownext)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnprojcode)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtcurrentBill)
        Me.Controls.Add(Me.txtProjName)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtProjCode)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.btnImport)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtPriceCodeResourcingRate)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.txtSearchBillToEdit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnSave)
        Me.Name = "frmBill"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "BILL"
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtPriceCodeResourcingRate As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents btnSearch As Button
    Friend WithEvents txtSearchBillToEdit As TextBox
    Friend WithEvents btnClear As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnHome As Button
    Friend WithEvents btnImport As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents txtProjCode As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtProjName As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtcurrentBill As TextBox
    Friend WithEvents btnprojcode As Button
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnhide As Button
    Friend WithEvents btnshowprev As Button
    Friend WithEvents btnshownext As Button
    Friend WithEvents btnshowall As Button
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents Column10 As DataGridViewTextBoxColumn
    Friend WithEvents Column11 As DataGridViewTextBoxColumn
    Friend WithEvents Column12 As DataGridViewTextBoxColumn
    Friend WithEvents Column13 As DataGridViewTextBoxColumn
    Friend WithEvents Column14 As DataGridViewTextBoxColumn
    Friend WithEvents Column15 As DataGridViewTextBoxColumn
    Friend WithEvents Column16 As DataGridViewTextBoxColumn
    Friend WithEvents Column17 As DataGridViewComboBoxColumn
End Class
