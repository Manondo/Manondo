﻿Imports System.Data.OleDb
Imports System.Math
Public Class frmValuation

    Dim indexk As Integer

    Dim columnindex As Integer = 0


    'Declaring Dynamic Arrays
    Dim itemno() As String
    Dim descr() As String
    Dim unit() As String
    Dim qty() As String
    Dim Net() As String
    Dim Amount() As String
    Dim Markup() As String
    Dim BillItemno() As String
    Dim TradeID() As String
    Dim Pricecode() As String
    Dim startdate() As String
    Dim enddate() As String
    Dim duration() As String
    Dim sellingamount() As String
    Dim netamount() As String
    Dim markupamount() As String


    Dim xl As Integer
    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C: Relational Database Design Estimating Rev2.accdb")
    Private ts As Object
    Private e As Object


    'sub procedure for: Bill Net Rate is on price code form


    'sub procedure to calculate and display results in appropriate rows
    'calculate bill selling rate: (BillNetRate+BillMarkup)
    Public Sub BillSellingRate()

        Try
            Dim sellingrate, netrate, markup As Decimal
            Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index
            markup = Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(5).Value) / 100
            netrate = Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(4).Value)

            sellingrate = netrate + (netrate * markup)

            DataGridView2.Rows(selectedrow1).Cells(6).Value = Round(sellingrate, 2)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub


    'calculate Net Amount:formula is Billqty x Bill Net Rate
    Public Sub BillNetAmount()

        Try
            Dim netAmount As Decimal
            Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index

            Dim billQty1 As Decimal = Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(3).Value)


            netAmount = Round((Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(4).Value) * billQty1), 2)

            DataGridView2.Rows(selectedrow1).Cells(13).Value = netAmount

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try



    End Sub

    'calculate Mark up amount,formula: Bill net Amount* Bill Mark up percentage
    Public Sub aMarkupAmount()

        Try
            Dim billnetAmount, markupAmount1, markup As Decimal
            Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index

            billnetAmount = Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(13).Value)
            markup = Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(5).Value) / 100
            markupAmount1 = billnetAmount * markup

            DataGridView2.Rows(selectedrow1).Cells(14).Value = Round(Convert.ToDecimal(markupAmount1), 2)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub


    'calculate  BillSellingAmount,formula: Bill net Amount + Mark up amount
    Public Sub BillSellingAmount()
        Try
            Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index

            Dim billnetAmount, markupAmount, sellingAmount As Decimal

            billnetAmount = Round(Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(13).Value), 2)
            markupAmount = Round(Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(14).Value), 2)
            sellingAmount = billnetAmount + markupAmount

            DataGridView2.Rows(selectedrow1).Cells(15).Value = Round(sellingAmount, 2)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    ' 'calculate final selling amount, Formula: Selling Rate * BillFinalQty
    Public Sub BillFinalSellingAmount()
        Dim finalsellingAmount, billfinalqty, sellingAmountRate As Decimal
        Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index
        billfinalqty = DataGridView2.Rows(selectedrow1).Cells(21).Value
        sellingAmountRate = DataGridView2.Rows(selectedrow1).Cells(5).Value
        finalsellingAmount = billfinalqty * sellingAmountRate

        DataGridView2.Rows(selectedrow1).Cells(25).Value = Round(Convert.ToDecimal(finalsellingAmount), 2)

    End Sub

    'calculate remeasured qty
    Public Sub BillRemeasureQty()
        Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index
        Dim billmeasureqty, finalqty, billqty As Decimal
        finalqty = DataGridView2.Rows(selectedrow1).Cells(21).Value
        billqty = DataGridView2.Rows(selectedrow1).Cells(3).Value

        billmeasureqty = finalqty - billqty

        DataGridView2.Rows(selectedrow1).Cells(29).Value = billmeasureqty

    End Sub


    'calculate remeasured selling amount, formula: final selling amount - selling amount
    Public Sub BillRemeasureSellingAmount()
        Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index
        Dim billmeasureSellingAmount, finalSellingamount, Sellingamount As Decimal
        finalSellingamount = Round(Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(25).Value), 2)
        Sellingamount = Round(Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(16).Value), 2)

        billmeasureSellingAmount = finalSellingamount - Sellingamount

        DataGridView2.Rows(selectedrow1).Cells(31).Value = billmeasureSellingAmount

    End Sub


    'calculate BillActualSellingAmount Formula:(BillActualQty x BillSellingRate)
    Public Sub BillActualSellingAmount()
        Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index
        Dim billactualSellingamount, billactualqty, sellingrate As Decimal
        sellingrate = DataGridView2.Rows(selectedrow1).Cells(5).Value
        billactualqty = DataGridView2.Rows(selectedrow1).Cells(17).Value

        billactualSellingamount = billactualqty * sellingrate

        DataGridView2.Rows(selectedrow1).Cells(33).Value = Round(Convert.ToDecimal(billactualSellingamount), 2)
    End Sub


    'calculate BillClaimedAmount:BillClaimedQty x BillSellingRate
    Public Sub BillClaimedAmount()

        Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index
        Dim billclaimedamount, billclaimedqty, sellingrate As Decimal
        sellingrate = DataGridView2.Rows(selectedrow1).Cells(5).Value
        billclaimedqty = DataGridView2.Rows(selectedrow1).Cells(18).Value

        billclaimedamount = billclaimedqty * sellingrate

        DataGridView2.Rows(selectedrow1).Cells(34).Value = billclaimedamount
    End Sub


    'calculate BillCertifiedAmount: BillCertifiedQty x BillSellingRate
    Public Sub BillCertifiedAmount()
        Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index
        Dim billcertifiedamount, billcertifiedqty, sellingrate As Decimal
        sellingrate = DataGridView2.Rows(selectedrow1).Cells(5).Value
        billcertifiedqty = DataGridView2.Rows(selectedrow1).Cells(19).Value

        billcertifiedamount = billcertifiedqty * sellingrate

        DataGridView2.Rows(selectedrow1).Cells(35).Value = Round(Convert.ToDecimal(billcertifiedamount), 2)

    End Sub

    'calculate BillPaidAmount: BillPaidQty x BillSellingRate
    Public Sub BillPaidAmount()
        Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index
        Dim billpaidamount, billpaidqty, sellingrate As Decimal
        sellingrate = DataGridView2.Rows(selectedrow1).Cells(5).Value
        billpaidqty = DataGridView2.Rows(selectedrow1).Cells(20).Value

        billpaidamount = billpaidqty * sellingrate

        DataGridView2.Rows(selectedrow1).Cells(36).Value = Round(Convert.ToDecimal(billpaidamount), 2)
    End Sub


    'calculate final net amount, formula: BillFinalQty x BillFinalNetRate
    Public Sub BillFinalNetAmount()
        Dim billFinalNetAmount, finalqty, finalnetRate As Decimal
        Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index

        finalqty = DataGridView2.Rows(selectedrow1).Cells(21).Value
        finalnetRate = DataGridView2.Rows(selectedrow1).Cells(22).Value

        billFinalNetAmount = finalqty * finalnetRate

        DataGridView2.Rows(selectedrow1).Cells(24).Value = Round(Convert.ToDecimal(billFinalNetAmount), 2)

    End Sub



    'calculate remeasured net amount: BillFinalNetAmount - BillNetAmount
    Public Sub BillRemeasureNetAmount()
        Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index

        Dim billmeasurenetamount, finalnetamount, netamount As Decimal
        finalnetamount = DataGridView2.Rows(selectedrow1).Cells(24).Value
        netamount = DataGridView2.Rows(selectedrow1).Cells(14).Value

        billmeasurenetamount = finalnetamount - netamount

        DataGridView2.Rows(selectedrow1).Cells(30).Value = Round(Convert.ToDecimal(billmeasurenetamount), 2)

    End Sub



    'calculate actual net amount:BillActualQty x BillFinalNetRate
    Public Sub BillActualNetAmount()
        Dim billactualnetamount, billactualqty, finalnetrate As Decimal
        Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index

        finalnetrate = DataGridView2.Rows(selectedrow1).Cells(22).Value
        billactualqty = DataGridView2.Rows(selectedrow1).Cells(17).Value

        billactualnetamount = billactualqty * finalnetrate

        DataGridView2.Rows(selectedrow1).Cells(32).Value = Round(Convert.ToDecimal(billactualnetamount), 2)

    End Sub

    'sub to calculate Actual duration. Formula: End date - Start Date

    Public Sub BillActualDuration()
        Try
            If True Then

                Dim dt1 As DateTime = Convert.ToDateTime(frmDatePickerStart.DateTimePicker1.Value)
                Dim dt2 As DateTime = Convert.ToDateTime(frmDatePickerEnd.DateTimePicker1.Value)


                Dim ts As TimeSpan = dt2.Subtract(dt1)

                'get current selected row
                Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index

                If Convert.ToInt32(ts.Days) >= 0 Then

                    DataGridView2.Rows(selectedrow1).Cells(8).Value = Convert.ToInt32(ts.Days)
                Else

                    MessageBox.Show("Invalid Input")

                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    'sub to clear all textboxes
    Public Sub clear()
        Try

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Dim txt As Control
        For Each txt In Controls
            If TypeOf txt Is TextBox Then
                txt.Text = ""
            End If
        Next
    End Sub

    'sub procedure to search by id in DB table
    Public Sub cSearchID()
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            'sql to view/open then fetch specific row of data in the table
            sqlcomm.CommandText = "SELECT* FROM T_Bill WHERE BillCode=@AIDE"
            Dim searchID As New OleDb.OleDbParameter("@AID", Val(txtSearchBillToEdit.Text))
            sqlcomm.Parameters.Add(searchID)
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()
            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub



    'sub procedure to display or refresh the T_Bill data on the datagridview

    Private Sub bind_data()
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            sqlcomm.CommandText = "SELECT* FROM T_Bill"

            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()

            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    'sub to calculate duration. Formula: End date - Start Date

    Public Sub BillItemDuration()
        Try
            If True Then

                Dim dt1 As DateTime = Convert.ToDateTime(frmDatePickerStart.DateTimePicker1.Value)
                Dim dt2 As DateTime = Convert.ToDateTime(frmDatePickerEnd.DateTimePicker1.Value)


                Dim ts As TimeSpan = dt2.Subtract(dt1)

                'get current selected row
                Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index

                If Convert.ToInt32(ts.Days) >= 0 Then

                    DataGridView2.Rows(selectedrow1).Cells(8).Value = Convert.ToInt32(ts.Days)
                Else

                    MessageBox.Show("Invalid Input")

                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        Try
            frmNavigation.Show()
            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub


    '    'FREEZE THE ITEM NO AND DESCRIPTION---code will use to freeze columns
    '    DataGridView2.Columns(0).Frozen = True
    '        DataGridView2.Columns(1).Frozen = True





    '        Dim indexd As Integer = DataGridView1.Rows.Count

    '        For i As Integer = 0 To DataGridView1.Rows.Count - 1

    '            Dim item1 As String
    '            Dim description1 As String
    '            Dim unit1 As String
    '            Dim qty1 As String
    '            'Dim netrate1 As Decimal
    '            ''selling rate
    '            'Dim amount1 As String
    '            'Dim markup1 As String
    '            'Dim billitemno1 As String
    '            'Dim tradeid1 As String
    '            'Dim pricecode1 As String
    '            'Dim startdate1 As String
    '            'Dim enddate1 As String
    '            'Dim duration1 As String
    '            'Dim netamount1 As String
    '            'Dim markupamount1 As String
    '            'Dim sellingamount1 As String


    '            item1 = DataGridView1.Rows(i).Cells(0).Value.ToString
    '            description1 = DataGridView1.Rows(i).Cells(1).Value.ToString
    '            unit1 = DataGridView1.Rows(i).Cells(2).Value.ToString
    '            qty1 = DataGridView1.Rows(i).Cells(3).Value.ToString
    '            'netrate1 = Convert.ToDecimal(DataGridView1.Rows(i).Cells(4).Value)
    '            'amount1 = Convert.ToDecimal(DataGridView1.Rows(i).Cells(5).Value)
    '            'markup1 = DataGridView1.Rows(i).Cells(6).Value.ToString
    '            'billitemno1 = DataGridView1.Rows(i).Cells(7).Value.ToString
    '            'tradeid1 = DataGridView1.Rows(i).Cells(8).Value.ToString
    '            'pricecode1 = DataGridView1.Rows(i).Cells(9).Value.ToString
    '            'startdate1 = DataGridView1.Rows(i).Cells(10).Value.ToString
    '            'enddate1 = DataGridView1.Rows(i).Cells(11).Value.ToString
    '            'duration1 = DataGridView1.Rows(i).Cells(12).Value.ToString
    '            'netamount1 = DataGridView1.Rows(i).Cells(13).Value.ToString
    '            'markupamount1 = DataGridView1.Rows(i).Cells(14).Value.ToString
    '            'sellingamount1 = DataGridView1.Rows(i).Cells(15).Value.ToString



    '            ReDim Preserve itemno(indexd)
    '            ReDim Preserve descr(indexd)
    '            ReDim Preserve unit(indexd)
    '            ReDim Preserve qty(indexd)
    '            'ReDim Preserve Net(indexd)
    '            'ReDim Preserve Amount(indexd)
    '            'ReDim Preserve Markup(indexd)
    '            'ReDim Preserve BillItemno(indexd)
    '            'ReDim Preserve TradeID(indexd)
    '            'ReDim Preserve Pricecode(indexd)
    '            'ReDim Preserve startdate(indexd)
    '            'ReDim Preserve enddate(indexd)
    '            'ReDim Preserve duration(indexd)
    '            'ReDim Preserve netamount(indexd)
    '            'ReDim Preserve markupamount(indexd)
    '            'ReDim Preserve sellingamount(indexd)




    '            itemno(i) = item1
    '            descr(i) = description1
    '            unit(i) = unit1
    '            qty(i) = qty1

    '            'COMMENTED LINES NOT NECESSARY NOW --- KEEPING THEM COMMENTED INCASE THEY'LL BE NEEDED IN FUTURE

    '            'Net(i) = netrate1
    '            'Amount(i) = amount1
    '            'Markup(i) = markup1
    '            'BillItemno(i) = billitemno1
    '            'TradeID(i) = tradeid1
    '            'Pricecode(i) = pricecode1
    '            'startdate(i) = startdate1
    '            'enddate(i) = enddate1
    '            'duration(i) = duration1
    '            'netamount(i) = netamount1
    '            'markupamount(i) = markupamount1
    '            'sellingamount(i) = sellingamount1




    '            DataGridView1.Rows(i).Cells(0).Value = itemno(i)
    '            DataGridView1.Rows(i).Cells(1).Value = descr(i)
    '            DataGridView1.Rows(i).Cells(2).Value = unit(i)
    '            ' DataGridView1.Rows(i).Cells(3).Value = qty(i)


    '            'NO NEED to SEND GRID DATA FROM GRID 1 TO ARRAYS BELOW as the VALUES PASSING are currently empty or null --- CAUSING DBNULL CONVERSION ERRORS. But keeping them commented incase needed in the future

    '            'DataGridView1.Rows(i).Cells(4).Value = Net(i)
    '            'DataGridView1.Rows(i).Cells(5).Value = Amount(i)
    '            'DataGridView1.Rows(i).Cells(6).Value = Markup(i)
    '            'DataGridView1.Rows(i).Cells(7).Value = BillItemno(i)
    '            'DataGridView1.Rows(i).Cells(8).Value = TradeID(i)
    '            'DataGridView1.Rows(i).Cells(9).Value = Pricecode(i)
    '            'DataGridView1.Rows(i).Cells(10).Value = startdate(i)
    '            'DataGridView1.Rows(i).Cells(11).Value = enddate(i)
    '            'DataGridView1.Rows(i).Cells(12).Value = duration(i)
    '            'DataGridView1.Rows(i).Cells(13).Value = netamount(i)
    '            'DataGridView1.Rows(i).Cells(14).Value = markupamount(i)
    '            'DataGridView1.Rows(i).Cells(15).Value = sellingamount(i)

    '        Next

    '        Dim indexcf As Integer = DataGridView1.Rows.Count
    '        Dim indexc As Integer

    '        ReDim Preserve itemno(indexcf)
    '        ReDim Preserve descr(indexcf)
    '        ReDim Preserve unit(indexcf)
    '        ReDim Preserve qty(indexcf)


    '        'NO NEED to resize other ARRAYS as they are currently empty or null. But keeping them commented incase needed in the future

    '        'ReDim Preserve Net(indexcf)
    '        'ReDim Preserve Amount(indexcf)
    '        'ReDim Preserve Markup(indexcf)
    '        'ReDim Preserve BillItemno(indexcf)
    '        'ReDim Preserve TradeID(indexcf)
    '        'ReDim Preserve Pricecode(indexcf)
    '        'ReDim Preserve startdate(indexcf)
    '        'ReDim Preserve enddate(indexcf)
    '        'ReDim Preserve duration(indexcf)
    '        'ReDim Preserve netamount(indexcf)
    '        'ReDim Preserve markupamount(indexcf)
    '        'ReDim Preserve sellingamount(indexcf)



    '        '-===========================================-=================================-=========================
    '        'CURRENTLY IN RUNTIME --- DG2 HAS NO ROWS SO CAN'T COUNT THOSE ROWS --- IT WON'T POPULATE
    '        indexc = DataGridView1.Rows.Count - 1

    '        For r As Integer = 0 To indexc - 1

    '            DataGridView2.Rows.Add(itemno(r), descr(r), unit(r), qty(r), "", "", "", "", "", "", "", "", "", "", "", "")

    '        Next


    '        'code below commented incase take different approach to adding rows 

    '        'DataGridView2.Rows.Add(New DataGridViewRow)
    '        'DataGridView2.Rows(r).Cells(0).Value = itemno(r)
    '        'DataGridView2.Rows(r).Cells(1).Value = descr(r)
    '        'DataGridView2.Rows(r).Cells(2).Value = unit(r)
    '        'DataGridView2.Rows(r).Cells(3).Value = QTY(r)
    '        'DataGridView2.Rows(r).Cells(4).Value = Net(r)
    '        'DataGridView2.Rows(r).Cells(5).Value = Amount(r)
    '        'DataGridView2.Rows(r).Cells(6).Value = Markup(r)
    '        'DataGridView2.Rows(r).Cells(7).Value = BillItemno(r)
    '        'DataGridView2.Rows(r).Cells(8).Value = TradeID(r)
    '        'DataGridView2.Rows(r).Cells(9).Value = Pricecode(r)
    '        'DataGridView2.Rows(r).Cells(10).Value = startdate(r)
    '        'DataGridView2.Rows(r).Cells(11).Value = enddate(r)
    '        'DataGridView2.Rows(r).Cells(12).Value = duration(r)
    '        'DataGridView2.Rows(r).Cells(13).Value = netamount(r)
    '        'DataGridView2.Rows(r).Cells(14).Value = markupamount(r)
    '        'DataGridView2.Rows(r).Cells(15).Value = sellingamount(r)





    '        For i As Integer = 0 To 14

    '            'Mark-up can be edited from the Grid

    '            DataGridView2.Columns(i).ReadOnly = True

    '        Next

    '        DataGridView2.Columns(5).ReadOnly = False



    '        'prefer this one---other one required cells to not be empty to work
    '        Dim indexf As Integer = DataGridView2.CurrentCell.ColumnIndex
    '        Dim header1 As Integer = DataGridView2.CurrentCell.ColumnIndex

    '        'this checks if the cell selected is in RATE column and if the is item number in ITEM NO column. If not the form don't show

    '        For indexk As Integer = 0 To DataGridView2.Rows.Count - 1


    '            'checking qty and item no --- color = light yellow
    '            If Convert.ToString(DataGridView2.Rows(indexk).Cells(0).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(indexk).Cells(3).Value) <> Convert.ToString("") Then

    '                DataGridView2.Rows(indexk).DefaultCellStyle.BackColor = Color.PowderBlue

    '            End If

    '        Next

    '        'selling amount check ---- COMPLETED BILL ITEM ROWS ---- CODE PUT UNDER DATABASE FUNCTIONS FETCH.

    '        'DataGridView2.Rows(6).Cells(15).Value = 122

    '        For i As Integer = 0 To DataGridView2.Rows.Count - 1

    '            If Convert.ToString(DataGridView2.Rows(i).Cells(0).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(i).Cells(3).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(i).Cells(4).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(i).Cells(15).Value) <> Convert.ToString("") Then

    '                DataGridView2.Rows(6).DefaultCellStyle.BackColor = Color.CornflowerBlue

    '            End If
    '        Next

    '        'HIDING PRICRCODE COLUMN AS PER CLIENT REQUEST
    '        DataGridView2.Columns(9).Visible = False

    '    Catch ex As Exception
    '        MsgBox(ex.Message)
    '    End Try



    'End Sub




    'Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

    '    Try
    '        BillSellingRate()

    '        BillNetAmount()

    '        aMarkupAmount()

    '        BillSellingAmount()



    '        Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index



    '        'Auto fill the Bill no
    '        DataGridView2.Rows(selectedrow1).Cells(7).Value = txtcurrentBill.Text


    '        For i As Integer = 0 To DataGridView2.Rows.Count - 1
    '            If Convert.ToString(DataGridView2.Rows(selectedrow1).Cells(0).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(selectedrow1).Cells(3).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(selectedrow1).Cells(4).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(selectedrow1).Cells(15).Value) <> Convert.ToString("") Then

    '                DataGridView2.Rows(selectedrow1).DefaultCellStyle.BackColor = Color.Coral

    '            End If
    '        Next
    '    Catch ex As Exception
    '        MsgBox(ex.Message)
    '    End Try




    'End Sub

    'Private Sub btnprojcode_Click(sender As Object, e As EventArgs) Handles btnprojcode.Click
    '    Try
    '        frmProjectCode.Show()
    '        Me.Hide()
    '    Catch ex As Exception
    '        MsgBox(ex.Message)
    '    End Try

    'End Sub

    'Private Sub DataGridView2_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles DataGridView2.MouseDoubleClick
    '    Try
    '        'prefer this one---other one required cells to not be empty to work
    '        Dim indexf As Integer = DataGridView2.CurrentCell.ColumnIndex
    '        Dim header1 As Integer = DataGridView2.CurrentCell.ColumnIndex
    '        Dim indexh As Integer = DataGridView2.CurrentRow.Index

    '        'this checks if the cell selected is in RATE column and if the is item number in ITEM NO column. If not the form don't show
    '        MsgBox(header1)

    '        For i As Integer = 0 To indexf - 1

    '            'could use a select statement in future

    '            'Bill NET RATE pop up form
    '            If header1 = 4 And Convert.ToString(DataGridView2.Rows(indexh).Cells(0).Value.ToString().Trim()) <> Convert.ToString("") Then

    '                frmPriceCode.Show()


    '            End If

    '            'Bill trade ID pop up form
    '            If header1 = 8 And Convert.ToString(DataGridView2.Rows(indexh).Cells(0).Value.ToString().Trim()) <> Convert.ToString("") Then


    '                frmBillTrade.Show()



    '                'Bill Datetimepicker estimated start date pop up form
    '            ElseIf header1 = 10 And Convert.ToString(DataGridView2.Rows(indexh).Cells(0).Value.ToString().Trim()) <> Convert.ToString("") Then

    '                frmDatePickerStart.Show()



    '            End If


    '            'Bill Datetimepicker end date pop up form
    '            If header1 = 11 And Convert.ToString(DataGridView2.Rows(indexh).Cells(0).Value.ToString().Trim()) <> Convert.ToString("") Then

    '                frmDatePickerEnd.Show()



    '            End If
    '        Next
    '    Catch ex As Exception
    '        MsgBox(ex.Message)
    '    End Try
    'End Sub

    Private Sub btnhide_Click(sender As Object, e As EventArgs) Handles btnhide.Click
        Try

            columnindex = DataGridView2.CurrentCell.ColumnIndex

            DataGridView2.Columns(columnindex).Visible = False

            'focus
            DataGridView2.Rows(0).Cells(0).Selected = True
            DataGridView2.Select()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnImportval_Click(sender As Object, e As EventArgs) Handles btnImportval.Click
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            sqlcomm.CommandText = "SELECT* FROM T_Bill"

            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()

            Dim Rowcount As Integer = dt.Rows.Count
            Dim Colcount As Integer = dt.Columns.Count

            For i As Integer = 0 To Rowcount
                ' DataGridView2.Rows.Add(New DataGridViewRow)
                DataGridView2.Rows.Add("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")
            Next

            For i As Integer = 0 To Rowcount - 1
                DataGridView2.Rows(i).Cells(2).Value = dt.Rows(i)("Unit Measure")
                DataGridView2.Rows(i).Cells(1).Value = dt.Rows(i)("BillItemDescription")
                DataGridView2.Rows(i).Cells(0).Value = dt.Rows(i)("ItemNumber")
                DataGridView2.Rows(i).Cells(3).Value = dt.Rows(i)("BillQty")
                DataGridView2.Rows(i).Cells(4).Value = dt.Rows(i)("BillNetRate")
                DataGridView2.Rows(i).Cells(5).Value = dt.Rows(i)("BillSellingRate")
                DataGridView2.Rows(i).Cells(6).Value = dt.Rows(i)("BillMarkup")
                DataGridView2.Rows(i).Cells(7).Value = dt.Rows(i)("Bill Item No")
                DataGridView2.Rows(i).Cells(8).Value = dt.Rows(i)("ProjectCode")
                DataGridView2.Rows(i).Cells(9).Value = dt.Rows(i)("BillTradeId")
                DataGridView2.Rows(i).Cells(10).Value = dt.Rows(i)("BillPriceCode")
                DataGridView2.Rows(i).Cells(11).Value = dt.Rows(i)("BillItemStartDate")
                DataGridView2.Rows(i).Cells(12).Value = dt.Rows(i)("BillItemEndDate")
                DataGridView2.Rows(i).Cells(13).Value = dt.Rows(i)("BillItemDuration")
                DataGridView2.Rows(i).Cells(14).Value = dt.Rows(i)("BillNetAmount")
                DataGridView2.Rows(i).Cells(15).Value = dt.Rows(i)("BillMarkupAmount")
                DataGridView2.Rows(i).Cells(16).Value = dt.Rows(i)("BillSellingAmount")
                DataGridView2.Rows(i).Cells(17).Value = dt.Rows(i)("BillActualQty")
                DataGridView2.Rows(i).Cells(18).Value = dt.Rows(i)("BillClaimedQty")
                DataGridView2.Rows(i).Cells(19).Value = dt.Rows(i)("BillCertifiedQty")
                DataGridView2.Rows(i).Cells(20).Value = dt.Rows(i)("BillPaidQty")
                DataGridView2.Rows(i).Cells(21).Value = dt.Rows(i)("BillFinalQty")
                DataGridView2.Rows(i).Cells(22).Value = dt.Rows(i)("BillFinalNetRate")
                DataGridView2.Rows(i).Cells(23).Value = dt.Rows(i)("BillCostRate")
                DataGridView2.Rows(i).Cells(24).Value = dt.Rows(i)("BillFinalNetAmount")
                DataGridView2.Rows(i).Cells(25).Value = dt.Rows(i)("BillFinalSellingAmount")
                DataGridView2.Rows(i).Cells(26).Value = dt.Rows(i)("BillActualStartDate")
                DataGridView2.Rows(i).Cells(27).Value = dt.Rows(i)("BillActualEndDate")
                DataGridView2.Rows(i).Cells(28).Value = dt.Rows(i)("BillActualDuration")
                DataGridView2.Rows(i).Cells(29).Value = dt.Rows(i)("BillRemeasureQty")
                DataGridView2.Rows(i).Cells(30).Value = dt.Rows(i)("BillRemeasureNetAmount")
                DataGridView2.Rows(i).Cells(31).Value = dt.Rows(i)("BillRemeasureSellingAmount")
                DataGridView2.Rows(i).Cells(32).Value = dt.Rows(i)("BillActualNetAmount")
                DataGridView2.Rows(i).Cells(33).Value = dt.Rows(i)("BillActualSellingAmount")
                DataGridView2.Rows(i).Cells(34).Value = dt.Rows(i)("BillClaimedAmount")
                DataGridView2.Rows(i).Cells(35).Value = dt.Rows(i)("BillCertifiedAmount")
                DataGridView2.Rows(i).Cells(36).Value = dt.Rows(i)("BillPaidAmount")

                'setting default final qty (index 21) to bill qty
                DataGridView2.Rows(i).Cells(21).Value = DataGridView2.Rows(i).Cells(3).Value

                'setting default cost rate (index 23) to net rate 
                DataGridView2.Rows(i).Cells(23).Value = DataGridView2.Rows(i).Cells(4).Value


                'setting default final net rate (index 22) to net rate
                DataGridView2.Rows(i).Cells(22).Value = DataGridView2.Rows(i).Cells(4).Value



            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub DataGridView2_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView2.CellDoubleClick
        Dim selectedrow4 As Integer = DataGridView2.CurrentCell.ColumnIndex
        MsgBox(selectedrow4)
    End Sub


End Class