﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmValuation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btnhide = New System.Windows.Forms.Button()
        Me.btnshowprev = New System.Windows.Forms.Button()
        Me.btnshowall = New System.Windows.Forms.Button()
        Me.btnshownext = New System.Windows.Forms.Button()
        Me.btnprojcode = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtcurrentBill = New System.Windows.Forms.TextBox()
        Me.txtProjName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtProjCode = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btnImportval = New System.Windows.Forms.Button()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.txtPriceCodeResourcingRate = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.txtSearchBillToEdit = New System.Windows.Forms.TextBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.Column37 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column36 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column24 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column25 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column26 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column27 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column28 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column29 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column30 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column31 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column32 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column33 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column34 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column35 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnhide
        '
        Me.btnhide.BackColor = System.Drawing.Color.LightCoral
        Me.btnhide.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhide.Location = New System.Drawing.Point(758, 7)
        Me.btnhide.Name = "btnhide"
        Me.btnhide.Size = New System.Drawing.Size(246, 23)
        Me.btnhide.TabIndex = 235
        Me.btnhide.Text = " HIDE SELECTED COLUMN"
        Me.btnhide.UseVisualStyleBackColor = False
        '
        'btnshowprev
        '
        Me.btnshowprev.BackColor = System.Drawing.Color.Turquoise
        Me.btnshowprev.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnshowprev.Location = New System.Drawing.Point(757, 36)
        Me.btnshowprev.Name = "btnshowprev"
        Me.btnshowprev.Size = New System.Drawing.Size(246, 23)
        Me.btnshowprev.TabIndex = 234
        Me.btnshowprev.Text = "<<< SHOW PREVIOUS HIDDEN COLUMN"
        Me.btnshowprev.UseVisualStyleBackColor = False
        '
        'btnshowall
        '
        Me.btnshowall.BackColor = System.Drawing.Color.Chartreuse
        Me.btnshowall.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnshowall.Location = New System.Drawing.Point(758, 91)
        Me.btnshowall.Name = "btnshowall"
        Me.btnshowall.Size = New System.Drawing.Size(247, 23)
        Me.btnshowall.TabIndex = 236
        Me.btnshowall.Text = "SHOW ALL COLUMNS"
        Me.btnshowall.UseVisualStyleBackColor = False
        '
        'btnshownext
        '
        Me.btnshownext.BackColor = System.Drawing.Color.Turquoise
        Me.btnshownext.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnshownext.Location = New System.Drawing.Point(756, 62)
        Me.btnshownext.Name = "btnshownext"
        Me.btnshownext.Size = New System.Drawing.Size(247, 23)
        Me.btnshownext.TabIndex = 233
        Me.btnshownext.Text = "SHOW NEXT HIDDEN COLUMN >>>"
        Me.btnshownext.UseVisualStyleBackColor = False
        '
        'btnprojcode
        '
        Me.btnprojcode.Location = New System.Drawing.Point(252, 10)
        Me.btnprojcode.Name = "btnprojcode"
        Me.btnprojcode.Size = New System.Drawing.Size(75, 23)
        Me.btnprojcode.TabIndex = 230
        Me.btnprojcode.Text = "Search"
        Me.btnprojcode.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 72)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(102, 13)
        Me.Label4.TabIndex = 229
        Me.Label4.Text = "Enter Current Bill No"
        '
        'txtcurrentBill
        '
        Me.txtcurrentBill.Location = New System.Drawing.Point(121, 67)
        Me.txtcurrentBill.Name = "txtcurrentBill"
        Me.txtcurrentBill.Size = New System.Drawing.Size(206, 20)
        Me.txtcurrentBill.TabIndex = 228
        '
        'txtProjName
        '
        Me.txtProjName.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtProjName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProjName.ForeColor = System.Drawing.SystemColors.Window
        Me.txtProjName.Location = New System.Drawing.Point(121, 37)
        Me.txtProjName.Name = "txtProjName"
        Me.txtProjName.Size = New System.Drawing.Size(206, 20)
        Me.txtProjName.TabIndex = 227
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(37, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 226
        Me.Label3.Text = "Project Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(415, 17)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(113, 13)
        Me.Label2.TabIndex = 225
        Me.Label2.Text = "Select Bill No. To Edit:"
        '
        'txtProjCode
        '
        Me.txtProjCode.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtProjCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProjCode.ForeColor = System.Drawing.SystemColors.Window
        Me.txtProjCode.Location = New System.Drawing.Point(121, 10)
        Me.txtProjCode.Name = "txtProjCode"
        Me.txtProjCode.Size = New System.Drawing.Size(125, 20)
        Me.txtProjCode.TabIndex = 224
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 13)
        Me.Label1.TabIndex = 223
        Me.Label1.Text = "Project Code"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(1143, 665)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 26)
        Me.Button3.TabIndex = 222
        Me.Button3.Text = "Finalized"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btnImportval
        '
        Me.btnImportval.Location = New System.Drawing.Point(898, 668)
        Me.btnImportval.Name = "btnImportval"
        Me.btnImportval.Size = New System.Drawing.Size(75, 23)
        Me.btnImportval.TabIndex = 221
        Me.btnImportval.Text = "Import Valuation"
        Me.btnImportval.UseVisualStyleBackColor = True
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(1283, 668)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 220
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(184, 665)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 219
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'txtPriceCodeResourcingRate
        '
        Me.txtPriceCodeResourcingRate.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.txtPriceCodeResourcingRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPriceCodeResourcingRate.ForeColor = System.Drawing.SystemColors.Window
        Me.txtPriceCodeResourcingRate.Location = New System.Drawing.Point(563, 69)
        Me.txtPriceCodeResourcingRate.Name = "txtPriceCodeResourcingRate"
        Me.txtPriceCodeResourcingRate.Size = New System.Drawing.Size(126, 20)
        Me.txtPriceCodeResourcingRate.TabIndex = 218
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(415, 72)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(142, 13)
        Me.Label11.TabIndex = 217
        Me.Label11.Text = "Price Code Resourcing Rate"
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(648, 17)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(41, 23)
        Me.btnSearch.TabIndex = 216
        Me.btnSearch.Text = "Go"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'txtSearchBillToEdit
        '
        Me.txtSearchBillToEdit.Location = New System.Drawing.Point(563, 17)
        Me.txtSearchBillToEdit.Name = "txtSearchBillToEdit"
        Me.txtSearchBillToEdit.Size = New System.Drawing.Size(79, 20)
        Me.txtSearchBillToEdit.TabIndex = 215
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(623, 668)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 214
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Enabled = False
        Me.btnSave.Location = New System.Drawing.Point(373, 665)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(92, 23)
        Me.btnSave.TabIndex = 213
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column37, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column7, Me.Column6, Me.Column8, Me.Column1, Me.Column9, Me.Column10, Me.Column11, Me.Column12, Me.Column13, Me.Column14, Me.Column15, Me.Column16, Me.Column17, Me.Column18, Me.Column19, Me.Column20, Me.Column21, Me.Column22, Me.Column23, Me.Column36, Me.Column24, Me.Column25, Me.Column26, Me.Column27, Me.Column28, Me.Column29, Me.Column30, Me.Column31, Me.Column32, Me.Column33, Me.Column34, Me.Column35})
        Me.DataGridView2.Location = New System.Drawing.Point(9, 120)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(1348, 514)
        Me.DataGridView2.TabIndex = 237
        '
        'Column37
        '
        Me.Column37.HeaderText = "ITEM NUMBER"
        Me.Column37.Name = "Column37"
        '
        'Column2
        '
        Me.Column2.HeaderText = "DESCRIPTION"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.HeaderText = "UNIT"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.HeaderText = "QUANTITY"
        Me.Column4.Name = "Column4"
        '
        'Column5
        '
        Me.Column5.HeaderText = "NET RATE"
        Me.Column5.Name = "Column5"
        '
        'Column7
        '
        Me.Column7.HeaderText = "SELLING RATE"
        Me.Column7.Name = "Column7"
        '
        'Column6
        '
        Me.Column6.HeaderText = "MARK-UP"
        Me.Column6.Name = "Column6"
        '
        'Column8
        '
        Me.Column8.HeaderText = "BILL ITEM NO"
        Me.Column8.Name = "Column8"
        '
        'Column1
        '
        Me.Column1.HeaderText = "PROJECT CODE"
        Me.Column1.Name = "Column1"
        '
        'Column9
        '
        Me.Column9.HeaderText = "BILL TRADE ID"
        Me.Column9.Name = "Column9"
        '
        'Column10
        '
        Me.Column10.HeaderText = "PRICE CODE"
        Me.Column10.Name = "Column10"
        '
        'Column11
        '
        Me.Column11.HeaderText = "START DATE"
        Me.Column11.Name = "Column11"
        '
        'Column12
        '
        Me.Column12.HeaderText = "END DATE"
        Me.Column12.Name = "Column12"
        '
        'Column13
        '
        Me.Column13.HeaderText = "DURATION"
        Me.Column13.Name = "Column13"
        '
        'Column14
        '
        Me.Column14.HeaderText = "NET AMOUNT"
        Me.Column14.Name = "Column14"
        '
        'Column15
        '
        Me.Column15.HeaderText = "MARK-UP AMOUNT"
        Me.Column15.Name = "Column15"
        '
        'Column16
        '
        Me.Column16.HeaderText = "SELLING AMOUNT"
        Me.Column16.Name = "Column16"
        '
        'Column17
        '
        Me.Column17.HeaderText = "ACTUAL QUANTITY"
        Me.Column17.Name = "Column17"
        '
        'Column18
        '
        Me.Column18.HeaderText = "CLAIMED QUANTITY"
        Me.Column18.Name = "Column18"
        '
        'Column19
        '
        Me.Column19.HeaderText = "CERTIFIED QUANTITY"
        Me.Column19.Name = "Column19"
        '
        'Column20
        '
        Me.Column20.HeaderText = "PAID QUANTITY"
        Me.Column20.Name = "Column20"
        '
        'Column21
        '
        Me.Column21.HeaderText = "FINAL QUANTITY"
        Me.Column21.Name = "Column21"
        '
        'Column22
        '
        Me.Column22.HeaderText = "FINAL NET RATE"
        Me.Column22.Name = "Column22"
        '
        'Column23
        '
        Me.Column23.HeaderText = "COST RATE"
        Me.Column23.Name = "Column23"
        '
        'Column36
        '
        Me.Column36.HeaderText = "FINAL NET AMOUNT"
        Me.Column36.Name = "Column36"
        '
        'Column24
        '
        Me.Column24.HeaderText = "FINAL SELLING AMOUNT"
        Me.Column24.Name = "Column24"
        '
        'Column25
        '
        Me.Column25.HeaderText = "ACTUAL START DATE"
        Me.Column25.Name = "Column25"
        '
        'Column26
        '
        Me.Column26.HeaderText = "ACTUAL END DATE"
        Me.Column26.Name = "Column26"
        '
        'Column27
        '
        Me.Column27.HeaderText = "ACTUAL DURATION"
        Me.Column27.Name = "Column27"
        '
        'Column28
        '
        Me.Column28.HeaderText = "REMEASURE QUANTITY"
        Me.Column28.Name = "Column28"
        '
        'Column29
        '
        Me.Column29.HeaderText = "REMEASURE NET AMOUNT"
        Me.Column29.Name = "Column29"
        '
        'Column30
        '
        Me.Column30.HeaderText = "REMEASURE SELLING AMOUNT"
        Me.Column30.Name = "Column30"
        '
        'Column31
        '
        Me.Column31.HeaderText = "ACTUAL NET AMOUNT"
        Me.Column31.Name = "Column31"
        '
        'Column32
        '
        Me.Column32.HeaderText = "ACTUAL SELLING AMOUNT"
        Me.Column32.Name = "Column32"
        '
        'Column33
        '
        Me.Column33.HeaderText = "CLAIMED AMOUNT"
        Me.Column33.Name = "Column33"
        '
        'Column34
        '
        Me.Column34.HeaderText = "CERTIFIED AMOUNT"
        Me.Column34.Name = "Column34"
        '
        'Column35
        '
        Me.Column35.HeaderText = "PAID AMOUNT"
        Me.Column35.Name = "Column35"
        '
        'frmValuation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 738)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.btnhide)
        Me.Controls.Add(Me.btnshowprev)
        Me.Controls.Add(Me.btnshowall)
        Me.Controls.Add(Me.btnshownext)
        Me.Controls.Add(Me.btnprojcode)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtcurrentBill)
        Me.Controls.Add(Me.txtProjName)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtProjCode)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.btnImportval)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtPriceCodeResourcingRate)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.txtSearchBillToEdit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnSave)
        Me.Name = "frmValuation"
        Me.Text = "VALUATION"
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnhide As Button
    Friend WithEvents btnshowprev As Button
    Friend WithEvents btnshowall As Button
    Friend WithEvents btnshownext As Button
    Friend WithEvents btnprojcode As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents txtcurrentBill As TextBox
    Friend WithEvents txtProjName As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtProjCode As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents btnImportval As Button
    Friend WithEvents btnHome As Button
    Friend WithEvents btnCalculate As Button
    Friend WithEvents txtPriceCodeResourcingRate As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents btnSearch As Button
    Friend WithEvents txtSearchBillToEdit As TextBox
    Friend WithEvents btnClear As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents Column37 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents Column10 As DataGridViewTextBoxColumn
    Friend WithEvents Column11 As DataGridViewTextBoxColumn
    Friend WithEvents Column12 As DataGridViewTextBoxColumn
    Friend WithEvents Column13 As DataGridViewTextBoxColumn
    Friend WithEvents Column14 As DataGridViewTextBoxColumn
    Friend WithEvents Column15 As DataGridViewTextBoxColumn
    Friend WithEvents Column16 As DataGridViewTextBoxColumn
    Friend WithEvents Column17 As DataGridViewTextBoxColumn
    Friend WithEvents Column18 As DataGridViewTextBoxColumn
    Friend WithEvents Column19 As DataGridViewTextBoxColumn
    Friend WithEvents Column20 As DataGridViewTextBoxColumn
    Friend WithEvents Column21 As DataGridViewTextBoxColumn
    Friend WithEvents Column22 As DataGridViewTextBoxColumn
    Friend WithEvents Column23 As DataGridViewTextBoxColumn
    Friend WithEvents Column36 As DataGridViewTextBoxColumn
    Friend WithEvents Column24 As DataGridViewTextBoxColumn
    Friend WithEvents Column25 As DataGridViewTextBoxColumn
    Friend WithEvents Column26 As DataGridViewTextBoxColumn
    Friend WithEvents Column27 As DataGridViewTextBoxColumn
    Friend WithEvents Column28 As DataGridViewTextBoxColumn
    Friend WithEvents Column29 As DataGridViewTextBoxColumn
    Friend WithEvents Column30 As DataGridViewTextBoxColumn
    Friend WithEvents Column31 As DataGridViewTextBoxColumn
    Friend WithEvents Column32 As DataGridViewTextBoxColumn
    Friend WithEvents Column33 As DataGridViewTextBoxColumn
    Friend WithEvents Column34 As DataGridViewTextBoxColumn
    Friend WithEvents Column35 As DataGridViewTextBoxColumn
End Class
