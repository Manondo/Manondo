﻿Public Class frmResourceType
    'sub procedure to be reused to fetch/load data from database tables
    Public Sub connectToDB()
        Try
            'establish connection to DB
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            'select sql statement to view only
            sqlcomm.CommandText = "SELECT* FROM T_ResourceType"
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()

            'populate the datagridview
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    'subprocedure/ module to search and DISPLAY THE SPECIFIC ROW DATA TO THE DATA GRIDVIEW
    Public Sub cSearchID()

        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            'sql to view/open then fetch specific row of data in the table
            sqlcomm.CommandText = "SELECT* FROM T_ResourceType WHERE ResourceType=@AIDE"
            Dim allocID As New OleDb.OleDbParameter("@AID", txtRtype.Text)
            sqlcomm.Parameters.Add(allocID)
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub



    'subprocedure/ module to search and DISPLAY THE SPECIFIC ROW DATA TO THE DATA GRIDVIEW
    Public Sub cSearchDesc()
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "SELECT* FROM T_ResourceType WHERE ResourceDescription=@AD"
            Dim allocdis As New OleDb.OleDbParameter("@AD", txtdesc.Text)
            sqlcomm.Parameters.Add(allocdis)

            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub txtIDalloc_TextChanged(sender As Object, e As EventArgs) Handles txtRtype.TextChanged
        cSearchID()
    End Sub


    Private Sub txtdesc_TextChanged(sender As Object, e As EventArgs) Handles txtdesc.TextChanged
        cSearchDesc()
    End Sub


    Private Sub ResourceType_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connectToDB()
    End Sub


    Private Sub btnNewResourceType_Click(sender As Object, e As EventArgs) Handles btnNewResourceType.Click

        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "INSERT INTO T_ResourceType (ResourceType,ResourceDescription) VALUES (@Rtype,@Rdesc)"


            Dim allochange As New OleDb.OleDbParameter("@Rtype", txtRtypenew.Text)
            Dim allochange1 As New OleDb.OleDbParameter("@Rdesc", txtRdescnew.Text)


            sqlcomm.Parameters.Add(allochange)
            sqlcomm.Parameters.Add(allochange1)

            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            connectToDB()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            Dim intcount As String
            intcount = DataGridView1.CurrentCell.Value
            FRMResources.txtRtype.Text = intcount
            Me.Close()
            FRMResources.Show()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub


    Private Sub txtRtype_MouseDown(sender As Object, e As MouseEventArgs) Handles txtRtype.MouseDown
        'when user puts mouse in text box it clears it
        txtRtype.Clear()
    End Sub

    Private Sub txtdesc_MouseDown(sender As Object, e As MouseEventArgs) Handles txtdesc.MouseDown
        'when user puts mouse in text box it clears it
        txtdesc.Clear()
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmNavigation.Show()
        Me.Close()
    End Sub
End Class