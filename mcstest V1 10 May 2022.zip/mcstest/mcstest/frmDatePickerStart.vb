﻿Public Class frmDatePickerStart


    Private Sub btnSubmitStartDate_Click(sender As Object, e As EventArgs) Handles btnSubmitStartDate.Click

        Try
            'get current selected row
            Dim selectedrow1 As Integer = frmBill.DataGridView2.CurrentRow.Index

            frmBill.DataGridView2.Rows(selectedrow1).Cells(10).Value = DateTimePicker1.Value.ToShortDateString
            Me.Close()
            frmBill.Show()


        Catch ex As Exception

            MsgBox(ex.Message)

        End Try


    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged

        Try


            If True Then


                'get current selected row
                Dim selectedrow1 As Integer = frmBill.DataGridView2.CurrentRow.Index


                'write back text value in textbox to datagrid
                frmBill.DataGridView2.Rows(selectedrow1).Cells(10).Value = DateTimePicker1.Value.ToShortDateString


                Dim dt1 As DateTime = Convert.ToDateTime(DateTimePicker1.Value)
                Dim dt2 As DateTime = Convert.ToDateTime(frmDatePickerEnd.DateTimePicker1.Value)


                Dim ts As TimeSpan = dt2.Subtract(dt1)

                If Convert.ToInt32(ts.Days) >= 0 Then

                    frmBill.DataGridView2.Rows(selectedrow1).Cells(12).Value = Convert.ToInt32(ts.Days)
                Else

                    MessageBox.Show("Invalid Input")

                End If

            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

End Class