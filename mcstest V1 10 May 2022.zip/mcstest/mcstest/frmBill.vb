﻿Imports System.Data.OleDb
Imports System.Math
Public Class frmBill

    Dim indexk As Integer

    Dim columnindex As Integer = 0


    'Declaring Dynamic Arrays
    Dim itemno() As String
    Dim descr() As String
    Dim unit() As String
    Dim qty() As String
    Dim Net() As String
    Dim Amount() As String
    Dim Markup() As String
    Dim BillItemno() As String
    Dim TradeID() As String
    Dim Pricecode() As String
    Dim startdate() As String
    Dim enddate() As String
    Dim duration() As String
    Dim sellingamount() As String
    Dim netamount() As String
    Dim markupamount() As String


    Dim xl As Integer
    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C: Relational Database Design Estimating Rev2.accdb")
    Private ts As Object
    Private e As Object

    'sub procedure to calculate and display results in appropriate rows
    'calculate bill selling rate: (BillNetRate+BillMarkup)
    Public Sub BillSellingRate()

        Try
            Dim sellingrate, netrate, markup As Decimal
            Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index
            markup = Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(5).Value) / 100
            netrate = Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(4).Value)

            sellingrate = netrate + (netrate * markup)

            DataGridView2.Rows(selectedrow1).Cells(6).Value = Round(sellingrate, 2)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub


    'sub to export bill data
    Public Sub Exportbill()
        For i As Integer = 0 To DataGridView2.Rows.Count - 1
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            '     '"& VARIABLENAME &"' is how we insert variables into qouted text.

            sqlcomm.CommandText = "INSERT INTO test (Nametest) VALUES ('" & DataGridView2.Rows(i).Cells(0).Value & "')"


            sqlcomm.ExecuteNonQuery()

            cn.Close()

            'finally populate the datagrid


            'DataGridView1.DataSource = dt

        Next
    End Sub


    'calculate Net Amount:formula is Billqty x Bill Net Rate
    Public Sub BillNetAmount()

        Try
            Dim netAmount As Decimal
            Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index

            Dim billQty1 As Decimal = Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(3).Value)


            netAmount = Round((Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(4).Value) * billQty1), 2)

            DataGridView2.Rows(selectedrow1).Cells(13).Value = netAmount

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try



    End Sub

    'calculate Mark up amount,formula: Bill net Amount* Bill Mark up percentage
    Public Sub aMarkupAmount()

        Try
            Dim billnetAmount, markupAmount1, markup As Decimal
            Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index

            billnetAmount = Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(13).Value)
            markup = Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(5).Value) / 100
            markupAmount1 = billnetAmount * markup

            DataGridView2.Rows(selectedrow1).Cells(14).Value = Round(Convert.ToDecimal(markupAmount1), 2)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub


    'calculate  BillSellingAmount,formula: Bill net Amount + Mark up amount
    Public Sub BillSellingAmount()
        Try
            Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index

            Dim billnetAmount, markupAmount, sellingAmount As Decimal

            billnetAmount = Round(Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(13).Value), 2)
            markupAmount = Round(Convert.ToDecimal(DataGridView2.Rows(selectedrow1).Cells(14).Value), 2)
            sellingAmount = billnetAmount + markupAmount

            DataGridView2.Rows(selectedrow1).Cells(15).Value = Round(sellingAmount, 2)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    'sub to clear all textboxes
    Public Sub clear()
        Try

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Dim txt As Control
        For Each txt In Controls
            If TypeOf txt Is TextBox Then
                txt.Text = ""
            End If
        Next
    End Sub

    'sub procedure to search by id in DB table
    Public Sub cSearchID()
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            'sql to view/open then fetch specific row of data in the table
            sqlcomm.CommandText = "SELECT* FROM T_Bill WHERE BillCode=@AIDE"
            Dim searchID As New OleDb.OleDbParameter("@AID", Val(txtSearchBillToEdit.Text))
            sqlcomm.Parameters.Add(searchID)
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()
            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub



    'sub procedure to display or refresh the T_Bill data on the datagridview

    Private Sub bind_data()
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            sqlcomm.CommandText = "SELECT* FROM T_Bill"

            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()

            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub bind_data2()
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            sqlcomm.CommandText = "SELECT* FROM T_Bill"

            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()

            DataGridView2.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    'sub to calculate duration. Formula: End date - Start Date

    Public Sub BillItemDuration()
        Try
            If True Then

                Dim dt1 As DateTime = Convert.ToDateTime(frmDatePickerStart.DateTimePicker1.Value)
                Dim dt2 As DateTime = Convert.ToDateTime(frmDatePickerEnd.DateTimePicker1.Value)


                Dim ts As TimeSpan = dt2.Subtract(dt1)

                'get current selected row
                Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index

                If Convert.ToInt32(ts.Days) >= 0 Then

                    DataGridView2.Rows(selectedrow1).Cells(8).Value = Convert.ToInt32(ts.Days)
                Else

                    MessageBox.Show("Invalid Input")

                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        Try
            frmNavigation.Show()
            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub btnImport_Click(sender As Object, e As EventArgs) Handles btnImport.Click

        Try
            'POPULATE THE DATAGRIDVIEW1

            Dim con As OleDbConnection
            Dim dta As OleDbDataAdapter
            Dim dts As New DataSet
            Dim excel As String
            Dim useropendialogue As New OpenFileDialog
            Dim dt As New DataTable
            useropendialogue.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
            useropendialogue.Filter = "Excel| *.xlsx;*.xls"
            If useropendialogue.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
                Dim fi As New IO.FileInfo(useropendialogue.FileName)
                Dim FileName As String = useropendialogue.FileName
                excel = fi.FullName
                con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + excel + ";Extended Properties=Excel 12.0;")
                dta = New OleDbDataAdapter("select * from [BOQ$]", con)
                dts = New DataSet
                dta.Fill(dts, "[BOQ$]")
            End If



            DataGridView1.DataSource = dts
            DataGridView1.DataMember = "[BOQ$]"

            'FREEZE THE ITEM NO AND DESCRIPTION---code will use to freeze columns
            DataGridView2.Columns(0).Frozen = True
            DataGridView2.Columns(1).Frozen = True





            Dim indexd As Integer = DataGridView1.Rows.Count

            For i As Integer = 0 To DataGridView1.Rows.Count - 1

                Dim item1 As String
                Dim description1 As String
                Dim unit1 As String
                Dim qty1 As String
                'Dim netrate1 As Decimal
                ''selling rate
                'Dim amount1 As String
                'Dim markup1 As String
                'Dim billitemno1 As String
                'Dim tradeid1 As String
                'Dim pricecode1 As String
                'Dim startdate1 As String
                'Dim enddate1 As String
                'Dim duration1 As String
                'Dim netamount1 As String
                'Dim markupamount1 As String
                'Dim sellingamount1 As String


                item1 = DataGridView1.Rows(i).Cells(0).Value.ToString
                description1 = DataGridView1.Rows(i).Cells(1).Value.ToString
                unit1 = DataGridView1.Rows(i).Cells(2).Value.ToString
                qty1 = DataGridView1.Rows(i).Cells(3).Value.ToString
                'netrate1 = Convert.ToDecimal(DataGridView1.Rows(i).Cells(4).Value)
                'amount1 = Convert.ToDecimal(DataGridView1.Rows(i).Cells(5).Value)
                'markup1 = DataGridView1.Rows(i).Cells(6).Value.ToString
                'billitemno1 = DataGridView1.Rows(i).Cells(7).Value.ToString
                'tradeid1 = DataGridView1.Rows(i).Cells(8).Value.ToString
                'pricecode1 = DataGridView1.Rows(i).Cells(9).Value.ToString
                'startdate1 = DataGridView1.Rows(i).Cells(10).Value.ToString
                'enddate1 = DataGridView1.Rows(i).Cells(11).Value.ToString
                'duration1 = DataGridView1.Rows(i).Cells(12).Value.ToString
                'netamount1 = DataGridView1.Rows(i).Cells(13).Value.ToString
                'markupamount1 = DataGridView1.Rows(i).Cells(14).Value.ToString
                'sellingamount1 = DataGridView1.Rows(i).Cells(15).Value.ToString



                ReDim Preserve itemno(indexd)
                ReDim Preserve descr(indexd)
                ReDim Preserve unit(indexd)
                ReDim Preserve qty(indexd)
                'ReDim Preserve Net(indexd)
                'ReDim Preserve Amount(indexd)
                'ReDim Preserve Markup(indexd)
                'ReDim Preserve BillItemno(indexd)
                'ReDim Preserve TradeID(indexd)
                'ReDim Preserve Pricecode(indexd)
                'ReDim Preserve startdate(indexd)
                'ReDim Preserve enddate(indexd)
                'ReDim Preserve duration(indexd)
                'ReDim Preserve netamount(indexd)
                'ReDim Preserve markupamount(indexd)
                'ReDim Preserve sellingamount(indexd)




                itemno(i) = item1
                descr(i) = description1
                unit(i) = unit1
                qty(i) = qty1

                'COMMENTED LINES NOT NECESSARY NOW --- KEEPING THEM COMMENTED INCASE THEY'LL BE NEEDED IN FUTURE

                'Net(i) = netrate1
                'Amount(i) = amount1
                'Markup(i) = markup1
                'BillItemno(i) = billitemno1
                'TradeID(i) = tradeid1
                'Pricecode(i) = pricecode1
                'startdate(i) = startdate1
                'enddate(i) = enddate1
                'duration(i) = duration1
                'netamount(i) = netamount1
                'markupamount(i) = markupamount1
                'sellingamount(i) = sellingamount1




                DataGridView1.Rows(i).Cells(0).Value = itemno(i)
                DataGridView1.Rows(i).Cells(1).Value = descr(i)
                DataGridView1.Rows(i).Cells(2).Value = unit(i)
                ' DataGridView1.Rows(i).Cells(3).Value = qty(i)


                'NO NEED to SEND GRID DATA FROM GRID 1 TO ARRAYS BELOW as the VALUES PASSING are currently empty or null --- CAUSING DBNULL CONVERSION ERRORS. But keeping them commented incase needed in the future

                'DataGridView1.Rows(i).Cells(4).Value = Net(i)
                'DataGridView1.Rows(i).Cells(5).Value = Amount(i)
                'DataGridView1.Rows(i).Cells(6).Value = Markup(i)
                'DataGridView1.Rows(i).Cells(7).Value = BillItemno(i)
                'DataGridView1.Rows(i).Cells(8).Value = TradeID(i)
                'DataGridView1.Rows(i).Cells(9).Value = Pricecode(i)
                'DataGridView1.Rows(i).Cells(10).Value = startdate(i)
                'DataGridView1.Rows(i).Cells(11).Value = enddate(i)
                'DataGridView1.Rows(i).Cells(12).Value = duration(i)
                'DataGridView1.Rows(i).Cells(13).Value = netamount(i)
                'DataGridView1.Rows(i).Cells(14).Value = markupamount(i)
                'DataGridView1.Rows(i).Cells(15).Value = sellingamount(i)

            Next

            Dim indexcf As Integer = DataGridView1.Rows.Count
            Dim indexc As Integer

            ReDim Preserve itemno(indexcf)
            ReDim Preserve descr(indexcf)
            ReDim Preserve unit(indexcf)
            ReDim Preserve qty(indexcf)


            'NO NEED to resize other ARRAYS as they are currently empty or null. But keeping them commented incase needed in the future

            'ReDim Preserve Net(indexcf)
            'ReDim Preserve Amount(indexcf)
            'ReDim Preserve Markup(indexcf)
            'ReDim Preserve BillItemno(indexcf)
            'ReDim Preserve TradeID(indexcf)
            'ReDim Preserve Pricecode(indexcf)
            'ReDim Preserve startdate(indexcf)
            'ReDim Preserve enddate(indexcf)
            'ReDim Preserve duration(indexcf)
            'ReDim Preserve netamount(indexcf)
            'ReDim Preserve markupamount(indexcf)
            'ReDim Preserve sellingamount(indexcf)



            '-===========================================-=================================-=========================
            'CURRENTLY IN RUNTIME --- DG2 HAS NO ROWS SO CAN'T COUNT THOSE ROWS --- IT WON'T POPULATE
            indexc = DataGridView1.Rows.Count - 1

            For r As Integer = 0 To indexc - 1

                DataGridView2.Rows.Add(itemno(r), descr(r), unit(r), qty(r), "", "", "", "", "", "", "", "", "", "", "", "")

            Next


            'code below commented incase take different approach to adding rows 

            'DataGridView2.Rows.Add(New DataGridViewRow)
            'DataGridView2.Rows(r).Cells(0).Value = itemno(r)
            'DataGridView2.Rows(r).Cells(1).Value = descr(r)
            'DataGridView2.Rows(r).Cells(2).Value = unit(r)
            'DataGridView2.Rows(r).Cells(3).Value = QTY(r)
            'DataGridView2.Rows(r).Cells(4).Value = Net(r)
            'DataGridView2.Rows(r).Cells(5).Value = Amount(r)
            'DataGridView2.Rows(r).Cells(6).Value = Markup(r)
            'DataGridView2.Rows(r).Cells(7).Value = BillItemno(r)
            'DataGridView2.Rows(r).Cells(8).Value = TradeID(r)
            'DataGridView2.Rows(r).Cells(9).Value = Pricecode(r)
            'DataGridView2.Rows(r).Cells(10).Value = startdate(r)
            'DataGridView2.Rows(r).Cells(11).Value = enddate(r)
            'DataGridView2.Rows(r).Cells(12).Value = duration(r)
            'DataGridView2.Rows(r).Cells(13).Value = netamount(r)
            'DataGridView2.Rows(r).Cells(14).Value = markupamount(r)
            'DataGridView2.Rows(r).Cells(15).Value = sellingamount(r)





            For i As Integer = 0 To 14

                'Mark-up can be edited from the Grid

                DataGridView2.Columns(i).ReadOnly = True

            Next

            DataGridView2.Columns(5).ReadOnly = False



            'prefer this one---other one required cells to not be empty to work
            Dim indexf As Integer = DataGridView2.CurrentCell.ColumnIndex
            Dim header1 As Integer = DataGridView2.CurrentCell.ColumnIndex

            'this checks if the cell selected is in RATE column and if the is item number in ITEM NO column. If not the form don't show

            For indexk As Integer = 0 To DataGridView2.Rows.Count - 1


                'checking qty and item no --- color = light yellow
                If Convert.ToString(DataGridView2.Rows(indexk).Cells(0).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(indexk).Cells(3).Value) <> Convert.ToString("") Then

                    DataGridView2.Rows(indexk).DefaultCellStyle.BackColor = Color.PowderBlue

                End If

            Next

            'selling amount check ---- COMPLETED BILL ITEM ROWS ---- CODE PUT UNDER DATABASE FUNCTIONS FETCH.

            'DataGridView2.Rows(6).Cells(15).Value = 122

            For i As Integer = 0 To DataGridView2.Rows.Count - 1

                If Convert.ToString(DataGridView2.Rows(i).Cells(0).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(i).Cells(3).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(i).Cells(4).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(i).Cells(15).Value) <> Convert.ToString("") Then

                    DataGridView2.Rows(6).DefaultCellStyle.BackColor = Color.CornflowerBlue

                End If
            Next

            'HIDING PRICRCODE COLUMN AS PER CLIENT REQUEST
            DataGridView2.Columns(9).Visible = False

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try



    End Sub




    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        Try
            BillSellingRate()

            BillNetAmount()

            aMarkupAmount()

            BillSellingAmount()



            Dim selectedrow1 As Integer = DataGridView2.CurrentRow.Index



            'Auto fill the Bill no
            DataGridView2.Rows(selectedrow1).Cells(7).Value = txtcurrentBill.Text


            For i As Integer = 0 To DataGridView2.Rows.Count - 1
                If Convert.ToString(DataGridView2.Rows(selectedrow1).Cells(0).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(selectedrow1).Cells(3).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(selectedrow1).Cells(4).Value) <> Convert.ToString("") And Convert.ToString(DataGridView2.Rows(selectedrow1).Cells(15).Value) <> Convert.ToString("") Then

                    DataGridView2.Rows(selectedrow1).DefaultCellStyle.BackColor = Color.Coral

                End If
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try




    End Sub

    Private Sub btnprojcode_Click(sender As Object, e As EventArgs) Handles btnprojcode.Click
        Try
            frmProjectCode.Show()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub DataGridView2_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles DataGridView2.MouseDoubleClick
        Try
            'prefer this one---other one required cells to not be empty to work
            Dim indexf As Integer = DataGridView2.CurrentCell.ColumnIndex
            Dim header1 As Integer = DataGridView2.CurrentCell.ColumnIndex
            Dim indexh As Integer = DataGridView2.CurrentRow.Index

            'this checks if the cell selected is in RATE column and if the is item number in ITEM NO column. If not the form don't show
            MsgBox(header1)

            For i As Integer = 0 To indexf - 1

                'could use a select statement in future

                'Bill NET RATE pop up form
                If header1 = 4 And Convert.ToString(DataGridView2.Rows(indexh).Cells(0).Value.ToString().Trim()) <> Convert.ToString("") Then

                    frmPriceCode.Show()


                End If

                'Bill trade ID pop up form
                If header1 = 8 And Convert.ToString(DataGridView2.Rows(indexh).Cells(0).Value.ToString().Trim()) <> Convert.ToString("") Then


                    frmBillTrade.Show()



                    'Bill Datetimepicker estimated start date pop up form
                ElseIf header1 = 10 And Convert.ToString(DataGridView2.Rows(indexh).Cells(0).Value.ToString().Trim()) <> Convert.ToString("") Then

                    frmDatePickerStart.Show()



                End If


                'Bill Datetimepicker end date pop up form
                If header1 = 11 And Convert.ToString(DataGridView2.Rows(indexh).Cells(0).Value.ToString().Trim()) <> Convert.ToString("") Then

                    frmDatePickerEnd.Show()



                End If
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnhide_Click(sender As Object, e As EventArgs) Handles btnhide.Click
        Try

            columnindex = DataGridView2.CurrentCell.ColumnIndex

            DataGridView2.Columns(columnindex).Visible = False

            'focus
            DataGridView2.Rows(0).Cells(0).Selected = True
            DataGridView2.Select()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnshowprev_Click(sender As Object, e As EventArgs) Handles btnshowprev.Click
        Try

            columnindex = DataGridView2.CurrentCell.ColumnIndex

            columnindex = columnindex - 1

            DataGridView2.Columns(columnindex).Visible = True


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnshownext_Click(sender As Object, e As EventArgs) Handles btnshownext.Click
        Try

            columnindex = DataGridView2.CurrentCell.ColumnIndex

            columnindex = columnindex + 1

            DataGridView2.Columns(columnindex).Visible = True


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnshowall_Click(sender As Object, e As EventArgs) Handles btnshowall.Click

        'there are 15 columns on the bill, not including the billcode which is an autonumber

        For i As Integer = 0 To 14

            'show all colums
            DataGridView2.Columns(i).Visible = True

            'HIDING PRICRCODE COLUMN AS PER CLIENT REQUEST
            DataGridView2.Columns(9).Visible = False
        Next
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Exportbill()



    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        bind_data2()
    End Sub
End Class