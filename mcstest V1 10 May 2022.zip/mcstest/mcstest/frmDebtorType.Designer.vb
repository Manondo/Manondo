﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDebtorType
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtdescription = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtDebtorTypeID = New System.Windows.Forms.TextBox()
        Me.txtdesc = New System.Windows.Forms.TextBox()
        Me.txtsearchbyid = New System.Windows.Forms.TextBox()
        Me.btnsearch2 = New System.Windows.Forms.Button()
        Me.btnsearch1 = New System.Windows.Forms.Button()
        Me.btnHome = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(8, 193)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(669, 150)
        Me.DataGridView1.TabIndex = 0
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(85, 389)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 1
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(185, 389)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 2
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(12, 34)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(80, 13)
        Me.Label21.TabIndex = 183
        Me.Label21.Text = "Debtor Type ID"
        '
        'txtdescription
        '
        Me.txtdescription.Location = New System.Drawing.Point(98, 77)
        Me.txtdescription.Name = "txtdescription"
        Me.txtdescription.Size = New System.Drawing.Size(123, 20)
        Me.txtdescription.TabIndex = 182
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(37, 80)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(55, 13)
        Me.Label15.TabIndex = 181
        Me.Label15.Text = "Decription"
        '
        'txtDebtorTypeID
        '
        Me.txtDebtorTypeID.Location = New System.Drawing.Point(98, 34)
        Me.txtDebtorTypeID.Name = "txtDebtorTypeID"
        Me.txtDebtorTypeID.Size = New System.Drawing.Size(123, 20)
        Me.txtDebtorTypeID.TabIndex = 180
        '
        'txtdesc
        '
        Me.txtdesc.Location = New System.Drawing.Point(460, 167)
        Me.txtdesc.Name = "txtdesc"
        Me.txtdesc.Size = New System.Drawing.Size(145, 20)
        Me.txtdesc.TabIndex = 185
        Me.txtdesc.Text = "Type Description to search"
        '
        'txtsearchbyid
        '
        Me.txtsearchbyid.Location = New System.Drawing.Point(8, 167)
        Me.txtsearchbyid.Name = "txtsearchbyid"
        Me.txtsearchbyid.Size = New System.Drawing.Size(109, 20)
        Me.txtsearchbyid.TabIndex = 184
        Me.txtsearchbyid.Text = "Type ID to search"
        '
        'btnsearch2
        '
        Me.btnsearch2.Location = New System.Drawing.Point(611, 167)
        Me.btnsearch2.Name = "btnsearch2"
        Me.btnsearch2.Size = New System.Drawing.Size(66, 23)
        Me.btnsearch2.TabIndex = 186
        Me.btnsearch2.Text = "Search"
        Me.btnsearch2.UseVisualStyleBackColor = True
        '
        'btnsearch1
        '
        Me.btnsearch1.Location = New System.Drawing.Point(123, 167)
        Me.btnsearch1.Name = "btnsearch1"
        Me.btnsearch1.Size = New System.Drawing.Size(66, 23)
        Me.btnsearch1.TabIndex = 187
        Me.btnsearch1.Text = "Search"
        Me.btnsearch1.UseVisualStyleBackColor = True
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(634, 414)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 190
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'frmDebtorType
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(711, 449)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnsearch1)
        Me.Controls.Add(Me.btnsearch2)
        Me.Controls.Add(Me.txtdesc)
        Me.Controls.Add(Me.txtsearchbyid)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.txtdescription)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.txtDebtorTypeID)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "frmDebtorType"
        Me.Text = "DEBTOR TYPE"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents Label21 As Label
    Friend WithEvents txtdescription As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents txtDebtorTypeID As TextBox
    Friend WithEvents txtdesc As TextBox
    Friend WithEvents txtsearchbyid As TextBox
    Friend WithEvents btnsearch2 As Button
    Friend WithEvents btnsearch1 As Button
    Friend WithEvents btnHome As Button
End Class
