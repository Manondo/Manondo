﻿Public Class frmCLASSIFICATION
    Private Sub txtID_TextChanged(sender As Object, e As EventArgs) Handles txtID.TextChanged
        cSearchID()
    End Sub


    'sub procedure to be reused to fetch/load data from database tables
    Public Sub connectToDB()
        Try
            'establish connection to DB
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            'select sql statement to view only
            sqlcomm.CommandText = "SELECT* FROM T_Classification"

            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()

            'populate the datagridview
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    'used same names for sub procedure as form 1 incase of any conflicts
    Public Sub cSearchID()
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            'sql to view/open then fetch specific row of data in the table
            sqlcomm.CommandText = "SELECT* FROM T_Classification WHERE ClassificationID=@AID"
            Dim allocID As New OleDb.OleDbParameter("@AID", Val(txtID.Text))
            sqlcomm.Parameters.Add(allocID)
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub



    Public Sub cSearchClassification()
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "SELECT* FROM T_Classification WHERE ClassificationDescription=@AID"
            Dim allocID As New OleDb.OleDbParameter("@AID", txtClassDesc.Text)
            sqlcomm.Parameters.Add(allocID)
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub txtClassDesc_TextChanged(sender As Object, e As EventArgs) Handles txtClassDesc.TextChanged
        cSearchClassification()
    End Sub


    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "INSERT INTO T_Classification (ClassificationID,ClassificationDescription,AllocationID) VALUES (@CID,@Cdescr,@Allocat)"
            Dim Cdescri As New OleDb.OleDbParameter("@CID", Val(txtAddID.Text))
            'IDN for id number
            Dim CIDN As New OleDb.OleDbParameter("@Cdescr", txtAddClass.Text)
            Dim AID As New OleDb.OleDbParameter("@Allocat", Val(txtallocID.Text))
            sqlcomm.Parameters.Add(Cdescri)
            sqlcomm.Parameters.Add(CIDN)
            sqlcomm.Parameters.Add(AID)

            sqlcomm.ExecuteNonQuery()
            cn.Close()
            DataGridView1.DataSource = dt
            connectToDB()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub frmCLASSIFICATION_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        connectToDB()

    End Sub


    Private Sub btnsearchallocations_Click(sender As Object, e As EventArgs) Handles btnsearchallocations.Click

        Try
            frmALLOCATION.Show()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try



    End Sub


    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            Dim intcount As String
            intcount = DataGridView1.CurrentCell.Value
            frmCost_Codes.txtClassiID.Text = intcount
            frmCost_Codes.Show()
            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    'when user puts mouse in text box it clears it
    Private Sub txtID_MouseDown(sender As Object, e As MouseEventArgs) Handles txtID.MouseDown
        txtID.Clear()
    End Sub

    'when user puts mouse in text box it clears it
    Private Sub txtClassDesc_MouseDown(sender As Object, e As MouseEventArgs) Handles txtClassDesc.MouseDown
        txtClassDesc.Clear()
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmNavigation.Show()
        Me.Close()
    End Sub
End Class