﻿Imports System.Data.OleDb
Public Class frmPriceCodeResourcing

    '==================

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb")
    Public IDKey As Long

    'saves the value from the row index in price code form
    Public IDrow2 As Integer

    'sub procedure to be reused to fetch/load data from database tables
    Public Sub connectToDB()
        Try
            'establish connection to DB
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            'select sql statement to view only
            sqlcomm.CommandText = "SELECT* FROM T_PriceCodeResourcing"
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()

            'populate the datagridview
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    'subprocedure/ module to search and DISPLAY THE SPECIFIC ROW DATA TO THE DATA GRIDVIEW
    Public Sub cSearchID()

        Try
            txtID.Text = frmPriceCode.IndxCurrent
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn

            'sql to view/open then fetch specific row of data in the table
            sqlcomm.CommandText = "SELECT* FROM T_PriceCodeResourcing WHERE PriceCodeResourcingID=@AIDE"
            Dim PRICERESOURCE As New OleDb.OleDbParameter("@AID", Val(txtID.Text))
            sqlcomm.Parameters.Add(PRICERESOURCE)
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()
            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub



    'subprocedure/ module to search and DISPLAY THE SPECIFIC ROW DATA TO THE DATA GRIDVIEW
    Public Sub cSearchBillID()
        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "SELECT* FROM T_PriceCodeResourcing WHERE BillPriceCode=@AD"
            Dim billpricecode As New OleDb.OleDbParameter("@AD", Val(txtbillcode.Text))
            sqlcomm.Parameters.Add(billpricecode)
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()
            DataGridView1.DataSource = dt


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub




    Private Sub btnsearchclassifications_Click(sender As Object, e As EventArgs) Handles btnsearchclassifications.Click

        Try
            FRMResources.Show()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub



    Private Sub txtresourcecode_TextChanged(sender As Object, e As EventArgs) Handles txtresourcecode.TextChanged
        Try
            'here when text is changed in the resource code textbox, the unit measure and rate linked to the resource code is searched and binded/displayed to the labels.
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn
            sqlcomm.CommandText = "SELECT* FROM T_Resources WHERE ResourceCode=@AD"
            Dim resourcecode As New OleDb.OleDbParameter("@AD", Val(txtresourcecode.Text))
            sqlcomm.Parameters.Add(resourcecode)
            dt.Load(sqlcomm.ExecuteReader)
            cn.Close()
            DataGridView1.DataSource = dt

            'linking data from DB to label control
            lblresourceunit.Text = dt.Rows(0)("ResourceUnitMeasure")
            lblresourcerate.Text = dt.Rows(0)("ResourceRate")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub



    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        Try
            Dim cn As New OleDb.OleDbConnection
            Dim dt As New DataTable
            Dim sqlcomm As New OleDb.OleDbCommand
            cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn.Open()
            sqlcomm.Connection = cn


            '==== CALCULATION FOR PRICE CODE RESOURCE RATE FORMULA:(PriceCodeResourceQty x PriceCodeResourceDuration x PriceCodeResourceUsagePerDay x PriceCodeResourceRate)

            'the calculation is correcT.====



            Dim total As Decimal = Val(txtqty.Text) * Val(txtduration.Text) * Val(txtusagePday.Text) * Val(lblresourcerate.Text)

            'total after wastage percentage added
            Dim wastage As Decimal
            wastage = total + (total * (Val(txtPercentage.Text) / 100))



            '     '"& VARIABLENAME &"' is how we insert variables into qouted text.

            sqlcomm.CommandText = "INSERT INTO T_PriceCodeResourcing (PriceCodeResourcingID,BillPriceCode,ResourceCode,ResourceRate,ResourceUnitMeasure,PriceCodeResourceQty,UnitMeasure1,PriceCodeResourceDuration,UnitMeasure2,PriceCodeResourceUsagePerDay,UnitMeasure3,PriceCodeResourceRate,PriceCodeResourcePercentage) VALUES (@priceID,@Bcode,@Rcode,@Rrate,@Runit,@Qty1,@UnitMeasure1,@Duration,@UnitM2,@Usagepday,@UnitM3,'" & wastage & "',@Percentage)"


            Dim Pcode As New OleDb.OleDbParameter("@priceID", Val(txtresourceID.Text))
            Dim Bcode As New OleDb.OleDbParameter("@Bcode", Val(txtbillcode.Text))
            Dim Rcode As New OleDb.OleDbParameter("@Rcode", Val(txtresourcecode.Text))

            'convert the text in the label to number data type to avoid data conversion errors.


            Dim Rrate As New OleDb.OleDbParameter("@Rrate", Val(lblresourcerate.Text))
            Dim Runitm As New OleDb.OleDbParameter("@Runit", lblresourceunit.Text)


            Dim Priceqty As New OleDb.OleDbParameter("@Qty1", Val(txtqty.Text))
            Dim Priceqtyunit As New OleDb.OleDbParameter("@UnitMeasure1", txtunitqty.Text)

            Dim duration As New OleDb.OleDbParameter("@Duration", Val(txtduration.Text))
            Dim durationUnit As New OleDb.OleDbParameter("@UnitM2", txtdurationunit.Text)

            Dim usagePerday As New OleDb.OleDbParameter("@Usagepday", Val(txtusagePday.Text))
            Dim usageUnit As New OleDb.OleDbParameter("@UnitM3", txtusagePerdayunit.Text)
            Dim Perce As New OleDb.OleDbParameter("@Percentage", txtPercentage.Text)

            sqlcomm.Parameters.Add(Pcode)
            sqlcomm.Parameters.Add(Bcode)
            sqlcomm.Parameters.Add(Rcode)
            sqlcomm.Parameters.Add(Rrate)
            sqlcomm.Parameters.Add(Runitm)
            sqlcomm.Parameters.Add(Priceqty)
            sqlcomm.Parameters.Add(Priceqtyunit)
            sqlcomm.Parameters.Add(duration)
            sqlcomm.Parameters.Add(durationUnit)
            sqlcomm.Parameters.Add(usagePerday)
            sqlcomm.Parameters.Add(usageUnit)
            sqlcomm.Parameters.Add(Perce)

            sqlcomm.ExecuteNonQuery()

            cn.Close()

            'finally populate the datagrid


            DataGridView1.DataSource = dt


            'populate the price code resource rate label

            lblpricecoderesourcerate.Text = wastage


            Dim cmd1 As New OleDbCommand("SELECT * FROM T_PriceCodeResourcing where BillPriceCode like '%'+ @parm1 + '%'", conn)
            cmd1.Parameters.AddWithValue("@parm1", txtbillcode.Text)
            Dim da As New OleDbDataAdapter
            da.SelectCommand = cmd1

            Dim table2 As New DataTable
            table2.Clear()
            da.Fill(table2)

            Dim sum As Decimal = 0

            Dim updatedprice As Decimal


            'this array goes through the values in the data table
            'executing the processing below to calculate the sum

            For i As Integer = 0 To table2.Rows.Count - 1
                sum = (Val(table2.Rows(i)("PriceCodeResourceRate")) + sum)

            Next


            updatedprice = sum

            lblRate.Text = updatedprice




            'update sql statement
            Dim cn1 As New OleDb.OleDbConnection
            Dim dt1 As New DataTable
            Dim sqlcomm1 As New OleDb.OleDbCommand
            cn1.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb"
            cn1.Open()

            sqlcomm1.Connection = cn1
            sqlcomm1.CommandText = "UPDATE T_PriceCode SET BillPriceCodeRate=" & updatedprice & " WHERE BillPriceCode=@IDKey"


            Dim Cpricecode As New OleDb.OleDbParameter("@IDKey", Val(txtbillcode.Text))

            sqlcomm1.Parameters.Add(Cpricecode)

            sqlcomm1.ExecuteNonQuery()
            cn1.Close()


            'update the datagridview
            cSearchBillID()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub



    Private Sub btnbillcode_Click(sender As Object, e As EventArgs) Handles btnbillcode.Click

        Try

            frmPriceCode.Show()
            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub txtresourcecode_MouseDown(sender As Object, e As MouseEventArgs) Handles txtresourcecode.MouseDown
        Try
            FRMResources.Show()
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub



    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        frmNavigation.Show()
        Me.Close()
    End Sub




    Private Sub frmPriceCodeResourcing_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        'code to pass values from price code form to pricecoderesourcing form.
        'code to pass values from price code form to pricecoderesourcing form.
        txtbillcode.Text = frmPriceCode.IndxCurrent
        lblDescription.Text = frmPriceCode.IndxCurrent2
        lblUnit.Text = frmPriceCode.IndxCurrent3
        lblRate.Text = frmPriceCode.IndxCurrent4
        cSearchBillID()

        frmPriceCode.Close()

    End Sub

    Private Sub frmPriceCodeResourcing_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class