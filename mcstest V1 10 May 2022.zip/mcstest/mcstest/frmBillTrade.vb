﻿Imports System.Data.OleDb
Public Class frmBillTrade


    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:Relational Database Design Estimating Rev2.accdb")

    Private Sub bind_data()
        Try
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_BillTrade", conn)
            Dim da As New OleDbDataAdapter
            da.SelectCommand = cmd1

            Dim table1 As New DataTable
            table1.Clear()
            da.Fill(table1)

            DataGridView1.DataSource = table1
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        Try
            bind_data()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            Dim strsql As String
            strsql = "INSERT INTO T_BillTrade(BillTradeid,BillTradeDescription) Values(@bid,@bdesc)"
            Dim cmd2 As New OleDbCommand(strsql, conn)

            cmd2.Parameters.AddWithValue("@bid", txtBillTradeID.Text)
            cmd2.Parameters.AddWithValue("@bdesc", txtBillDesc.Text)

            conn.Open()
            cmd2.ExecuteNonQuery()
            conn.Close()
            bind_data()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    ''clearing the inputs
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        Try

            txtBillTradeID.Text = ""
            txtBillDesc.Text = ""
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub



    ''Selecting rows
    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick

        Try
            Dim index As Integer
            index = e.RowIndex

            Dim selectedRow As DataGridViewRow = DataGridView1.Rows(index)

            txtBillTradeID.Text = selectedRow.Cells(0).Value.ToString
            txtBillDesc.Text = selectedRow.Cells(1).Value.ToString
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)

        Try
            Dim cmd4 As New OleDbCommand("delete from T_BillTrade where BillTradeId=@bid", conn)
            cmd4.Parameters.AddWithValue("@bid", txtBillTradeID.Text)

            conn.Open()
            cmd4.ExecuteNonQuery()
            conn.Close()
            bind_data()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub


    ''Search button - search according to description
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles btnDescriptionSearch.Click
        Try
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_BillTrade where BillTradeDescription like '%'+ @parm1 + '%'", conn)
            cmd1.Parameters.AddWithValue("@parm1", txtSearch.Text)
            Dim da As New OleDbDataAdapter
            da.SelectCommand = cmd1

            Dim table1 As New DataTable
            table1.Clear()
            da.Fill(table1)

            DataGridView1.DataSource = table1
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub btnBill_Click(sender As Object, e As EventArgs) Handles btnBill.Click

        Try
            frmBill.Show()
            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub



    'search according to ID
    Private Sub btnIDsearch_Click(sender As Object, e As EventArgs) Handles btnIDsearch.Click
        Try
            Dim cmd1 As New OleDbCommand("SELECT * FROM T_BillTrade where BillTradeId like '%'+ @parm1 + '%'", conn)
            cmd1.Parameters.AddWithValue("@parm1", txtID.Text)
            Dim da As New OleDbDataAdapter
            da.SelectCommand = cmd1

            Dim table1 As New DataTable
            table1.Clear()
            da.Fill(table1)

            DataGridView1.DataSource = table1
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        Try

            Dim selectedrow1 As Integer = frmBill.DataGridView2.CurrentRow.Index

            'ASIGNING VALUE OF THE SELECTED CELL TO THE VARABLE intcount
            Dim TradeID As Integer = DataGridView1.CurrentCell.Value

            frmBill.DataGridView2.Rows(selectedrow1).Cells(8).Value = TradeID


            frmBill.Show()

            Me.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click

        Try
            frmNavigation.Show()
            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
End Class